/**
 * /api/products  —  Product catalog endpoints
 * Falls back to in-memory catalog when Supabase is not configured.
 */
const router = require('express').Router();
const supabase = require('../../lib/supabase');
const { PRODUCTS, HEX, slug, expandVariants } = require('../../lib/catalog');

// GET /api/products
router.get('/', async (req, res) => {
  const { category, q, sort = 'featured' } = req.query;
  try {
    if (supabase) {
      let query = supabase.from('v_product_catalog').select('*');
      if (category && category !== 'Semua') query = query.eq('category', category);
      if (q) query = query.ilike('name', `%${q}%`);
      const { data, error } = await query;
      if (error) throw error;
      return res.json({ products: data, source: 'supabase' });
    }
    // Mock fallback
    let arr = PRODUCTS.map(p => ({
      sku_prefix: p.sku_prefix, name: p.name, slug: p.slug, category: p.category,
      retail_price_half_meter: p.retail_half, retail_price_meter: p.retail_meter,
      wholesale_price_yard: p.wholesale_yard, is_featured: p.featured,
      variant_count: p.colors.length,
      colors_preview: p.colors.slice(0, 5).map(c => ({ name: c, hex: HEX[c] || '#888' }))
    }));
    if (category && category !== 'Semua') arr = arr.filter(p => p.category === category);
    if (q) arr = arr.filter(p => p.name.toLowerCase().includes(q.toLowerCase()));
    if (sort === 'name')          arr.sort((a, b) => a.name.localeCompare(b.name));
    else if (sort === 'price-asc')  arr.sort((a, b) => a.retail_price_half_meter - b.retail_price_half_meter);
    else if (sort === 'price-desc') arr.sort((a, b) => b.retail_price_half_meter - a.retail_price_half_meter);
    else arr.sort((a, b) => (b.is_featured ? 1 : 0) - (a.is_featured ? 1 : 0));
    res.json({ products: arr, source: 'catalog' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/products/:slug
router.get('/:slug', async (req, res) => {
  try {
    const product = PRODUCTS.find(p => p.slug === req.params.slug || p.sku_prefix === req.params.slug.toUpperCase());
    if (!product) return res.status(404).json({ error: 'not_found' });
    const variants = product.colors.map(c => ({
      sku: `${product.sku_prefix}-${slug(c)}`,
      color_name: c, hex: HEX[c] || '#888', stock_m: 50
    }));
    if (supabase) {
      const { data: dbVars } = await supabase.from('product_variants')
        .select('sku,color_name,hex,inventory(qty_on_hand,qty_yard)')
        .like('sku', product.sku_prefix + '-%');
      if (dbVars?.length) {
        return res.json({ product, variants: dbVars, source: 'supabase' });
      }
    }
    res.json({ product, variants, source: 'catalog' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/products/categories
router.get('/meta/categories', (_, res) => {
  const cats = [...new Set(PRODUCTS.map(p => p.category))];
  res.json({ categories: ['Semua', ...cats] });
});

// GET /api/products/meta/variants — full denormalized list
router.get('/meta/variants', (_, res) => {
  res.json({ variants: expandVariants(), count: expandVariants().length });
});

module.exports = router;
