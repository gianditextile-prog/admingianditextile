/**
 * /api/whatsapp  —  WhatsApp Cloud API (Meta) webhook + outbound messaging
 *
 *   GET  /webhook    — verification handshake
 *   POST /webhook    — inbound message handler → Claude AI auto-reply
 *   POST /send       — outbound message (text/template)
 */
const router   = require('express').Router();
const axios    = require('axios');
const supabase = require('../../lib/supabase');
const claude   = require('../../lib/claude');

const WA_TOKEN      = process.env.WHATSAPP_TOKEN || '';
const WA_PHONE_ID   = process.env.WHATSAPP_PHONE_NUMBER_ID || '';
const VERIFY_TOKEN  = process.env.WHATSAPP_VERIFY_TOKEN || 'giandi-verify-2026';
const WA_API        = 'https://graph.facebook.com/v20.0';

/**
 * GET /api/whatsapp/webhook
 * Meta verification handshake. Returns the challenge if verify token matches.
 */
router.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  if (mode === 'subscribe' && token === VERIFY_TOKEN) {
    console.log('[wa-webhook] verified');
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

/**
 * POST /api/whatsapp/webhook
 * Receives inbound WhatsApp messages, runs Claude AI, replies automatically.
 */
router.post('/webhook', async (req, res) => {
  // Must return 200 fast (Meta retries on slow responses)
  res.status(200).json({ ok: true });

  try {
    const entry = req.body?.entry?.[0]?.changes?.[0]?.value;
    if (!entry?.messages?.length) return;
    const msg = entry.messages[0];
    const from = msg.from;
    const text = msg.text?.body || '[non-text message]';

    // 1) Find or create conversation + persist inbound
    let conversationId = null;
    let history = [];
    if (supabase) {
      // Upsert customer
      const { data: cust } = await supabase.from('customers').upsert({
        full_name: entry.contacts?.[0]?.profile?.name || 'WhatsApp User',
        phone: from, whatsapp: from, source: 'whatsapp'
      }, { onConflict: 'phone' }).select().single();

      // Find or create conversation
      let { data: conv } = await supabase.from('conversations')
        .select('id').eq('external_id', from).eq('channel', 'whatsapp').maybeSingle();
      if (!conv) {
        const { data: newConv } = await supabase.from('conversations').insert({
          customer_id: cust?.id, channel: 'whatsapp', external_id: from, state: 'open'
        }).select().single();
        conv = newConv;
      }
      conversationId = conv.id;

      // Persist inbound message
      await supabase.from('messages').insert({
        conversation_id: conversationId, direction: 'inbound',
        type: msg.type || 'text', body: text, raw_payload: msg
      });

      // Get last 10 messages for context
      const { data: msgs } = await supabase.from('messages')
        .select('direction,body').eq('conversation_id', conversationId)
        .order('created_at', { ascending: false }).limit(10);
      history = (msgs || []).reverse().map(m => ({
        role: m.direction === 'inbound' ? 'user' : 'assistant', content: m.body
      })).slice(0, -1); // exclude the current message
    }

    // 2) Run Claude AI
    const { reply, intent, confidence } = await claude.chat({
      history, message: text, customerContext: { phone: from }
    });

    // 3) Send reply via WhatsApp Cloud API
    await sendWhatsAppText(from, reply);

    // 4) Persist outbound message
    if (supabase && conversationId) {
      await supabase.from('messages').insert({
        conversation_id: conversationId, direction: 'outbound',
        type: 'text', body: reply, ai_generated: true,
        ai_intent: intent, ai_confidence: confidence
      });
      await supabase.from('conversations').update({
        last_message_at: new Date().toISOString()
      }).eq('id', conversationId);
    }

    console.log(`[wa] ${from} → ${intent} → replied`);
  } catch (e) {
    console.error('[wa-webhook]', e.message);
  }
});

async function sendWhatsAppText(to, body) {
  if (!WA_TOKEN || !WA_PHONE_ID) {
    console.log(`[wa-mock] to=${to}: ${body.slice(0, 120)}`);
    return { mock: true };
  }
  const resp = await axios.post(`${WA_API}/${WA_PHONE_ID}/messages`, {
    messaging_product: 'whatsapp', to, type: 'text',
    text: { preview_url: false, body }
  }, { headers: { Authorization: `Bearer ${WA_TOKEN}`, 'Content-Type': 'application/json' } });
  return resp.data;
}

// POST /api/whatsapp/send  — outbound from admin panel
router.post('/send', async (req, res) => {
  try {
    const { to, body } = req.body;
    if (!to || !body) return res.status(400).json({ error: 'to_and_body_required' });
    const r = await sendWhatsAppText(to, body);
    res.json({ ok: true, ...r });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// POST /api/whatsapp/broadcast — send to many recipients
router.post('/broadcast', async (req, res) => {
  try {
    const { recipients, body } = req.body;
    if (!Array.isArray(recipients) || !body) return res.status(400).json({ error: 'invalid_payload' });
    const results = await Promise.allSettled(recipients.map(to => sendWhatsAppText(to, body)));
    res.json({
      ok: true,
      sent: results.filter(r => r.status === 'fulfilled').length,
      failed: results.filter(r => r.status === 'rejected').length
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
