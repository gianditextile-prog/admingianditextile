/**
 * /api/shipping  —  RajaOngkir shipping rate integration
 *   GET  /provinces       — list provinces
 *   GET  /cities          — list cities (optionally by province)
 *   POST /cost            — get shipping cost (origin, destination, weight, courier)
 */
const router = require('express').Router();
const axios  = require('axios');

const RO_KEY = process.env.RAJAONGKIR_API_KEY || '';
const RO_BASE = process.env.RAJAONGKIR_BASE || 'https://api.rajaongkir.com/starter';
const ORIGIN_CITY_ID = process.env.RAJAONGKIR_ORIGIN_CITY_ID || '152'; // Jakarta Pusat default

const headers = { key: RO_KEY };

router.get('/provinces', async (_, res) => {
  try {
    if (!RO_KEY) return res.json({ results: [], mock: true });
    const { data } = await axios.get(`${RO_BASE}/province`, { headers });
    res.json({ results: data.rajaongkir?.results || [] });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/cities', async (req, res) => {
  try {
    if (!RO_KEY) return res.json({ results: [], mock: true });
    const url = `${RO_BASE}/city${req.query.province ? '?province=' + req.query.province : ''}`;
    const { data } = await axios.get(url, { headers });
    res.json({ results: data.rajaongkir?.results || [] });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/cost', async (req, res) => {
  try {
    const { destination, weight = 1000, courier = 'jne', origin = ORIGIN_CITY_ID } = req.body;
    if (!destination) return res.status(400).json({ error: 'destination_required' });
    if (!RO_KEY) {
      // Mock fallback (typical JNE rates Jakarta → Surabaya, weight 1kg)
      return res.json({
        mock: true,
        results: [{
          code: courier, name: courier.toUpperCase(),
          costs: [
            { service: 'REG', description: 'Layanan Reguler', cost: [{ value: 25000, etd: '2-3', note: '' }] },
            { service: 'YES', description: 'Yakin Esok Sampai', cost: [{ value: 38000, etd: '1', note: '' }] },
            { service: 'OKE', description: 'Ongkos Kirim Ekonomis', cost: [{ value: 22000, etd: '3-4', note: '' }] }
          ]
        }]
      });
    }
    const { data } = await axios.post(`${RO_BASE}/cost`,
      new URLSearchParams({ origin, destination, weight: String(weight), courier }),
      { headers: { ...headers, 'Content-Type': 'application/x-www-form-urlencoded' } });
    res.json({ results: data.rajaongkir?.results || [] });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
