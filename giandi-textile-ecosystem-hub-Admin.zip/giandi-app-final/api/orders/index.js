/**
 * /api/orders  —  Order management
 */
const router   = require('express').Router();
const supabase = require('../../lib/supabase');
const { createTransaction } = require('../../lib/midtrans');

// POST /api/orders  — create new order from cart payload
router.post('/', async (req, res) => {
  try {
    const { customer, items, shipping, channel = 'website', utm = {} } = req.body;
    if (!items?.length) return res.status(400).json({ error: 'items_required' });
    if (!customer?.name || !customer?.phone) return res.status(400).json({ error: 'customer_required' });

    const subtotal = items.reduce((s, i) => s + Number(i.unit_price) * Number(i.qty), 0);
    const shipping_total = subtotal > 500_000 ? 0 : Number(shipping?.cost || 25_000);
    const cost_total = items.reduce((s, i) => s + Number(i.cost_price || 0) * Number(i.qty), 0);
    const grand_total = subtotal + shipping_total;
    const order_no = 'GD-' + new Date().toISOString().slice(2, 10).replace(/-/g, '') + '-' +
                     Math.random().toString(36).slice(2, 10).toUpperCase();

    let order = {
      order_no, channel, status: 'pending_payment',
      customer_name: customer.name, customer_phone: customer.phone, customer_email: customer.email || null,
      shipping_address: shipping || {},
      shipping_courier: shipping?.courier || null,
      shipping_service: shipping?.service || null,
      shipping_total, subtotal, cost_total, grand_total,
      items, placed_at: new Date().toISOString(),
      utm_source: utm.source || null, utm_campaign: utm.campaign || null
    };

    if (supabase) {
      // Upsert customer
      const { data: cust } = await supabase.from('customers').upsert({
        full_name: customer.name, phone: customer.phone, email: customer.email,
        whatsapp: customer.phone, source: channel
      }, { onConflict: 'phone' }).select().single();

      const { data: ord, error } = await supabase.from('orders').insert({
        order_no, customer_id: cust?.id, channel, status: 'pending_payment',
        customer_name: customer.name, customer_phone: customer.phone, customer_email: customer.email,
        shipping_address: shipping || {}, shipping_courier: shipping?.courier,
        shipping_total, subtotal, cost_total, grand_total
      }).select().single();
      if (error) throw error;

      // Insert items
      const itemsRows = items.map(i => ({
        order_id: ord.id,
        variant_id: i.variant_id,
        product_name: i.product_name, color_name: i.color_name, sku: i.sku,
        unit: i.unit, qty: i.qty, unit_price: i.unit_price,
        cost_price: i.cost_price || 0, line_total: i.unit_price * i.qty
      }));
      await supabase.from('order_items').insert(itemsRows);
      order = { ...order, id: ord.id, customer_id: cust?.id };
    }

    // Create Midtrans Snap transaction
    const payment = await createTransaction(order);

    res.json({
      ok: true, order_no, order,
      payment: {
        snap_token: payment.token,
        redirect_url: payment.redirect_url,
        mock: !!payment.mock
      }
    });
  } catch (e) {
    console.error('[create-order]', e);
    res.status(500).json({ error: e.message });
  }
});

// GET /api/orders/:order_no
router.get('/:order_no', async (req, res) => {
  try {
    if (!supabase) return res.json({ order: null, source: 'mock' });
    const { data, error } = await supabase.from('orders').select('*, order_items(*), payments(*), shipments(*)').eq('order_no', req.params.order_no).single();
    if (error) throw error;
    res.json({ order: data });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/orders?phone=...
router.get('/', async (req, res) => {
  try {
    if (!supabase) return res.json({ orders: [], source: 'mock' });
    let q = supabase.from('orders').select('*, order_items(*)').order('placed_at', { ascending: false }).limit(50);
    if (req.query.phone) q = q.eq('customer_phone', req.query.phone);
    if (req.query.status) q = q.eq('status', req.query.status);
    if (req.query.channel) q = q.eq('channel', req.query.channel);
    const { data, error } = await q;
    if (error) throw error;
    res.json({ orders: data });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PATCH /api/orders/:order_no/status
router.patch('/:order_no/status', async (req, res) => {
  try {
    const { status, awb, courier } = req.body;
    if (!supabase) return res.json({ ok: true, mock: true });
    const update = { status, updated_at: new Date().toISOString() };
    if (status === 'shipped') { update.shipped_at = new Date().toISOString(); update.shipping_awb = awb; update.shipping_courier = courier; }
    if (status === 'delivered') update.completed_at = new Date().toISOString();
    const { data, error } = await supabase.from('orders').update(update).eq('order_no', req.params.order_no).select().single();
    if (error) throw error;
    res.json({ ok: true, order: data });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
