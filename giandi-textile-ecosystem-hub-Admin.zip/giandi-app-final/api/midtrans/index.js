/**
 * /api/midtrans  —  Payment gateway endpoints
 *   POST  /create     — create Snap token from existing order
 *   POST  /webhook    — Midtrans HTTPS notification handler (with signature verify)
 */
const router   = require('express').Router();
const crypto   = require('crypto');
const supabase = require('../../lib/supabase');
const { createTransaction, verifyNotification } = require('../../lib/midtrans');

// POST /api/midtrans/create
router.post('/create', async (req, res) => {
  try {
    const order = req.body;
    const tx = await createTransaction(order);
    res.json({ ok: true, ...tx });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

/**
 * POST /api/midtrans/webhook
 * Midtrans posts a JSON notification here when payment status changes.
 *
 * Signature key check (per Midtrans docs):
 *   signature_key = sha512(order_id + status_code + gross_amount + server_key)
 */
router.post('/webhook', async (req, res) => {
  try {
    const n = req.body;
    const serverKey = process.env.MIDTRANS_SERVER_KEY || '';
    const expected = crypto
      .createHash('sha512')
      .update(`${n.order_id}${n.status_code}${n.gross_amount}${serverKey}`)
      .digest('hex');

    if (serverKey && n.signature_key && n.signature_key !== expected) {
      console.warn('[midtrans-webhook] invalid signature', n.order_id);
      return res.status(401).json({ error: 'invalid_signature' });
    }

    // Verify with Midtrans Core
    const verified = await verifyNotification(n);
    const { transaction_status, fraud_status, order_id, payment_type, gross_amount } = verified;

    let orderStatus = null;
    let paymentStatus = 'pending';
    if (transaction_status === 'capture' || transaction_status === 'settlement') {
      if (fraud_status === 'accept' || !fraud_status) {
        orderStatus = 'paid';
        paymentStatus = 'settled';
      }
    } else if (transaction_status === 'pending') {
      paymentStatus = 'pending';
    } else if (['cancel', 'deny', 'expire', 'failure'].includes(transaction_status)) {
      orderStatus = 'cancelled';
      paymentStatus = transaction_status === 'expire' ? 'expired' : 'failed';
    }

    if (supabase) {
      // Upsert payment record
      await supabase.from('payments').upsert({
        midtrans_order_id: order_id,
        midtrans_transaction_id: verified.transaction_id,
        method: (payment_type || 'qris').replace(/[^a-z_]/g, '_'),
        status: paymentStatus,
        amount: Number(gross_amount || 0),
        raw_payload: verified,
        paid_at: orderStatus === 'paid' ? new Date().toISOString() : null
      }, { onConflict: 'midtrans_order_id' });

      // Update order status
      if (orderStatus) {
        await supabase.from('orders').update({
          status: orderStatus,
          paid_at: orderStatus === 'paid' ? new Date().toISOString() : null
        }).eq('order_no', order_id);
      }
    }

    console.log(`[midtrans-webhook] ${order_id} → ${transaction_status} (${paymentStatus})`);
    res.json({ ok: true });
  } catch (e) {
    console.error('[midtrans-webhook]', e);
    res.status(500).json({ error: e.message });
  }
});

// GET /api/midtrans/status/:order_id  — manual status check
router.get('/status/:order_id', async (req, res) => {
  try {
    const { core } = require('../../lib/midtrans');
    const status = await core.transaction.status(req.params.order_id);
    res.json(status);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
