/**
 * /api/claude  —  Direct Claude AI endpoint for in-app sales assistant
 *   POST /chat        — chat with Claude using Giandi sales prompt
 *   POST /extract     — extract structured order from conversation
 *   POST /classify    — classify intent of a message
 */
const router = require('express').Router();
const claude = require('../../lib/claude');

router.post('/chat', async (req, res) => {
  try {
    const { history = [], message, customer = {} } = req.body;
    if (!message) return res.status(400).json({ error: 'message_required' });
    const out = await claude.chat({ history, message, customerContext: customer });
    res.json({ ok: true, ...out });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/extract', async (req, res) => {
  try {
    const order = await claude.extractOrder({ conversation: req.body.conversation || [] });
    res.json({ ok: true, order });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/classify', async (req, res) => {
  try {
    const intent = await claude.classifyIntent(req.body.message || '');
    res.json({ ok: true, intent });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
