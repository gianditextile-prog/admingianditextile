#!/usr/bin/env node
/**
 * Migration helper for Giandi Textile.
 * Prints/runs db/schema.sql against Supabase.
 *
 * Easiest method: Open Supabase Dashboard → SQL Editor → New Query →
 * paste content of db/schema.sql → Run.
 *
 * This script just verifies the SQL file is readable and prints the command.
 */
require('dotenv').config();
const fs = require('fs');
const path = require('path');

const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
if (!fs.existsSync(schemaPath)) {
  console.error('❌ db/schema.sql not found');
  process.exit(1);
}

const sql = fs.readFileSync(schemaPath, 'utf8');
console.log(`✓ Schema file found (${sql.split('\n').length} lines)`);
console.log('\n📋 To apply this schema, choose one option:\n');
console.log('  [A] Recommended — Supabase Dashboard:');
console.log('      1. Open https://app.supabase.com → your project');
console.log('      2. Click "SQL Editor" → "New query"');
console.log('      3. Paste content of db/schema.sql');
console.log('      4. Click "Run"\n');
console.log('  [B] CLI (if you have psql + SUPABASE_DB_URL):');
console.log('      psql "$SUPABASE_DB_URL" -f db/schema.sql\n');
console.log('  [C] Supabase CLI:');
console.log('      supabase db push\n');

process.exit(0);
