#!/usr/bin/env node
/**
 * Idempotent seed script for Giandi Textile.
 * Loads PRODUCTS catalog → upserts products, product_variants, inventory.
 * Run AFTER db/schema.sql has been executed in Supabase SQL Editor.
 *
 * Usage:
 *   node scripts/seed.js
 */
require('dotenv').config();
const supabase = require('../lib/supabase');
const { PRODUCTS, expandVariants } = require('../lib/catalog');

async function main() {
  if (!supabase) {
    console.error('❌ Supabase not configured. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY.');
    process.exit(1);
  }

  console.log('▸ Upserting products...');
  for (const p of PRODUCTS) {
    const { error } = await supabase.from('products').upsert({
      sku_prefix: p.sku_prefix,
      slug: p.slug,
      name: p.name,
      category: p.category,
      retail_price_half_meter: p.retail_half,
      retail_price_meter: p.retail_meter,
      wholesale_price_yard: p.wholesale_yard,
      cost_price: p.cost,
      is_featured: p.featured,
      is_active: true
    }, { onConflict: 'sku_prefix' });
    if (error) console.error(`  ✗ ${p.sku_prefix}:`, error.message);
    else console.log(`  ✓ ${p.sku_prefix} ${p.name}`);
  }

  console.log('\n▸ Upserting variants & inventory...');
  const variants = expandVariants();
  for (const v of variants) {
    const { data: prod } = await supabase.from('products').select('id').eq('sku_prefix', v.product_sku).single();
    if (!prod) continue;

    const { data: variant, error: vErr } = await supabase.from('product_variants').upsert({
      product_id: prod.id,
      sku: v.sku,
      color_name: v.color_name,
      color_code: v.color_code,
      hex: v.hex,
      is_active: true
    }, { onConflict: 'sku' }).select().single();

    if (vErr) { console.error(`  ✗ ${v.sku}:`, vErr.message); continue; }

    await supabase.from('inventory').upsert({
      variant_id: variant.id,
      qty_on_hand: 50,
      qty_reserved: 0,
      reorder_level: 10
    }, { onConflict: 'variant_id' });
  }
  console.log(`  ✓ ${variants.length} variants seeded`);

  console.log('\n✅ Seed complete!');
  process.exit(0);
}

main().catch(e => { console.error(e); process.exit(1); });
