/**
 * GIANDI TEXTILE — ECOSYSTEM HUB v3
 * Bulletproof Production Server
 * - Serves static storefront ALWAYS, even if API/env broken
 * - Each route loaded in try/catch — single broken module won't crash server
 * - Works on Hostinger Node.js, Vercel, Railway, any Node 18+ env
 */
'use strict';

console.log('\n=== GIANDI TEXTILE BOOTING ===');
console.log('Node:', process.version);
console.log('Env:', process.env.NODE_ENV || 'development');
console.log('Cwd:', process.cwd());

try { require('dotenv').config(); console.log('+ dotenv loaded'); }
catch (e) { console.log('- dotenv skipped'); }

const express = require('express');
const path    = require('path');
const fs      = require('fs');

const app  = express();
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';

// CORS
app.use(function(req, res, next){
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization,X-Requested-With');
  if (req.method === 'OPTIONS') return res.status(204).end();
  next();
});

app.use(express.json({ limit: '4mb' }));
app.use(express.urlencoded({ extended: true, limit: '4mb' }));
app.set('trust proxy', 1);

// Static files
const publicDir = path.join(__dirname, 'public');
console.log('Static dir:', publicDir);
console.log('Static exists:', fs.existsSync(publicDir));
console.log('index.html exists:', fs.existsSync(path.join(publicDir, 'index.html')));

app.use(express.static(publicDir, {
  maxAge: 0,
  etag: true,
  setHeaders: function(res, filePath){
    if (filePath.endsWith('.html')) {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    }
  }
}));

app.get('/health',   function(_, res){ res.json({ ok: true, ts: Date.now(), v: '3.0.0' }); });
app.get('/api/ping', function(_, res){ res.json({ pong: true, ts: Date.now() }); });

// Try loading optional API routes
function tryMount(prefix, modulePath){
  try {
    const route = require(modulePath);
    app.use(prefix, route);
    console.log('+ mounted', prefix);
  } catch (e) {
    console.warn('- skipped', prefix, '-', e.message);
    app.use(prefix, function(req, res){
      res.status(503).json({
        ok: false, stub: true,
        message: 'API tidak tersedia. Set environment variables untuk fitur lengkap.',
        endpoint: prefix
      });
    });
  }
}

tryMount('/api/products',  './api/products');
tryMount('/api/orders',    './api/orders');
tryMount('/api/shipping',  './api/shipping');
tryMount('/api/midtrans',  './api/midtrans');
tryMount('/api/whatsapp',  './api/whatsapp');
tryMount('/api/claude',    './api/claude');

// SPA fallback
app.get('*', function(req, res){
  if (req.path.indexOf('/api/') === 0) {
    return res.status(404).json({ error: 'not_found', path: req.path });
  }
  const indexPath = path.join(publicDir, 'index.html');
  if (fs.existsSync(indexPath)) {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    return res.sendFile(indexPath);
  }
  res.status(500).send('index.html not found in: ' + publicDir);
});

app.use(function(err, req, res, _next){
  console.error('[error]', err.message);
  console.error(err.stack);
  res.status(err.status || 500).json({ error: 'internal_error', message: 'Server error' });
});

process.on('uncaughtException', function(e){ console.error('[uncaughtException]', e.message, e.stack); });
process.on('unhandledRejection', function(reason){ console.error('[unhandledRejection]', reason); });

app.listen(PORT, HOST, function(){
  console.log('\n  ====================================================');
  console.log('  | GIANDI TEXTILE - ECOSYSTEM HUB v3              |');
  console.log('  | Running: http://' + HOST + ':' + PORT);
  console.log('  | Env: ' + (process.env.NODE_ENV || 'dev'));
  console.log('  ====================================================\n');
});
