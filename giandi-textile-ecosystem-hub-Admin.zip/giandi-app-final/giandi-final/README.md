# Giandi Textile · Ecosystem Hub v3.0

Premium fabric marketplace + admin platform · production-ready · deployable to Hostinger Node.js hosting.

## Features

### Customer Marketplace (`/`)
- Product catalog with rich color variants (up to 32 colors per product)
- Cart and checkout with retail/wholesale pricing
- Mobile-responsive premium design

### Admin Center (`/admin/`)
- **Dashboard** — KPIs, recent orders, top products, stock alerts, channel distribution
- **Products** — Full PIM: 6-tab editor (General, Variants, Pricing, Media, Stock, SEO)
  - Up to 60 colors per product with named variants
  - Color picker for custom hex codes
  - Bulk color add
  - Photo & video upload (data URI)
  - SEO meta tags with Google preview
- **Variants** — Global color manager (rename propagates to all products)
- **Inventory** — Per-variant stock, attention list, restock alerts
- **Media Library** — Centralized media management
- **Orders** — Multi-channel: WhatsApp, Shopee, TikTok, Lazada
  - Order detail drawer with item breakdown
  - Status updates (processing/shipped/completed)
- **Channels** — Per-channel performance breakdown
- **Customers** — CRM with tier segmentation (VIP/Loyal/New)
- **Shipping** — RajaOngkir integration (6 couriers)
- **Finance** — Revenue trends, profit calculation, transaction ledger
- **Campaigns** — Meta Ads, TikTok Ads, Google Ads tracking with ROAS
- **Vouchers** — Coupon CRUD with usage tracking
- **Flash Sale** — Scheduled flash sales with countdown
- **Storefront** — **Zara-style** hero banner editor:
  - Multiple slides
  - Image OR video per slide
  - Per-slide eyebrow/title/subtitle/CTAs
  - Live preview pane
- **Collections** — Featured collections management
- **Brand & Theme** — Identity, colors, business rules
- **Team & Access** — User management
- **Integrations** — Supabase, Midtrans, WhatsApp, Claude AI, Meta Ads, RajaOngkir
- **Settings** — SEO, backup/restore, system info

## Tech Stack

- **Backend**: Node.js + Express (bulletproof error handling)
- **Frontend**: Vanilla JS + CSS (no build step required)
- **Database**: Supabase PostgreSQL (when env configured)
- **Payments**: Midtrans (QRIS, VA, Cards)
- **Storage**: Persistent localStorage (browser) + Supabase (production)

## Deployment to Hostinger

### Step 1: Upload
1. Login to Hostinger control panel
2. Go to **Tool → File Manager** (or use FTP)
3. Navigate to `nodejs/` directory
4. **Delete any existing deployment** (⋮ → Hapus)
5. Upload `giandi-textile-ecosystem-hub.zip`
6. Right-click ZIP → **Extract**

### Step 2: Configure
Hostinger will auto-detect:
- Framework: **Express**
- Node version: **18 or 20**
- Application Root: **giandi-app-final** (or whatever folder ZIP extracted to)
- Entry point: **server.js**
- Package manager: **npm**

### Step 3: Start
- Click **Deploy** or **Start Application**
- Hostinger will run `npm install` then `node server.js`
- App listens on port from `process.env.PORT`

### Step 4: Access
- Customer marketplace: `https://gianditextile.com/`
- Admin center: `https://gianditextile.com/admin/`

## Local Development

```bash
npm install
npm start
```

Then visit:
- http://localhost:3000/ (marketplace)
- http://localhost:3000/admin/ (admin)

## Why This Won't Break

- `package.json` has **only 2 dependencies** (express + dotenv) — npm install rock-solid
- Each API route loaded in **try/catch** — single broken module won't crash server
- Static files served unconditionally — admin will work even if all APIs fail
- Process-level error handlers prevent uncaught crashes
- No external CDN dependencies in admin (everything bundled or loaded from Google Fonts)

## Environment Variables (Optional)

Create `.env` for production integrations:

```
SUPABASE_URL=
SUPABASE_KEY=
MIDTRANS_SERVER_KEY=
MIDTRANS_CLIENT_KEY=
WA_TOKEN=
WA_PHONE_ID=
CLAUDE_API_KEY=
META_ACCESS_TOKEN=
RAJAONGKIR_KEY=
```

App runs fully WITHOUT these — APIs just return stub 503 responses.

## Browser Storage

Admin uses localStorage with prefix `giandi_admin_v1_*`. To reset:
- Open admin → Settings → Reset Semua Data
- Or DevTools → Application → Local Storage → Clear

## File Structure

```
giandi-app-final/
├── server.js              # Bulletproof Express server
├── package.json           # Only express + dotenv
├── .env.example           # Template for env vars
├── README.md              # This file
├── public/
│   ├── index.html         # Customer marketplace
│   ├── styles.css
│   ├── app.js
│   └── admin/
│       ├── index.html     # Admin shell
│       ├── styles.css     # Admin styles (Zara/Uniqlo aesthetic)
│       ├── data.js        # Master data (products, orders, customers)
│       └── admin.js       # Admin logic (20 pages, all features)
├── api/                   # Optional API routes
├── lib/                   # Backend libraries
├── db/schema.sql          # Supabase schema
└── scripts/               # Migrations & seeds
```

## Version

3.0.0 · Build 2026.05.19
