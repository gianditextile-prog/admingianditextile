/* GIANDI TEXTILE — Customer Marketplace · Clean Production Build */
(function(){
'use strict';

/* ════════════════ MASTER DATA ════════════════ */
var PRODUCTS = [
  {sku:"GI-MSP",name:"Marbella Silk Prestige",cat:"Premium Silk",rh:27500,rm:55000,wy:20000,colors:["Hitam","Broken White","Classic Maroon","Burgundy","Storm Blue","Deep Teal","Urban Mist","Deep Ash","Cocoa Chestnut","Blush Mauve","Warm Tan","Classic Taupe","Coffee","Chocolate Brown","Dusty Lavender","Mystic Plum","Ashen Berry","Soft Mocha","Twilight Navy","Slate Blue","Charcoal","Fog Stone","Grape Violet","Dust Plum","Soft Petal","Blush Petal","Silver Mist","Matcha Cream","Terracotta","Nude Mahogany","Burnt Mahogany","Intense Mahogany"]},
  {sku:"GI-MSL",name:"Marbella Silk Luxe",cat:"Premium Silk",rh:32500,rm:65000,wy:25000,colors:["Black","Royal Navy","Maroon","Forest Deep","Berry Blush","Rose Wood","Sage Grey","Cloudy Blue","Azure Calm","Deep Slate","Vanilla Dust","Caramel Nude"]},
  {sku:"GI-MSPM",name:"Marbella Silk Premium",cat:"Premium Silk",rh:37500,rm:75000,wy:30000,colors:["Ivory","Champagne","Dusty Pink","Sage Green","Olive","Terracotta","Mustard","Navy","Emerald"]},
  {sku:"GI-GS",name:"Golden Silk",cat:"Luxury Silk",rh:30000,rm:60000,wy:23000,colors:["Forest Green","Light Lime Green","Silver Pearl White"]},
  {sku:"GI-RSU",name:"Royanna Silk UV",cat:"Luxury Silk",rh:31000,rm:62000,wy:24000,colors:["Deep Blue","Snow White","Dark Maroon","Burgundy","Misty Purple","Deep Teal","Ash Grey","Warm Mocha"]},
  {sku:"GI-MHP",name:"Maheen Prive",cat:"Textured Premium",rh:34000,rm:68000,wy:28000,colors:["Soft Broken White","Warm Sand Beige","Natural Nude","Cream Stone","Cocoa Sand","Khaki Clay","Tiramisu Earth","Ash Peach Clay","Soft Peach Sand"]},
  {sku:"GI-CUP",name:"Cupro",cat:"Breathable Fabric",rh:36000,rm:72000,wy:29000,colors:["Desert Dune","Champagne Sand","Soft Almond","Cocoa Mousse","Sage Laurel","Graphite Ash","Midnight Navy","Onyx Black","Rosewood Blush"]},
  {sku:"GI-JKS",name:"Jetblack Kiara Softer",cat:"Jet Black Series",rh:24000,rm:48000,wy:18000,colors:["Jet Black"]},
  {sku:"GI-JFS",name:"Jetblack Fursan",cat:"Jet Black Series",rh:25000,rm:50000,wy:19000,colors:["Jet Black"]},
  {sku:"GI-JMB",name:"Jetblack Marbella",cat:"Jet Black Series",rh:26000,rm:52000,wy:20000,colors:["Jet Black"]},
  {sku:"GI-JWP",name:"Jetblack Woolpeach",cat:"Jet Black Series",rh:22500,rm:45000,wy:17000,colors:["Jet Black"]}
];

var HEX = {"Hitam":"#0B0B0B","Broken White":"#F2EBE0","Classic Maroon":"#5B1A1F","Burgundy":"#6B1F2C","Storm Blue":"#2C4A66","Deep Teal":"#1F4E5C","Urban Mist":"#9AA3A8","Deep Ash":"#5D6066","Cocoa Chestnut":"#6B3A22","Blush Mauve":"#C7A4A6","Warm Tan":"#B58965","Classic Taupe":"#8E7763","Coffee":"#5A3A24","Chocolate Brown":"#3E2418","Dusty Lavender":"#A493B4","Mystic Plum":"#5E3552","Ashen Berry":"#7B4256","Soft Mocha":"#8C6F5C","Twilight Navy":"#1B2A4E","Slate Blue":"#4A5F7A","Charcoal":"#2A2A2A","Fog Stone":"#A8A8A6","Grape Violet":"#5B2C6F","Dust Plum":"#6E4A65","Soft Petal":"#EAD0D4","Blush Petal":"#E8B6B6","Silver Mist":"#C7C9CC","Matcha Cream":"#C1C58F","Terracotta":"#B5573E","Nude Mahogany":"#9C6A5A","Burnt Mahogany":"#6E3A2D","Intense Mahogany":"#4A2218","Black":"#0A0A0A","Royal Navy":"#0F1E4B","Maroon":"#5C1A2A","Forest Deep":"#0E3B2E","Berry Blush":"#A45561","Rose Wood":"#7D4A4E","Sage Grey":"#9AA59A","Cloudy Blue":"#9EB1C6","Azure Calm":"#5B82A6","Deep Slate":"#3A4A5C","Vanilla Dust":"#E9DEC8","Caramel Nude":"#B98E66","Ivory":"#F4ECDD","Champagne":"#E3CFA6","Dusty Pink":"#D6A7AD","Sage Green":"#A8B5A2","Olive":"#6B6A2A","Mustard":"#C19A2C","Navy":"#1A2A52","Emerald":"#1F6E54","Forest Green":"#1F4D3A","Light Lime Green":"#B7D58A","Silver Pearl White":"#EDEAE0","Deep Blue":"#102B5C","Snow White":"#F8F6F0","Dark Maroon":"#3E0F18","Misty Purple":"#7E6E94","Ash Grey":"#8C8E92","Warm Mocha":"#7A5A45","Soft Broken White":"#F0E7D6","Warm Sand Beige":"#D4B894","Natural Nude":"#D9B89B","Cream Stone":"#E6D7BE","Cocoa Sand":"#A8825F","Khaki Clay":"#9C8255","Tiramisu Earth":"#7A5536","Ash Peach Clay":"#C28E76","Soft Peach Sand":"#E0B9A0","Desert Dune":"#C9A87C","Champagne Sand":"#D8B98A","Soft Almond":"#D9B894","Cocoa Mousse":"#7A5B45","Sage Laurel":"#7E8B6E","Graphite Ash":"#4A4A4A","Midnight Navy":"#0F172A","Onyx Black":"#0A0A0A","Rosewood Blush":"#8B5A5E","Jet Black":"#000000"};

var CATS = ["Semua","Premium Silk","Luxury Silk","Textured Premium","Breathable Fabric","Jet Black Series"];

/* ════════════════ STATE ════════════════ */
var KEY = "giandi_v3_2";
var S = {
  cart: load("cart", []),
  wishlist: load("wl", []),
  orders: load("orders", []),
  user: load("user", null),
  cat: "Semua",
  q: "",
  page: "home",
  pdp: {pi:0, vi:0, unit:"half", qty:1},
  co: {step:1, addr:{}, method:""}
};
function load(k, def){ try { return JSON.parse(localStorage.getItem(KEY+"_"+k)) || def; } catch(e){ return def; } }
function save(){ try {
  localStorage.setItem(KEY+"_cart", JSON.stringify(S.cart));
  localStorage.setItem(KEY+"_wl", JSON.stringify(S.wishlist));
  localStorage.setItem(KEY+"_orders", JSON.stringify(S.orders));
  localStorage.setItem(KEY+"_user", JSON.stringify(S.user));
} catch(e){} }

/* ════════════════ UTILS ════════════════ */
function $(s){ return document.querySelector(s); }
function $$(s){ return document.querySelectorAll(s); }
function fmt(n){ return "Rp"+Math.round(n).toLocaleString("id-ID"); }
function hex(c){ return HEX[c] || "#888"; }
function escape(s){ return String(s).replace(/[&<>"']/g, function(c){ return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]; }); }
function slug(s){ return s.replace(/[^A-Za-z0-9]/g,"").toUpperCase(); }
function priceFor(p, u){ if(u==="half") return p.rh; if(u==="meter") return p.rm; return p.wy; }
function unitLabel(u){ if(u==="half") return "0,5 m"; if(u==="meter") return "1 m"; return "1 yard"; }
function unitShort(u){ if(u==="half") return "0,5m"; if(u==="meter") return "m"; return "yd"; }
function cartTotal(){ var t=0; for(var i=0;i<S.cart.length;i++) t += S.cart[i].price * S.cart[i].qty; return t; }
function cartCount(){ var c=0; for(var i=0;i<S.cart.length;i++) c += S.cart[i].qty; return c; }

function toast(msg){
  var t = $("#toast");
  if(!t){
    t = document.createElement("div");
    t.id = "toast";
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.className = "on";
  clearTimeout(window._tt);
  window._tt = setTimeout(function(){ t.className = ""; }, 2400);
}

/* ════════════════ ROUTING ════════════════ */
function go(page, arg){
  S.page = page;
  if(page === "pdp") S.pdp = {pi: arg||0, vi:0, unit:"half", qty:1};
  if(page === "shop" && typeof arg === "string") S.cat = arg;
  render();
  window.scrollTo({top:0, behavior:"smooth"});
}
window.go = go;

/* ════════════════ RENDER ════════════════ */
function render(){
  var app = $("#app");
  var html = "";
  html += renderTopbar();
  if(S.page === "home") html += renderHome();
  else if(S.page === "shop") html += renderShop();
  else if(S.page === "pdp") html += renderPDP();
  else if(S.page === "cart") html += renderCart();
  else if(S.page === "checkout") html += renderCheckout();
  else if(S.page === "account") html += renderAccount();
  else if(S.page === "wholesale") html += renderWholesale();
  else if(S.page === "about") html += renderAbout();
  else html += renderHome();
  html += renderFooter();
  app.innerHTML = html;
  updateBadge();
}
function updateBadge(){
  var b = $("#cart-badge");
  if(b){
    var c = cartCount();
    b.textContent = c;
    b.style.display = c>0 ? "grid" : "none";
  }
}

/* ════════════════ TOPBAR ════════════════ */
function renderTopbar(){
  var nav = [
    {k:"home", l:"Beranda"},
    {k:"shop", l:"Koleksi"},
    {k:"wholesale", l:"Grosir"},
    {k:"about", l:"Tentang"}
  ];
  var navHtml = "";
  for(var i=0;i<nav.length;i++){
    var on = S.page === nav[i].k ? " on" : "";
    navHtml += '<a class="nav-link'+on+'" onclick="go(\''+nav[i].k+'\')">'+nav[i].l+'</a>';
  }
  return ''+
    '<header class="topbar">'+
      '<div class="tbar">'+
        '<div class="brand" onclick="go(\'home\')">'+
          '<div class="brand-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#C6A769" stroke-width="1.8" stroke-linecap="round"><path d="M4 8c4-4 8 0 16-4M4 14c4-4 8 0 16-4M4 20c4-4 8 0 16-4"/></svg></div>'+
          '<div class="brand-txt"><div class="brand-name">Giandi Textile</div><div class="brand-tag">Premium Fabric Atelier</div></div>'+
        '</div>'+
        '<nav class="nav">'+navHtml+'</nav>'+
        '<div class="tbar-actions">'+
          '<button class="ib" onclick="go(\'account\')" aria-label="Account"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7"/></svg></button>'+
          '<button class="ib cart-btn" onclick="openCart()" aria-label="Cart">'+
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M6 6h15l-2 9H8L6 4H3"/><circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/></svg>'+
            '<span class="badge" id="cart-badge">0</span>'+
          '</button>'+
        '</div>'+
      '</div>'+
    '</header>';
}

/* ════════════════ HOME ════════════════ */
function renderHome(){
  var f = PRODUCTS[0];
  var swHtml = "";
  for(var i=0;i<Math.min(8, f.colors.length);i++){
    swHtml += '<div style="background:'+hex(f.colors[i])+'"></div>';
  }
  var featured = [];
  for(var i=0;i<PRODUCTS.length;i++) featured.push(PRODUCTS[i]);
  featured = featured.slice(0, 8);

  var feats = [
    {t:"Premium Quality", d:"Setiap rol melewati QC internal — kerataan warna, kekuatan serat, finishing."},
    {t:"Ecer & Grosir", d:"Beli ecer mulai 0,5 meter atau grosir per yard untuk reseller."},
    {t:"WhatsApp Order", d:"Order langsung via WhatsApp dengan respon cepat dari tim sales."},
    {t:"Free Ongkir", d:"Gratis ongkir minimal pembelian Rp 500.000 untuk semua produk."}
  ];
  var featHtml = "";
  for(var i=0;i<feats.length;i++){
    featHtml += '<div class="feat-card"><h3>'+feats[i].t+'</h3><p>'+feats[i].d+'</p></div>';
  }

  return ''+
    '<section class="hero">'+
      '<div class="hero-grid">'+
        '<div class="hero-text">'+
          '<div class="hero-eb">Premium Silk · Est. 2018</div>'+
          '<h1 class="hero-h1">Kain Sutra Premium untuk Koleksi <em>Muslimah Modern</em></h1>'+
          '<p class="hero-p">Marbella · Maheen · Royanna · Golden Silk · Jetblack. Supplier kain premium untuk brand fashion, boutique, designer, dan reseller di seluruh Indonesia.</p>'+
          '<div class="hero-cta">'+
            '<button class="btn btn-rose" onclick="go(\'shop\')">Jelajahi Koleksi <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></button>'+
            '<button class="btn btn-outline" onclick="go(\'wholesale\')">Harga Grosir</button>'+
          '</div>'+
        '</div>'+
        '<div class="hero-vis">'+
          '<div class="fc">'+
            '<div class="fc-cat">'+f.cat+'</div>'+
            '<div class="fc-nm">'+f.name+'</div>'+
            '<div class="fc-sw">'+swHtml+'</div>'+
            '<div class="fc-pr"><span>Retail / m</span><b>'+fmt(f.rm)+'</b></div>'+
            '<div class="fc-pr"><span>Grosir / yard</span><b>'+fmt(f.wy)+'</b></div>'+
          '</div>'+
        '</div>'+
      '</div>'+
    '</section>'+
    '<section class="section">'+
      '<div class="section-head"><div><div class="eyebrow">Koleksi Pilihan</div><h2>Featured Products</h2></div><a class="link" onclick="go(\'shop\')">Lihat semua →</a></div>'+
      '<div class="grid">'+renderCards(featured)+'</div>'+
    '</section>'+
    '<section class="section">'+
      '<div style="text-align:center;margin-bottom:48px"><div class="eyebrow">Kenapa Giandi</div><h2 style="font-size:36px">Bukan sekadar kain. <em>Investasi koleksi.</em></h2></div>'+
      '<div class="feat-grid">'+featHtml+'</div>'+
    '</section>';
}

/* ════════════════ SHOP ════════════════ */
function renderShop(){
  var chips = "";
  for(var i=0;i<CATS.length;i++){
    var on = CATS[i]===S.cat ? " on" : "";
    chips += '<button class="chip'+on+'" onclick="setCat(\''+CATS[i]+'\')">'+CATS[i]+'</button>';
  }
  var items = [];
  for(var i=0;i<PRODUCTS.length;i++){
    var p = PRODUCTS[i];
    if(S.cat !== "Semua" && p.cat !== S.cat) continue;
    if(S.q){
      var q = S.q.toLowerCase();
      if(p.name.toLowerCase().indexOf(q)<0 && p.cat.toLowerCase().indexOf(q)<0) continue;
    }
    items.push(p);
  }
  var total = 0;
  for(var i=0;i<items.length;i++) total += items[i].colors.length;
  return ''+
    '<section class="container">'+
      '<div class="page-head"><div><div class="eyebrow">Catalog</div><h1>Seluruh Koleksi</h1><p class="page-sub">'+items.length+' produk · '+total+' varian warna</p></div></div>'+
      '<div class="chips">'+chips+'</div>'+
      '<div class="search-row"><input class="inp search-inp" placeholder="Cari produk..." value="'+escape(S.q)+'" oninput="setQ(this.value)" /></div>'+
      '<div class="grid">'+(items.length ? renderCards(items) : '<div class="empty">Tidak ada produk untuk filter ini.</div>')+'</div>'+
    '</section>';
}
window.setCat = function(c){ S.cat = c; render(); };
window.setQ = function(v){ S.q = v; render(); var inp = $(".search-inp"); if(inp){ inp.focus(); var len = inp.value.length; inp.setSelectionRange(len, len); } };

/* ════════════════ CARDS ════════════════ */
function renderCards(arr){
  var out = "";
  for(var i=0;i<arr.length;i++){
    var p = arr[i];
    var pi = PRODUCTS.indexOf(p);
    var c0 = p.colors[0];
    var c1 = p.colors[1] || c0;
    var swh = "";
    for(var j=0;j<Math.min(5, p.colors.length);j++){
      swh += '<div class="sw" style="background:'+hex(p.colors[j])+'"></div>';
    }
    var more = p.colors.length>5 ? '<span class="more">+'+(p.colors.length-5)+'</span>' : '';
    out += ''+
      '<div class="card" onclick="go(\'pdp\','+pi+')">'+
        '<div class="card-img" style="background:linear-gradient(135deg,'+hex(c0)+' 0%,'+hex(c1)+' 100%)">'+
          '<div class="card-lbl">'+p.cat+'</div>'+
          '<div class="card-ovl"></div>'+
          '<div class="card-swr">'+swh+more+'</div>'+
        '</div>'+
        '<div class="card-body">'+
          '<div class="card-cat">'+p.colors.length+' warna</div>'+
          '<div class="card-name">'+p.name+'</div>'+
          '<div class="card-sku">SKU '+p.sku+' · ★ 4.9</div>'+
          '<div class="card-prices">'+
            '<div class="card-pr"><b>'+fmt(p.rh)+'</b><small>/ 0,5 m</small></div>'+
            '<div class="card-pw">Grosir <b>'+fmt(p.wy)+'</b>/yd</div>'+
          '</div>'+
        '</div>'+
      '</div>';
  }
  return out;
}

/* ════════════════ PDP ════════════════ */
function renderPDP(){
  var p = PRODUCTS[S.pdp.pi];
  if(!p){ S.pdp.pi = 0; p = PRODUCTS[0]; }
  var c = p.colors[S.pdp.vi];
  var u = S.pdp.unit;
  var price = priceFor(p, u);
  var minQ = u === "yard" ? 5 : 1;
  if(S.pdp.qty < minQ) S.pdp.qty = minQ;

  var colorsHtml = "";
  for(var i=0;i<p.colors.length;i++){
    var on = i===S.pdp.vi ? " on" : "";
    colorsHtml += '<div class="color-opt'+on+'" onclick="setColor('+i+')" title="'+escape(p.colors[i])+'">'+
      '<div class="color-dot" style="background:'+hex(p.colors[i])+'"></div>'+
      '<div class="color-nm">'+escape(p.colors[i])+'</div>'+
    '</div>';
  }

  var thumbsHtml = "";
  for(var i=0;i<Math.min(5, p.colors.length);i++){
    var on = i===S.pdp.vi ? " on" : "";
    thumbsHtml += '<div class="thumb'+on+'" style="background:'+hex(p.colors[i])+'" onclick="setColor('+i+')"></div>';
  }

  var hintTxt = u === "yard" 
    ? '<b>Min. 5 yard / warna</b> · stok grosir terpisah · 1 yard ≈ 0,9144 m'
    : 'Ecer min. <b>0,5 m</b> per warna · stok retail terpisah';

  return ''+
    '<section class="container">'+
      '<div class="crumb"><a onclick="go(\'home\')">Beranda</a> / <a onclick="go(\'shop\')">Koleksi</a> / <span>'+escape(p.name)+'</span></div>'+
      '<div class="pdp">'+
        '<div class="pdp-imgs">'+
          '<div class="pdp-main" style="background:linear-gradient(135deg,'+hex(c)+'30,'+hex(c)+'10)">'+
            '<div class="pdp-swatch" style="background:'+hex(c)+'"></div>'+
          '</div>'+
          '<div class="pdp-thumbs">'+thumbsHtml+'</div>'+
        '</div>'+
        '<div class="pdp-info">'+
          '<div class="pdp-cat">'+p.cat+'</div>'+
          '<h1 class="pdp-name">'+p.name+'</h1>'+
          '<div class="pdp-rating"><span class="stars">★★★★★</span> 4.9 · <span>1.2k sold</span> · <span class="mono">'+p.sku+'-'+slug(c)+'</span></div>'+
          '<p class="pdp-desc">Kain premium '+p.name.toLowerCase()+' dengan '+p.colors.length+' pilihan warna dikurasi. Cocok untuk gamis syar\'i, dress, hijab segi empat, dan koleksi premium boutique. Lebar 150 cm, finishing soft handfeel, jatuh kain elegan.</p>'+
          '<div class="pbox">'+
            '<div class="utog">'+
              '<button class="'+(u==="half"?"on":"")+'" onclick="setUnit(\'half\')">Ecer 0,5 m</button>'+
              '<button class="'+(u==="meter"?"on":"")+'" onclick="setUnit(\'meter\')">Ecer 1 m</button>'+
              '<button class="'+(u==="yard"?"on":"")+'" onclick="setUnit(\'yard\')">Grosir / yard</button>'+
            '</div>'+
            '<div class="prow"><span>Harga '+unitLabel(u)+'</span><b>'+fmt(price)+'</b></div>'+
            '<div class="hint">'+hintTxt+'</div>'+
          '</div>'+
          '<div class="lbl-row"><div class="lbl">Warna · '+p.colors.length+' pilihan</div><span class="lbl-sel">'+escape(c)+'</span></div>'+
          '<div class="colors">'+colorsHtml+'</div>'+
          '<div class="qty-row">'+
            '<div class="stp">'+
              '<button onclick="changeQty(-1)">−</button>'+
              '<input value="'+S.pdp.qty+'" onchange="setQty(this.value)" />'+
              '<button onclick="changeQty(1)">+</button>'+
            '</div>'+
            '<div class="stk">● Stok tersedia</div>'+
          '</div>'+
          '<div class="cta-row">'+
            '<button class="btn btn-outline" onclick="addCart()">Tambah ke Keranjang</button>'+
            '<button class="btn btn-primary" onclick="buyNow()">Beli Sekarang</button>'+
          '</div>'+
          '<button class="btn-wa" onclick="waOrder()">'+
            '<svg viewBox="0 0 24 24" width="18" height="18" fill="#fff"><path d="M17.5 14.4c-.3-.1-1.7-.8-2-.9-.3-.1-.5-.1-.7.1-.2.3-.7.9-.9 1.1-.2.2-.3.2-.6.1-.3-.2-1.2-.5-2.4-1.5-.9-.8-1.5-1.8-1.6-2.1-.2-.3 0-.5.1-.6.1-.1.3-.3.4-.5.1-.1.2-.3.2-.4.1-.2.1-.3 0-.5-.1-.1-.7-1.6-.9-2.2-.2-.6-.4-.5-.6-.5h-.5c-.2 0-.5.1-.7.3-.3.3-1 1-1 2.4 0 1.4 1 2.8 1.2 3 .1.1 2 3.1 5 4.4.7.3 1.2.5 1.7.6.7.2 1.4.2 1.9.1.6-.1 1.7-.7 2-1.4.2-.7.2-1.2.2-1.4z"/></svg>'+
            ' Order via WhatsApp'+
          '</button>'+
          '<div class="specs">'+
            '<div class="spec-r"><span>Komposisi</span><span>Premium silk blend</span></div>'+
            '<div class="spec-r"><span>Lebar Kain</span><span>150 cm</span></div>'+
            '<div class="spec-r"><span>Berat</span><span>±200 g/m</span></div>'+
            '<div class="spec-r"><span>Perawatan</span><span>Hand wash / dry clean</span></div>'+
            '<div class="spec-r"><span>Origin</span><span>Indonesia</span></div>'+
          '</div>'+
        '</div>'+
      '</div>'+
    '</section>';
}
window.setColor = function(i){ S.pdp.vi = i; render(); };
window.setUnit = function(u){ S.pdp.unit = u; S.pdp.qty = u==="yard" ? 5 : 1; render(); };
window.changeQty = function(d){ var minQ = S.pdp.unit==="yard"?5:1; S.pdp.qty = Math.max(minQ, S.pdp.qty + d); render(); };
window.setQty = function(v){ var minQ = S.pdp.unit==="yard"?5:1; S.pdp.qty = Math.max(minQ, parseInt(v)||minQ); render(); };

window.addCart = function(){
  var p = PRODUCTS[S.pdp.pi];
  var c = p.colors[S.pdp.vi];
  var u = S.pdp.unit;
  var k = p.sku + "-" + slug(c) + "-" + u;
  var ex = null;
  for(var i=0;i<S.cart.length;i++){ if(S.cart[i].k===k){ ex = S.cart[i]; break; } }
  if(ex){ ex.qty += S.pdp.qty; }
  else {
    S.cart.push({
      k: k, sku: p.sku, name: p.name, color: c,
      hex: hex(c), unit: u, unitLabel: unitLabel(u),
      qty: S.pdp.qty, price: priceFor(p, u)
    });
  }
  save();
  updateBadge();
  toast("✓ " + p.name + " — " + c + " ditambahkan");
};
window.buyNow = function(){ addCart(); go("checkout"); };
window.waOrder = function(){
  var p = PRODUCTS[S.pdp.pi];
  var c = p.colors[S.pdp.vi];
  var msg = "Halo Giandi Textile, saya tertarik:\n\n*" + p.name + "*\nWarna: " + c + "\nQty: " + S.pdp.qty + " " + unitLabel(S.pdp.unit) + "\nTotal: " + fmt(priceFor(p, S.pdp.unit) * S.pdp.qty) + "\n\nMasih tersedia?";
  window.open("https://wa.me/6281234567890?text=" + encodeURIComponent(msg), "_blank");
};

/* ════════════════ CART DRAWER ════════════════ */
window.openCart = function(){
  var html = '';
  if(!S.cart.length){
    html = '<div class="empty-cart"><svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="#94A3B8" stroke-width="1.2"><path d="M6 6h15l-2 9H8L6 4H3"/></svg><h3>Keranjang kosong</h3><p>Pilih kain favorit Anda dari koleksi premium.</p><button class="btn btn-primary" onclick="closeCart();go(\'shop\')">Lihat Koleksi</button></div>';
    $("#cart-body").innerHTML = html;
    $("#cart-foot").innerHTML = '';
  } else {
    for(var i=0;i<S.cart.length;i++){
      var ci = S.cart[i];
      html += ''+
        '<div class="cart-row">'+
          '<div class="cart-thumb" style="background:'+ci.hex+'"></div>'+
          '<div class="cart-info">'+
            '<div class="cart-nm">'+escape(ci.name)+'</div>'+
            '<div class="cart-mt">'+escape(ci.color)+' · '+ci.unitLabel+'</div>'+
            '<div class="cart-qty">'+
              '<button onclick="cartQty('+i+',-1)">−</button>'+
              '<span>'+ci.qty+'</span>'+
              '<button onclick="cartQty('+i+',1)">+</button>'+
            '</div>'+
          '</div>'+
          '<div class="cart-right">'+
            '<div class="cart-pr">'+fmt(ci.price*ci.qty)+'</div>'+
            '<button class="cart-rm" onclick="rmCart('+i+')">Hapus</button>'+
          '</div>'+
        '</div>';
    }
    $("#cart-body").innerHTML = html;
    var t = cartTotal();
    $("#cart-foot").innerHTML = ''+
      '<div class="cart-sub"><span>Subtotal ('+cartCount()+' item)</span><b>'+fmt(t)+'</b></div>'+
      '<button class="btn btn-primary cart-checkout" onclick="closeCart();go(\'checkout\')">Lanjut ke Checkout →</button>';
  }
  $("#drawer").classList.add("on");
  $("#drawer-bg").classList.add("on");
};
window.closeCart = function(){
  $("#drawer").classList.remove("on");
  $("#drawer-bg").classList.remove("on");
};
window.cartQty = function(i, d){
  var minQ = S.cart[i].unit === "yard" ? 5 : 1;
  S.cart[i].qty = Math.max(minQ, S.cart[i].qty + d);
  save(); updateBadge(); openCart();
};
window.rmCart = function(i){
  S.cart.splice(i, 1);
  save(); updateBadge(); openCart();
};

/* ════════════════ CART PAGE ════════════════ */
function renderCart(){
  if(!S.cart.length){
    return '<section class="container"><div class="page-head"><div><div class="eyebrow">Cart</div><h1>Keranjang Belanja</h1></div></div><div class="empty"><h3>Keranjang masih kosong</h3><p>Jelajahi koleksi kain premium Giandi Textile.</p><button class="btn btn-primary" onclick="go(\'shop\')">Lihat Koleksi</button></div></section>';
  }
  var rows = '';
  for(var i=0;i<S.cart.length;i++){
    var ci = S.cart[i];
    rows += ''+
      '<div class="cp-row">'+
        '<div class="cp-thumb" style="background:'+ci.hex+'"></div>'+
        '<div class="cp-info">'+
          '<div class="cp-nm">'+escape(ci.name)+'</div>'+
          '<div class="cp-mt">'+escape(ci.color)+' · '+ci.unitLabel+' · '+ci.sku+'</div>'+
          '<div class="stp" style="margin-top:10px;display:inline-flex">'+
            '<button onclick="cartQtyPage('+i+',-1)">−</button>'+
            '<input value="'+ci.qty+'" readonly />'+
            '<button onclick="cartQtyPage('+i+',1)">+</button>'+
          '</div>'+
        '</div>'+
        '<div class="cp-prices">'+
          '<div class="cp-pr">'+fmt(ci.price*ci.qty)+'</div>'+
          '<div class="cp-unit">'+fmt(ci.price)+' / '+ci.unitLabel+'</div>'+
        '</div>'+
        '<button class="cp-rm" onclick="rmCartPage('+i+')">×</button>'+
      '</div>';
  }
  var sub = cartTotal();
  var ship = sub > 500000 ? 0 : 25000;
  return ''+
    '<section class="container">'+
      '<div class="page-head"><div><div class="eyebrow">Cart</div><h1>Keranjang Belanja</h1></div></div>'+
      '<div class="cart-grid">'+
        '<div class="cp-items">'+rows+'</div>'+
        '<aside class="cart-summary">'+
          '<h3>Ringkasan Pesanan</h3>'+
          '<div class="cs-r"><span>Subtotal</span><b>'+fmt(sub)+'</b></div>'+
          '<div class="cs-r"><span>Pengiriman</span><b>'+(ship?fmt(ship):"GRATIS")+'</b></div>'+
          '<div class="cs-r total"><span>Total</span><b>'+fmt(sub+ship)+'</b></div>'+
          '<button class="btn btn-primary full" onclick="go(\'checkout\')">Checkout · '+fmt(sub+ship)+'</button>'+
          '<p class="cs-note">Pembayaran via Midtrans · QRIS · VA · Card</p>'+
        '</aside>'+
      '</div>'+
    '</section>';
}
window.cartQtyPage = function(i,d){ var minQ=S.cart[i].unit==="yard"?5:1; S.cart[i].qty=Math.max(minQ,S.cart[i].qty+d); save(); render(); };
window.rmCartPage = function(i){ S.cart.splice(i,1); save(); render(); };

/* ════════════════ CHECKOUT ════════════════ */
function renderCheckout(){
  if(!S.cart.length){ go("shop"); return ""; }
  var s = S.co.step;
  var sub = cartTotal();
  var ship = sub > 500000 ? 0 : 25000;
  var total = sub + ship;

  var stepHtml = ''+
    '<div class="steps">'+
      '<div class="step '+(s>=1?(s===1?"on":"done"):"")+'"><span>1</span> Pengiriman</div>'+
      '<div class="step '+(s>=2?(s===2?"on":"done"):"")+'"><span>2</span> Pembayaran</div>'+
      '<div class="step '+(s>=3?"on":"")+'"><span>3</span> Konfirmasi</div>'+
    '</div>';

  var formHtml = "";
  if(s===1){
    var a = S.co.addr;
    formHtml = ''+
      '<h3>Informasi Pengiriman</h3>'+
      '<div class="fr two"><div><label>Nama Lengkap *</label><input class="inp" id="co-n" value="'+escape(a.name||"")+'"/></div><div><label>No. WhatsApp *</label><input class="inp" id="co-p" value="'+escape(a.phone||"")+'"/></div></div>'+
      '<div class="fr"><div><label>Email</label><input class="inp" type="email" id="co-e" value="'+escape(a.email||"")+'"/></div></div>'+
      '<div class="fr"><div><label>Alamat Lengkap *</label><textarea class="inp" id="co-a" rows="3">'+escape(a.addr||"")+'</textarea></div></div>'+
      '<div class="fr two"><div><label>Kota *</label><input class="inp" id="co-c" value="'+escape(a.city||"")+'"/></div><div><label>Kode Pos</label><input class="inp" id="co-z" value="'+escape(a.zip||"")+'"/></div></div>'+
      '<div class="fr two"><div><label>Provinsi</label><input class="inp" id="co-pr" value="'+escape(a.prov||"")+'"/></div><div><label>Kurir</label><select class="inp" id="co-k"><option>JNE Reguler</option><option>JNE YES</option><option>J&T Express</option><option>SiCepat</option><option>AnterAja</option></select></div></div>'+
      '<button class="btn btn-primary full" onclick="coNext()">Lanjut ke Pembayaran →</button>';
  } else if(s===2){
    var methods = [
      {k:"qris", i:"QR", n:"QRIS", d:"GoPay, OVO, Dana, ShopeePay, M-Banking"},
      {k:"va_bca", i:"BCA", n:"BCA Virtual Account", d:"Transfer otomatis terverifikasi"},
      {k:"va_mandiri", i:"M", n:"Mandiri VA", d:"ATM, Livin\', M-Banking"},
      {k:"va_bni", i:"BNI", n:"BNI Virtual Account", d:"ATM, Wondr, M-Banking"},
      {k:"va_bri", i:"BRI", n:"BRI Virtual Account", d:"ATM, BRImo, M-Banking"},
      {k:"cc", i:"CC", n:"Kartu Kredit/Debit", d:"Visa, Mastercard, JCB · 3DS"},
      {k:"gopay", i:"Go", n:"GoPay", d:"Scan via Gojek"},
      {k:"shopeepay", i:"SP", n:"ShopeePay", d:"Scan via Shopee"}
    ];
    var ms = "";
    for(var i=0;i<methods.length;i++){
      var m = methods[i];
      var on = S.co.method===m.k ? " on" : "";
      ms += ''+
        '<div class="pm'+on+'" onclick="setMethod(\''+m.k+'\')">'+
          '<div class="pm-ic">'+m.i+'</div>'+
          '<div class="pm-txt"><b>'+m.n+'</b><p>'+m.d+'</p></div>'+
          '<div class="pm-radio">'+(S.co.method===m.k?'●':'○')+'</div>'+
        '</div>';
    }
    formHtml = ''+
      '<h3>Pilih Metode Pembayaran</h3>'+
      ms+
      '<div class="form-actions"><button class="btn btn-outline" onclick="coBack()">← Kembali</button><button class="btn btn-primary" '+(!S.co.method?'disabled':'')+' onclick="placeOrder()">Bayar Sekarang · '+fmt(total)+'</button></div>';
  }

  var items = "";
  for(var i=0;i<S.cart.length;i++){
    var ci = S.cart[i];
    items += ''+
      '<div class="co-item">'+
        '<div class="co-thumb" style="background:'+ci.hex+'"></div>'+
        '<div class="co-info"><div class="co-nm">'+escape(ci.name)+'</div><div class="co-mt">'+escape(ci.color)+' · '+ci.qty+'× '+ci.unitLabel+'</div></div>'+
        '<div class="co-pr">'+fmt(ci.price*ci.qty)+'</div>'+
      '</div>';
  }

  return ''+
    '<section class="container narrow">'+
      '<div class="page-head"><div><div class="eyebrow">Checkout</div><h1>Selesaikan Pesanan</h1></div></div>'+
      stepHtml+
      '<div class="co-grid">'+
        '<div class="form-box">'+formHtml+'</div>'+
        '<aside class="cart-summary">'+
          '<h3>Ringkasan</h3>'+
          items+
          '<div class="cs-r"><span>Subtotal</span><b>'+fmt(sub)+'</b></div>'+
          '<div class="cs-r"><span>Ongkir</span><b>'+(ship?fmt(ship):"GRATIS")+'</b></div>'+
          '<div class="cs-r total"><span>Total</span><b>'+fmt(total)+'</b></div>'+
        '</aside>'+
      '</div>'+
    '</section>';
}
window.coNext = function(){
  S.co.addr = {
    name: $("#co-n").value,
    phone: $("#co-p").value,
    email: ($("#co-e")||{}).value || "",
    addr: $("#co-a").value,
    city: $("#co-c").value,
    zip: ($("#co-z")||{}).value || "",
    prov: ($("#co-pr")||{}).value || "",
    courier: ($("#co-k")||{}).value || "JNE Reguler"
  };
  if(!S.co.addr.name || !S.co.addr.phone || !S.co.addr.addr || !S.co.addr.city){
    toast("Lengkapi data: nama, HP, alamat, kota");
    return;
  }
  S.co.step = 2; render();
};
window.coBack = function(){ S.co.step = 1; render(); };
window.setMethod = function(m){ S.co.method = m; render(); };
window.placeOrder = function(){
  if(!S.co.method){ toast("Pilih metode pembayaran"); return; }
  var sub = cartTotal();
  var ship = sub > 500000 ? 0 : 25000;
  var order = {
    id: "GD-" + new Date().toISOString().slice(2,10).replace(/-/g,"") + "-" + Math.random().toString(36).slice(2,8).toUpperCase(),
    placed_at: new Date().toISOString(),
    status: "pending_payment",
    items: S.cart.slice(),
    address: Object.assign({}, S.co.addr),
    method: S.co.method,
    subtotal: sub, shipping: ship, total: sub+ship
  };
  // Try API
  fetch("/api/orders", {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({
      customer: {name:order.address.name, phone:order.address.phone, email:order.address.email},
      items: order.items.map(function(i){ return {sku:i.sku, product_name:i.name, color_name:i.color, unit:i.unit, qty:i.qty, unit_price:i.price}; }),
      shipping: {cost: ship, courier: order.address.courier, address: order.address.addr, city: order.address.city, postal_code: order.address.zip, province: order.address.prov},
      channel: "website"
    })
  }).then(function(r){return r.json();}).then(function(d){
    if(d.order_no) order.id = d.order_no;
    if(d.payment && d.payment.snap_token) order.snap_token = d.payment.snap_token;
    finalizeOrder(order);
  }).catch(function(){ finalizeOrder(order); });
};
function finalizeOrder(order){
  S.orders.unshift(order);
  S.cart = [];
  S.co = {step:1, addr:{}, method:""};
  save(); updateBadge();
  showOrderConfirm(order);
}
function showOrderConfirm(order){
  var html = ''+
    '<div class="modal-content">'+
      '<div class="check-circle"><svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="#0F766E" stroke-width="2.5" stroke-linecap="round"><path d="M5 12l5 5 9-11"/></svg></div>'+
      '<h2>Pesanan Berhasil!</h2>'+
      '<p>Order ID: <b class="mono">'+order.id+'</b></p>'+
      '<div class="confirm-box">'+
        '<div class="confirm-l">INSTRUKSI PEMBAYARAN</div>'+
        '<p>Metode: <b>'+order.method.toUpperCase()+'</b><br>Total: <b style="font-size:18px">'+fmt(order.total)+'</b></p>'+
        '<p class="confirm-note">'+(order.snap_token ? 'Anda akan diarahkan ke Midtrans Snap.' : 'Pembayaran diproses. Pantau email & WhatsApp.')+'</p>'+
      '</div>'+
      '<button class="btn btn-primary full" onclick="closeModal();go(\'account\')">Lihat Pesanan Saya</button>'+
    '</div>';
  $("#modal-content").innerHTML = html;
  $("#modal").classList.add("on");

  // If Midtrans snap_token present, open Snap.js
  if(order.snap_token && window.snap){
    window.snap.pay(order.snap_token, {
      onSuccess: function(){ toast("Pembayaran berhasil!"); },
      onPending: function(){ toast("Menunggu pembayaran..."); },
      onError:   function(){ toast("Pembayaran gagal."); },
      onClose:   function(){}
    });
  }
}
window.closeModal = function(){ $("#modal").classList.remove("on"); };

/* ════════════════ ACCOUNT ════════════════ */
function renderAccount(){
  if(!S.user){
    return ''+
      '<section class="container narrow">'+
        '<div class="page-head"><div><div class="eyebrow">My Account</div><h1>Masuk / Daftar</h1></div></div>'+
        '<div class="auth-grid">'+
          '<div class="form-box">'+
            '<h3>Masuk</h3>'+
            '<div class="fr"><div><label>Email atau No. HP</label><input class="inp" id="li-id"/></div></div>'+
            '<div class="fr"><div><label>Password</label><input type="password" class="inp" id="li-pw"/></div></div>'+
            '<button class="btn btn-primary full" onclick="signin()">Masuk</button>'+
            '<p class="auth-hint">Demo: <b>customer@giandi.id</b> / <b>any</b></p>'+
          '</div>'+
          '<div class="form-box dark">'+
            '<h3>Bergabung dengan Giandi</h3>'+
            '<p class="auth-sub">Dapatkan harga member, akses lookbook eksklusif, dan voucher khusus.</p>'+
            '<div class="fr"><div><label>Nama</label><input class="inp" id="su-n"/></div></div>'+
            '<div class="fr"><div><label>No. WhatsApp</label><input class="inp" id="su-p"/></div></div>'+
            '<button class="btn btn-rose full" onclick="signup()">Daftar Sekarang</button>'+
          '</div>'+
        '</div>'+
      '</section>';
  }
  var u = S.user;
  var my = [];
  for(var i=0;i<S.orders.length;i++){
    var o = S.orders[i];
    if(o.address.phone===u.phone || o.address.email===u.email) my.push(o);
  }
  var spent = 0;
  for(var i=0;i<my.length;i++) spent += my[i].total;
  var tier = my.length>=10?"VIP":my.length>=3?"Loyal":"New";

  var rows = "";
  if(my.length){
    rows = '<table><thead><tr><th>Order</th><th>Tanggal</th><th>Item</th><th>Total</th><th>Status</th></tr></thead><tbody>';
    for(var i=0;i<my.length;i++){
      var o = my[i];
      rows += '<tr><td class="mono">'+o.id+'</td><td>'+new Date(o.placed_at).toLocaleDateString("id-ID")+'</td><td>'+o.items.length+' item</td><td>'+fmt(o.total)+'</td><td><span class="pill">'+o.status+'</span></td></tr>';
    }
    rows += '</tbody></table>';
  } else {
    rows = '<div class="empty">Belum ada pesanan</div>';
  }

  return ''+
    '<section class="container">'+
      '<div class="page-head"><div><div class="eyebrow">My Account</div><h1>Halo, '+escape(u.name)+'</h1></div></div>'+
      '<div class="acc-grid">'+
        '<aside class="acc-side">'+
          '<div class="acc-avatar">'+u.name.charAt(0).toUpperCase()+'</div>'+
          '<div class="acc-nm">'+escape(u.name)+'</div>'+
          '<div class="acc-info">'+(u.phone||u.email)+'</div>'+
          '<hr/>'+
          '<button class="btn btn-outline full" onclick="signout()">Keluar</button>'+
        '</aside>'+
        '<div>'+
          '<div class="kpi-grid">'+
            '<div class="kpi"><div class="kpi-l">Total Pesanan</div><div class="kpi-v">'+my.length+'</div></div>'+
            '<div class="kpi"><div class="kpi-l">Total Belanja</div><div class="kpi-v">'+fmt(spent)+'</div></div>'+
            '<div class="kpi"><div class="kpi-l">Tier</div><div class="kpi-v" style="color:#C6A769">'+tier+'</div></div>'+
          '</div>'+
          '<div class="table-wrap"><div class="table-head"><h3>Riwayat Pesanan</h3></div>'+rows+'</div>'+
        '</div>'+
      '</div>'+
    '</section>';
}
window.signin = function(){
  var id = $("#li-id").value, pw = $("#li-pw").value;
  if(!id || !pw){ toast("Lengkapi email/HP dan password"); return; }
  var name = id.indexOf("@")>0 ? id.split("@")[0] : id;
  S.user = {name: name, email: id.indexOf("@")>0?id:"", phone: id.indexOf("@")<0?id:""};
  save(); toast("✓ Berhasil masuk"); render();
};
window.signup = function(){
  var n = $("#su-n").value, p = $("#su-p").value;
  if(!n || !p){ toast("Lengkapi nama dan no. WhatsApp"); return; }
  S.user = {name:n, phone:p, email:""};
  save(); toast("✓ Akun berhasil dibuat"); render();
};
window.signout = function(){ S.user = null; save(); render(); };

/* ════════════════ WHOLESALE ════════════════ */
function renderWholesale(){
  var rows = '';
  for(var i=0;i<PRODUCTS.length;i++){
    var p = PRODUCTS[i];
    rows += '<tr><td><b>'+escape(p.name)+'</b><br><span class="mono muted">'+p.sku+'</span></td><td>'+p.cat+'</td><td>'+p.colors.length+' pilihan</td><td class="ta-r"><b>'+fmt(p.wy)+'</b></td></tr>';
  }
  return ''+
    '<section class="container narrow">'+
      '<div class="page-head"><div><div class="eyebrow">B2B</div><h1>Pricelist Grosir</h1><p class="page-sub">Harga per yard untuk reseller, boutique, dan garment. Min. order 5 yard per warna.</p></div></div>'+
      '<div class="table-wrap"><div class="table-head"><h3>Pricelist Grosir (per yard)</h3><span class="pill">Min. 5 yard/warna</span></div>'+
        '<table><thead><tr><th>Produk</th><th>Kategori</th><th>Warna</th><th class="ta-r">Per Yard</th></tr></thead><tbody>'+rows+'</tbody></table>'+
      '</div>'+
      '<div class="info-box">'+
        '<h3>Cara Order Grosir</h3>'+
        '<ol><li>Hubungi tim grosir via WhatsApp dengan list produk dan warna.</li><li>Tim sales mengirim quotation dan ketersediaan stok grosir.</li><li>Konfirmasi order — DP 50% via VA/transfer.</li><li>Pelunasan sebelum pengiriman via JNE Trucking/cargo.</li></ol>'+
        '<button class="btn btn-rose" onclick="window.open(\'https://wa.me/6281234567890?text=Halo%20Giandi%2C%20konsultasi%20grosir\',\'_blank\')">Chat Tim Grosir</button>'+
      '</div>'+
    '</section>';
}

/* ════════════════ ABOUT ════════════════ */
function renderAbout(){
  return ''+
    '<section class="container narrow">'+
      '<div class="page-head"><div><div class="eyebrow">Our Story</div><h1>Tentang Giandi Textile</h1></div></div>'+
      '<div class="about-body">'+
        '<p><b>Giandi Textile</b> adalah supplier kain premium berfokus pada Muslimah dan syar\'i fashion. Bermula dari kecintaan terhadap kualitas serat dan jatuh kain, kami menyediakan koleksi sutra premium yang dikurasi untuk brand fashion, boutique, designer, tailor, dan end consumer di seluruh Indonesia.</p>'+
        '<p>Setiap rol kain melewati standar quality control internal — dari kerataan warna, kekuatan serat, hingga finishing — agar setiap produk akhir yang dibuat dari kain Giandi memiliki karakter premium yang konsisten.</p>'+
        '<p>Saat ini kami melayani <b>5000+ reseller aktif</b>, <b>120+ boutique partner</b>, dan distribusi ke seluruh Indonesia melalui Website, WhatsApp Business, Shopee, TikTok Shop, dan Lazada.</p>'+
      '</div>'+
    '</section>';
}

/* ════════════════ FOOTER ════════════════ */
function renderFooter(){
  return ''+
    '<footer>'+
      '<div class="fg">'+
        '<div class="fb"><h3>Giandi Textile</h3><p>Premium fabric supplier untuk Muslimah dan syar\'i fashion.</p></div>'+
        '<div class="fc2"><h5>Belanja</h5><a onclick="go(\'shop\')">Semua Produk</a><a onclick="go(\'wholesale\')">Grosir</a></div>'+
        '<div class="fc2"><h5>Bantuan</h5><a>FAQ</a><a>Pengiriman</a><a>Retur</a><a>Hubungi Kami</a></div>'+
        '<div class="fc2"><h5>Connect</h5><a>WhatsApp</a><a>Instagram</a><a>TikTok</a><a>Shopee</a></div>'+
      '</div>'+
      '<div class="fcp"><div>© 2026 Giandi Textile. All rights reserved.</div><div>gianditextile.com</div></div>'+
    '</footer>';
}

/* ════════════════ INIT ════════════════ */
if(document.readyState === "loading"){
  document.addEventListener("DOMContentLoaded", render);
} else {
  render();
}

})();
