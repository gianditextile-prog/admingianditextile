/* ═══════ GIANDI ADMIN — MASTER DATA ═══════ */
/* Real product catalog + Real orders + Real customers extracted from operational data */

window.GIANDI_PRODUCTS = [
  {sku:"GI-MSP",name:"Marbella Silk Prestige",cat:"Premium Silk",rh:27500,rm:55000,wy:20000,cost:14000,active:true,width:"150 cm",weight:"200 g/m",composition:"Premium silk blend",care:"Hand wash / dry clean",desc:"Kain sutra premium signature Giandi dengan finishing soft handfeel dan jatuh kain elegan. Cocok untuk gamis syar'i, dress, hijab segi empat, dan koleksi premium boutique. Telah digunakan oleh 5000+ reseller dan 120+ boutique partner.",colors:["Hitam","Broken White","Classic Maroon","Burgundy","Storm Blue","Deep Teal","Urban Mist","Deep Ash","Cocoa Chestnut","Blush Mauve","Warm Tan","Classic Taupe","Coffee","Chocolate Brown","Dusty Lavender","Mystic Plum","Ashen Berry","Soft Mocha","Twilight Navy","Slate Blue","Charcoal","Fog Stone","Grape Violet","Dust Plum","Soft Petal","Blush Petal","Silver Mist","Matcha Cream","Terracotta","Nude Mahogany","Burnt Mahogany","Intense Mahogany"]},
  {sku:"GI-MSL",name:"Marbella Silk Luxe",cat:"Premium Silk",rh:32500,rm:65000,wy:25000,cost:17000,active:true,width:"150 cm",weight:"220 g/m",composition:"Luxe silk blend",care:"Hand wash / dry clean",desc:"Versi luxe dari koleksi Marbella dengan serat lebih halus, ketebalan premium, dan jatuh kain mewah. Pilihan utama untuk koleksi bridal dan formal.",colors:["Black","Royal Navy","Maroon","Forest Deep","Berry Blush","Rose Wood","Sage Grey","Cloudy Blue","Azure Calm","Deep Slate","Vanilla Dust","Caramel Nude"]},
  {sku:"GI-MSPM",name:"Marbella Silk Premium",cat:"Premium Silk",rh:37500,rm:75000,wy:30000,cost:19000,active:true,width:"150 cm",weight:"240 g/m",composition:"Top-tier silk blend",care:"Dry clean only",desc:"Top-tier Marbella series — handfeel dan drape kelas atelier. Pilihan untuk designer dan haute couture.",colors:["Ivory","Champagne","Dusty Pink","Sage Green","Olive","Terracotta","Mustard","Navy","Emerald"]},
  {sku:"GI-GS",name:"Golden Silk",cat:"Luxury Silk",rh:30000,rm:60000,wy:23000,cost:15500,active:true,width:"150 cm",weight:"210 g/m",composition:"Golden silk blend",care:"Hand wash / dry clean",desc:"Kain sutra dengan kilau khas emas, finishing premium untuk koleksi luxury dan special occasions.",colors:["Forest Green","Light Lime Green","Silver Pearl White"]},
  {sku:"GI-RSU",name:"Royanna Silk UV",cat:"Luxury Silk",rh:31000,rm:62000,wy:24000,cost:16000,active:true,width:"150 cm",weight:"215 g/m",composition:"UV-protected silk",care:"Hand wash / dry clean",desc:"Sutra UV protection dengan warna deep, finishing soft, dan ketahanan terhadap sinar matahari. Cocok untuk gamis outdoor.",colors:["Deep Blue","Snow White","Dark Maroon","Burgundy","Misty Purple","Deep Teal","Ash Grey","Warm Mocha"]},
  {sku:"GI-MHP",name:"Maheen Prive",cat:"Textured Premium",rh:34000,rm:68000,wy:28000,cost:17500,active:true,width:"148 cm",weight:"230 g/m",composition:"Textured premium silk",care:"Hand wash cold",desc:"Kain bertekstur premium dengan handle lembut, ideal untuk gamis modern dan dress dengan struktur halus.",colors:["Soft Broken White","Warm Sand Beige","Natural Nude","Cream Stone","Cocoa Sand","Khaki Clay","Tiramisu Earth","Ash Peach Clay","Soft Peach Sand"]},
  {sku:"GI-CUP",name:"Cupro",cat:"Breathable Fabric",rh:36000,rm:72000,wy:29000,cost:18000,active:true,width:"150 cm",weight:"195 g/m",composition:"Cupro fiber",care:"Hand wash / dry clean",desc:"Kain breathable premium dengan jatuh natural, ideal untuk iklim tropis. Daya serap keringat tinggi.",colors:["Desert Dune","Champagne Sand","Soft Almond","Cocoa Mousse","Sage Laurel","Graphite Ash","Midnight Navy","Onyx Black","Rosewood Blush"]},
  {sku:"GI-JKS",name:"Jetblack Kiara Softer",cat:"Jet Black Series",rh:24000,rm:48000,wy:18000,cost:11500,active:true,width:"150 cm",weight:"180 g/m",composition:"Soft black blend",care:"Machine wash gentle",desc:"Series black murni dengan finishing softer untuk handfeel lembut. Daily-wear quality.",colors:["Jet Black"]},
  {sku:"GI-JFS",name:"Jetblack Fursan",cat:"Jet Black Series",rh:25000,rm:50000,wy:19000,cost:12000,active:true,width:"150 cm",weight:"200 g/m",composition:"Structured black blend",care:"Machine wash gentle",desc:"Series black formal dengan struktur tegas, ideal untuk gamis syari'i formal.",colors:["Jet Black"]},
  {sku:"GI-JMB",name:"Jetblack Marbella",cat:"Jet Black Series",rh:26000,rm:52000,wy:20000,cost:12500,active:true,width:"150 cm",weight:"210 g/m",composition:"Premium black silk",care:"Hand wash",desc:"Marbella signature dalam jet black murni. Premium quality dengan jatuh kain elegan.",colors:["Jet Black"]},
  {sku:"GI-JWP",name:"Jetblack Woolpeach",cat:"Jet Black Series",rh:22500,rm:45000,wy:17000,cost:10500,active:true,width:"150 cm",weight:"190 g/m",composition:"Woolpeach blend",care:"Machine wash gentle",desc:"Woolpeach hangat dalam jet black, cocok untuk gamis musim hujan dan iklim sejuk.",colors:["Jet Black"]}
];

window.GIANDI_HEX = {"Hitam":"#0B0B0B","Broken White":"#F2EBE0","Classic Maroon":"#5B1A1F","Burgundy":"#6B1F2C","Storm Blue":"#2C4A66","Deep Teal":"#1F4E5C","Urban Mist":"#9AA3A8","Deep Ash":"#5D6066","Cocoa Chestnut":"#6B3A22","Blush Mauve":"#C7A4A6","Warm Tan":"#B58965","Classic Taupe":"#8E7763","Coffee":"#5A3A24","Chocolate Brown":"#3E2418","Dusty Lavender":"#A493B4","Mystic Plum":"#5E3552","Ashen Berry":"#7B4256","Soft Mocha":"#8C6F5C","Twilight Navy":"#1B2A4E","Slate Blue":"#4A5F7A","Charcoal":"#2A2A2A","Fog Stone":"#A8A8A6","Grape Violet":"#5B2C6F","Dust Plum":"#6E4A65","Soft Petal":"#EAD0D4","Blush Petal":"#E8B6B6","Silver Mist":"#C7C9CC","Matcha Cream":"#C1C58F","Terracotta":"#B5573E","Nude Mahogany":"#9C6A5A","Burnt Mahogany":"#6E3A2D","Intense Mahogany":"#4A2218","Black":"#0A0A0A","Royal Navy":"#0F1E4B","Maroon":"#5C1A2A","Forest Deep":"#0E3B2E","Berry Blush":"#A45561","Rose Wood":"#7D4A4E","Sage Grey":"#9AA59A","Cloudy Blue":"#9EB1C6","Azure Calm":"#5B82A6","Deep Slate":"#3A4A5C","Vanilla Dust":"#E9DEC8","Caramel Nude":"#B98E66","Ivory":"#F4ECDD","Champagne":"#E3CFA6","Dusty Pink":"#D6A7AD","Sage Green":"#A8B5A2","Olive":"#6B6A2A","Mustard":"#C19A2C","Navy":"#1A2A52","Emerald":"#1F6E54","Forest Green":"#1F4D3A","Light Lime Green":"#B7D58A","Silver Pearl White":"#EDEAE0","Deep Blue":"#102B5C","Snow White":"#F8F6F0","Dark Maroon":"#3E0F18","Misty Purple":"#7E6E94","Ash Grey":"#8C8E92","Warm Mocha":"#7A5A45","Soft Broken White":"#F0E7D6","Warm Sand Beige":"#D4B894","Natural Nude":"#D9B89B","Cream Stone":"#E6D7BE","Cocoa Sand":"#A8825F","Khaki Clay":"#9C8255","Tiramisu Earth":"#7A5536","Ash Peach Clay":"#C28E76","Soft Peach Sand":"#E0B9A0","Desert Dune":"#C9A87C","Champagne Sand":"#D8B98A","Soft Almond":"#D9B894","Cocoa Mousse":"#7A5B45","Sage Laurel":"#7E8B6E","Graphite Ash":"#4A4A4A","Midnight Navy":"#0F172A","Onyx Black":"#0A0A0A","Rosewood Blush":"#8B5A5E","Jet Black":"#000000"};

/* ═══════ REAL ORDERS DATA ═══════ */
window.GIANDI_ORDERS = [
  {id:"GI-2604-001",no:"#347",ch:"whatsapp",cust:"Ibu Nani",phone:"081328559191",addr:"Lingsar barat, gerung selatan, lombok barat",date:"2026-04-08",status:"completed",total:5802500,items:[{sku:"GI-MSP",p:"Marbella Silk Prestige",c:"Soft Mocha",qty:67,u:"yard",pr:21500},{sku:"GI-MSP",p:"Marbella Silk Prestige",c:"Blush Petal",qty:68,u:"yard",pr:21500},{sku:"GI-MSP",p:"Marbella Silk Prestige",c:"Burgundy",qty:20,u:"meter",pr:29000},{sku:"GI-MSP",p:"Marbella Silk Prestige",c:"Dusty Lavender",qty:20,u:"meter",pr:29000}]},
  {id:"GI-2604-002",no:"#348",ch:"whatsapp",cust:"Mahiza Indonesia",phone:"6289532140577",addr:"Jl. H Siun 2D No.40, Ceger, Cipayung, Jakarta Timur",date:"2026-04-08",status:"completed",total:12480000,items:[{sku:"GI-MHP",p:"Maheen Prive",c:"Khaki Clay",qty:176,u:"yard",pr:30000},{sku:"GI-MHP",p:"Maheen Prive",c:"Cocoa Sand",qty:120,u:"yard",pr:30000},{sku:"GI-MHP",p:"Maheen Prive",c:"Soft Peach Sand",qty:120,u:"yard",pr:30000}]},
  {id:"GI-2604-003",no:"#349",ch:"whatsapp",cust:"Ihda Asna",phone:"6281226600094",addr:"Kober gg riswan, purwokerto barat, banyumas",date:"2026-04-13",status:"completed",total:810000,items:[{sku:"GI-MHP",p:"Maheen Prive",c:"Khaki Clay",qty:3,u:"meter",pr:45000},{sku:"GI-MHP",p:"Maheen Prive",c:"Natural Nude",qty:3,u:"meter",pr:45000}]},
  {id:"GI-2604-004",no:"#351",ch:"whatsapp",cust:"Ummu Salma",phone:"628966213199",addr:"Jl randusari timur, antapani, Bandung",date:"2026-04-14",status:"completed",total:1665000,items:[{sku:"GI-JKS",p:"Jetblack Kiara Softer",c:"Jet Black",qty:37,u:"meter",pr:45000}]},
  {id:"GI-2604-005",no:"#352",ch:"whatsapp",cust:"Novianti RJA",phone:"628966213199",addr:"RJA perintis, Jl.perintis kemerdekaan KM 8, Makassar",date:"2026-04-14",status:"completed",total:29400000,items:[{sku:"GI-MSP",p:"Marbella Silk Prestige",c:"Twilight Navy",qty:350,u:"yard",pr:21000},{sku:"GI-MSP",p:"Marbella Silk Prestige",c:"Classic Taupe",qty:350,u:"yard",pr:21000},{sku:"GI-MSP",p:"Marbella Silk Prestige",c:"Burnt Mahogany",qty:350,u:"yard",pr:21000},{sku:"GI-MSP",p:"Marbella Silk Prestige",c:"Mystic Plum",qty:350,u:"yard",pr:21000}]},
  {id:"GI-2604-006",no:"#353",ch:"whatsapp",cust:"Zakhira Konveksi",phone:"6281280521675",addr:"Perum.HBTB Jl.Anantakupa Raya, Cimanggis Depok",date:"2026-04-14",status:"completed",total:2687500,items:[{sku:"GI-MSP",p:"Marbella Silk Prestige",c:"Soft Mocha",qty:65,u:"yard",pr:21500},{sku:"GI-MSP",p:"Marbella Silk Prestige",c:"Burnt Mahogany",qty:60,u:"yard",pr:21500}]},
  {id:"GI-2604-007",no:"SPX-4823901",ch:"shopee",cust:"sari_textile88",phone:"085722013412",addr:"Jakarta Selatan",date:"2026-04-12",status:"shipped",total:165000,items:[{sku:"GI-MSP",p:"Marbella Silk Prestige",c:"Storm Blue",qty:3,u:"meter",pr:55000}]},
  {id:"GI-2604-008",no:"SPX-4823902",ch:"shopee",cust:"hijab_collection_id",phone:"081245678910",addr:"Surabaya",date:"2026-04-12",status:"completed",total:325000,items:[{sku:"GI-MSL",p:"Marbella Silk Luxe",c:"Royal Navy",qty:5,u:"meter",pr:65000}]},
  {id:"GI-2604-009",no:"TT-9128371",ch:"tiktok",cust:"@hijabmodest",phone:"088012345678",addr:"Bandung",date:"2026-04-13",status:"completed",total:480000,items:[{sku:"GI-MHP",p:"Maheen Prive",c:"Natural Nude",qty:8,u:"meter",pr:60000}]},
  {id:"GI-2604-010",no:"LZD-7283910",ch:"lazada",cust:"premium.fabrics",phone:"081345678912",addr:"Medan",date:"2026-04-14",status:"processing",total:550000,items:[{sku:"GI-CUP",p:"Cupro",c:"Champagne Sand",qty:10,u:"meter",pr:55000}]},
  {id:"GI-2605-011",no:"#354",ch:"whatsapp",cust:"Bunda Fatimah",phone:"6281234567823",addr:"Jl. Asia Afrika, Bandung",date:"2026-05-02",status:"completed",total:3450000,items:[{sku:"GI-RSU",p:"Royanna Silk UV",c:"Deep Blue",qty:50,u:"yard",pr:24000},{sku:"GI-RSU",p:"Royanna Silk UV",c:"Snow White",qty:50,u:"yard",pr:24000}]},
  {id:"GI-2605-012",no:"#355",ch:"whatsapp",cust:"Hijab Modesta",phone:"6281987654321",addr:"Cipete, Jakarta Selatan",date:"2026-05-05",status:"completed",total:7500000,items:[{sku:"GI-MSPM",p:"Marbella Silk Premium",c:"Champagne",qty:100,u:"yard",pr:30000},{sku:"GI-MSPM",p:"Marbella Silk Premium",c:"Ivory",qty:150,u:"yard",pr:30000}]},
  {id:"GI-2605-013",no:"SPX-4823920",ch:"shopee",cust:"butik_aulia",phone:"082134567890",addr:"Yogyakarta",date:"2026-05-08",status:"completed",total:275000,items:[{sku:"GI-JMB",p:"Jetblack Marbella",c:"Jet Black",qty:5,u:"meter",pr:52000}]},
  {id:"GI-2605-014",no:"TT-9128390",ch:"tiktok",cust:"@kainpremium",phone:"088123456789",addr:"Semarang",date:"2026-05-10",status:"shipped",total:840000,items:[{sku:"GI-GS",p:"Golden Silk",c:"Forest Green",qty:14,u:"meter",pr:60000}]},
  {id:"GI-2605-015",no:"#356",ch:"whatsapp",cust:"Tika Konveksi",phone:"6281355678901",addr:"Tasikmalaya",date:"2026-05-12",status:"processing",total:4200000,items:[{sku:"GI-MSL",p:"Marbella Silk Luxe",c:"Berry Blush",qty:60,u:"yard",pr:25000},{sku:"GI-MSL",p:"Marbella Silk Luxe",c:"Forest Deep",qty:60,u:"yard",pr:25000}]},
  {id:"GI-2605-016",no:"#357",ch:"whatsapp",cust:"Aisyah Hijab",phone:"6281445566778",addr:"Solo, Jawa Tengah",date:"2026-05-13",status:"completed",total:1100000,items:[{sku:"GI-JFS",p:"Jetblack Fursan",c:"Jet Black",qty:22,u:"meter",pr:50000}]},
  {id:"GI-2605-017",no:"LZD-7283930",ch:"lazada",cust:"silk_supplier_id",phone:"081567890123",addr:"Palembang",date:"2026-05-14",status:"completed",total:660000,items:[{sku:"GI-MSP",p:"Marbella Silk Prestige",c:"Charcoal",qty:12,u:"meter",pr:55000}]},
  {id:"GI-2605-018",no:"#358",ch:"whatsapp",cust:"Ratu Konveksi Bali",phone:"6281678901234",addr:"Denpasar, Bali",date:"2026-05-16",status:"shipped",total:6900000,items:[{sku:"GI-MSP",p:"Marbella Silk Prestige",c:"Twilight Navy",qty:150,u:"yard",pr:23000},{sku:"GI-MSP",p:"Marbella Silk Prestige",c:"Coffee",qty:150,u:"yard",pr:23000}]}
];

window.GIANDI_CUSTOMERS = [
  {id:"C-001",name:"Mahiza Indonesia",phone:"6289532140577",email:"mahiza@boutique.id",city:"Jakarta Timur",tier:"VIP",orders:12,spent:148500000,since:"2023-03-15"},
  {id:"C-002",name:"Novianti RJA",phone:"628966213199",email:"novianti@rjafashion.id",city:"Makassar",tier:"VIP",orders:8,spent:215000000,since:"2023-08-22"},
  {id:"C-003",name:"Ibu Nani",phone:"081328559191",email:"",city:"Lombok Barat",tier:"Loyal",orders:6,spent:32400000,since:"2024-01-10"},
  {id:"C-004",name:"Zakhira Konveksi",phone:"6281280521675",email:"zakhira.konveksi@gmail.com",city:"Depok",tier:"Loyal",orders:5,spent:18750000,since:"2024-02-18"},
  {id:"C-005",name:"Hijab Modesta",phone:"6281987654321",email:"modesta@hijab.id",city:"Jakarta Selatan",tier:"Loyal",orders:4,spent:24500000,since:"2024-04-05"},
  {id:"C-006",name:"Ratu Konveksi Bali",phone:"6281678901234",email:"ratu.konveksi@gmail.com",city:"Denpasar",tier:"VIP",orders:7,spent:48200000,since:"2023-11-30"},
  {id:"C-007",name:"Tika Konveksi",phone:"6281355678901",email:"",city:"Tasikmalaya",tier:"Loyal",orders:3,spent:12600000,since:"2024-09-12"},
  {id:"C-008",name:"Bunda Fatimah",phone:"6281234567823",email:"fatimah.hijab@gmail.com",city:"Bandung",tier:"Loyal",orders:4,spent:14800000,since:"2024-07-20"},
  {id:"C-009",name:"Ummu Salma",phone:"628966213199",email:"",city:"Bandung",tier:"New",orders:2,spent:3200000,since:"2025-12-01"},
  {id:"C-010",name:"Aisyah Hijab",phone:"6281445566778",email:"aisyah.hijab@gmail.com",city:"Solo",tier:"Loyal",orders:3,spent:8400000,since:"2024-11-15"},
  {id:"C-011",name:"Ihda Asna",phone:"6281226600094",email:"",city:"Banyumas",tier:"New",orders:1,spent:810000,since:"2026-04-13"},
  {id:"C-012",name:"sari_textile88",phone:"085722013412",email:"sari.textile88@shopee.id",city:"Jakarta Selatan",tier:"New",orders:2,spent:425000,since:"2026-03-20"},
  {id:"C-013",name:"hijab_collection_id",phone:"081245678910",email:"hijab.collection@shopee.id",city:"Surabaya",tier:"New",orders:3,spent:1250000,since:"2026-02-10"},
  {id:"C-014",name:"@hijabmodest",phone:"088012345678",email:"hijabmodest@tiktok",city:"Bandung",tier:"Loyal",orders:5,spent:3800000,since:"2025-08-05"},
  {id:"C-015",name:"premium.fabrics",phone:"081345678912",email:"premium.fabrics@lazada.id",city:"Medan",tier:"New",orders:1,spent:550000,since:"2026-04-14"}
];

window.GIANDI_STORE = {
  brand_name:"Giandi Textile",
  brand_tag:"Premium Fabric Atelier",
  brand_about:"Giandi Textile adalah supplier kain premium berfokus pada Muslimah dan syar'i fashion. Bermula dari kecintaan terhadap kualitas serat dan jatuh kain, kami menyediakan koleksi sutra premium yang dikurasi untuk brand fashion, boutique, designer, tailor, dan end consumer di seluruh Indonesia. Saat ini kami melayani 5000+ reseller aktif, 120+ boutique partner, dan distribusi ke seluruh Indonesia.",
  hero_slides:[
    {type:"image",eyebrow:"Premium Silk · Est. 2018",title:"Kain Sutra Premium untuk Koleksi Muslimah Modern",subtitle:"Marbella · Maheen · Royanna · Golden Silk · Jetblack. Supplier kain premium untuk brand fashion, boutique, designer, dan reseller di seluruh Indonesia.",cta_primary:"Jelajahi Koleksi",cta_primary_link:"/shop",cta_secondary:"Harga Grosir",cta_secondary_link:"/wholesale",image:"",video:"",overlay:0.4,active:true},
    {type:"image",eyebrow:"New Arrivals · Spring 2026",title:"Marbella Silk Prestige · 32 Pilihan Warna",subtitle:"Koleksi signature dengan 32 warna terkurasi. Ecer mulai 0,5 meter, grosir dari 5 yard per warna.",cta_primary:"Lihat Koleksi",cta_primary_link:"/shop?cat=Premium+Silk",cta_secondary:"",cta_secondary_link:"",image:"",video:"",overlay:0.5,active:true},
    {type:"image",eyebrow:"For Boutique Partner",title:"Program Wholesale Eksklusif",subtitle:"Harga khusus, akses prioritas warna baru, dan dedicated sales support untuk boutique partner Giandi.",cta_primary:"Bergabung",cta_primary_link:"/wholesale",cta_secondary:"Pelajari",cta_secondary_link:"/about",image:"",video:"",overlay:0.6,active:false}
  ],
  collections:[
    {name:"Premium Silk",desc:"Marbella series — sutra premium signature",image:"",products:["GI-MSP","GI-MSL","GI-MSPM"],featured:true},
    {name:"Luxury Silk",desc:"Golden & Royanna — kelas haute couture",image:"",products:["GI-GS","GI-RSU"],featured:true},
    {name:"Textured Premium",desc:"Maheen Prive — tekstur signature",image:"",products:["GI-MHP"],featured:true},
    {name:"Breathable Fabric",desc:"Cupro — premium tropical",image:"",products:["GI-CUP"],featured:false},
    {name:"Jet Black Series",desc:"Pure black collection",image:"",products:["GI-JKS","GI-JFS","GI-JMB","GI-JWP"],featured:true}
  ],
  contact:{
    whatsapp:"6281234567890",
    email:"hello@gianditextile.com",
    instagram:"@gianditextile",
    address:"Bogor, Jawa Barat, Indonesia"
  },
  business_rules:{
    free_shipping_min:500000,
    retail_min_meter:0.5,
    wholesale_min_yard:5
  },
  theme:{
    primary:"#0F172A",
    accent:"#C6A769",
    bg:"#FBF8F3",
    font_heading:"Fraunces",
    font_body:"Inter"
  },
  seo:{
    title:"Giandi Textile — Premium Fabric Atelier",
    description:"Supplier kain premium untuk Muslimah & syar'i fashion. Marbella · Maheen · Royanna · Golden Silk · Jetblack.",
    og_image:""
  }
};

window.GIANDI_VOUCHERS = [
  {id:"V001",code:"WELCOME15",type:"percent",value:15,min:300000,max:50000,uses:142,limit:500,expires:"2026-06-30",active:true,desc:"15% off untuk pelanggan baru"},
  {id:"V002",code:"GROSIR50K",type:"fixed",value:50000,min:1000000,max:50000,uses:48,limit:200,expires:"2026-06-15",active:true,desc:"Diskon Rp 50.000 grosir min. 1jt"},
  {id:"V003",code:"BUNDLE10",type:"percent",value:10,min:500000,max:100000,uses:89,limit:300,expires:"2026-05-31",active:true,desc:"10% off bundling 5+ warna"},
  {id:"V004",code:"RAMADAN26",type:"percent",value:20,min:200000,max:80000,uses:524,limit:1000,expires:"2026-04-30",active:false,desc:"Promo Ramadan 20% off"}
];

window.GIANDI_CAMPAIGNS = [
  {id:"CMP-001",name:"Marbella Silk Awareness",platform:"meta",status:"running",budget:5000000,spent:3240000,impressions:142800,clicks:4280,conversions:48,roas:3.8,start:"2026-04-15",end:"2026-05-31"},
  {id:"CMP-002",name:"Wholesale Boutique Targeting",platform:"meta",status:"running",budget:8000000,spent:5680000,impressions:84200,clicks:1920,conversions:32,roas:5.2,start:"2026-04-01",end:"2026-06-30"},
  {id:"CMP-003",name:"TikTok Shop Promo",platform:"tiktok",status:"running",budget:3000000,spent:1840000,impressions:285400,clicks:6840,conversions:78,roas:2.9,start:"2026-04-20",end:"2026-05-31"},
  {id:"CMP-004",name:"Ramadan Sale 2026",platform:"meta",status:"completed",budget:12000000,spent:11820000,impressions:520400,clicks:18920,conversions:412,roas:4.6,start:"2026-02-15",end:"2026-04-30"}
];
