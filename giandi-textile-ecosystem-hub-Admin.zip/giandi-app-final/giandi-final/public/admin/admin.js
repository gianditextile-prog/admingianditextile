/* ═══════════════ GIANDI ADMIN CENTER · v1.0 ═══════════════ */
/* World-class admin platform for premium fabric marketplace      */
(function(){
'use strict';

/* ═════ STATE ═════ */
var KEY = "giandi_admin_v1";

function load(k, d){ 
  try{ var v = localStorage.getItem(KEY+"_"+k); return v ? JSON.parse(v) : d; }
  catch(e){ return d; }
}
function persist(){
  try{
    localStorage.setItem(KEY+"_products", JSON.stringify(S.products));
    localStorage.setItem(KEY+"_hex", JSON.stringify(S.hex));
    localStorage.setItem(KEY+"_store", JSON.stringify(S.store));
    localStorage.setItem(KEY+"_stock", JSON.stringify(S.stock));
    localStorage.setItem(KEY+"_orders", JSON.stringify(S.orders));
    localStorage.setItem(KEY+"_customers", JSON.stringify(S.customers));
    localStorage.setItem(KEY+"_vouchers", JSON.stringify(S.vouchers));
    localStorage.setItem(KEY+"_campaigns", JSON.stringify(S.campaigns));
    localStorage.setItem(KEY+"_media", JSON.stringify(S.media));
  }catch(e){ console.warn("persist failed:", e); }
}

var S = {
  page: load("last_page", "dashboard"),
  products: load("products", window.GIANDI_PRODUCTS),
  hex: load("hex", window.GIANDI_HEX),
  store: load("store", window.GIANDI_STORE),
  orders: load("orders", window.GIANDI_ORDERS),
  customers: load("customers", window.GIANDI_CUSTOMERS),
  vouchers: load("vouchers", window.GIANDI_VOUCHERS),
  campaigns: load("campaigns", window.GIANDI_CAMPAIGNS),
  stock: load("stock", {}),
  media: load("media", []),
  q: "",
  filter_cat: "",
  filter_status: "",
  edit_pi: null,
  edit_tab: "general",
  edit_buf: null,
  edit_var_search: ""
};

function initStock(){
  for(var i=0;i<S.products.length;i++){
    var p = S.products[i];
    for(var j=0;j<p.colors.length;j++){
      var k = p.sku + ":" + p.colors[j];
      if(!S.stock[k]) S.stock[k] = { retail: 80+Math.floor(Math.random()*120), wholesale: 20+Math.floor(Math.random()*60) };
    }
  }
}
initStock();

/* ═════ UTILS ═════ */
function $(s){ return document.querySelector(s); }
function $$(s){ return Array.from(document.querySelectorAll(s)); }
function fmt(n){ return "Rp "+Math.round(n||0).toLocaleString("id-ID"); }
function fmtK(n){
  n = n||0;
  if(n >= 1000000000) return "Rp "+(n/1000000000).toFixed(1).replace(/\.0$/,"")+"M";
  if(n >= 1000000) return "Rp "+(n/1000000).toFixed(1).replace(/\.0$/,"")+"jt";
  if(n >= 1000) return "Rp "+(n/1000).toFixed(0)+"K";
  return "Rp "+n;
}
function fmtNum(n){ return (n||0).toLocaleString("id-ID"); }
function esc(s){ return String(s==null?"":s).replace(/[&<>"']/g, function(c){ return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]; }); }
function hex(c){ return S.hex[c] || "#888888"; }
function dateFmt(d){ try{ return new Date(d).toLocaleDateString("id-ID",{day:"numeric",month:"short",year:"numeric"}); }catch(e){ return d; } }
function totalStock(p){
  var t = 0;
  for(var i=0;i<p.colors.length;i++){
    var s = S.stock[p.sku+":"+p.colors[i]] || {};
    t += (s.retail||0) + (s.wholesale||0);
  }
  return t;
}

function toast(msg, type){
  var t = $("#toast");
  var icon;
  if(type === "error") icon = '<svg viewBox="0 0 24 24" fill="none" stroke="#FCA5A5" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>';
  else if(type === "info") icon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>';
  else icon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12l5 5 9-11"/></svg>';
  t.innerHTML = icon + '<span>' + esc(msg) + '</span>';
  t.classList.add("on");
  clearTimeout(window._tt);
  window._tt = setTimeout(function(){ t.classList.remove("on"); }, 2600);
}

function openModal(html){
  $("#modal-content").innerHTML = html;
  $("#modal").classList.add("on");
}
window.closeModal = function(){ $("#modal").classList.remove("on"); };

/* ═════ NAV ═════ */
var NAV = [
  {grp:"Overview", items:[
    {k:"dashboard", n:"Dashboard", i:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>'},
    {k:"analytics", n:"Analytics", i:'<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>'}
  ]},
  {grp:"Katalog", items:[
    {k:"products", n:"Produk", c:"prods", i:'<path d="M16 11a4 4 0 0 1-8 0M3 9l1.5 11a2 2 0 0 0 2 1.7h11a2 2 0 0 0 2-1.7L21 9z"/><path d="M3 9 6 3h12l3 6"/>'},
    {k:"variants", n:"Varian Warna", c:"vars", i:'<circle cx="13.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="10.5" r="2.5"/><circle cx="8.5" cy="7.5" r="2.5"/><circle cx="6.5" cy="12.5" r="2.5"/>'},
    {k:"inventory", n:"Inventaris", i:'<rect x="2" y="7" width="20" height="5"/><rect x="4" y="12" width="16" height="9"/><path d="M10 12v9M14 12v9"/>'},
    {k:"media", n:"Media Library", i:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/>'}
  ]},
  {grp:"Operasional", items:[
    {k:"orders", n:"Pesanan", c:"orders", i:'<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/><path d="M9 12h6M9 16h6"/>'},
    {k:"channels", n:"Channel", i:'<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>'},
    {k:"customers", n:"Pelanggan", c:"custs", i:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>'},
    {k:"shipping", n:"Pengiriman", i:'<rect x="1" y="3" width="15" height="13" rx="1"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/>'},
    {k:"finance", n:"Keuangan", i:'<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>'}
  ]},
  {grp:"Marketing", items:[
    {k:"campaigns", n:"Kampanye Iklan", i:'<path d="M3 11l18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>'},
    {k:"vouchers", n:"Voucher", i:'<path d="M21 5v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M9 9v.01M15 15v.01"/><path d="m9 15 6-6"/>'},
    {k:"flashsale", n:"Flash Sale", i:'<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>'}
  ]},
  {grp:"Toko", items:[
    {k:"storefront", n:"Hero Banner", i:'<path d="M3 9h18l-2 12H5L3 9z"/><path d="M3 9V6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v3"/>'},
    {k:"collections", n:"Koleksi", i:'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>'},
    {k:"brand", n:"Brand & Theme", i:'<circle cx="13.5" cy="6.5" r="1.5"/><circle cx="17.5" cy="10.5" r="1.5"/><circle cx="8.5" cy="7.5" r="1.5"/><circle cx="6.5" cy="12.5" r="1.5"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/>'}
  ]},
  {grp:"Pengaturan", items:[
    {k:"team", n:"Tim & Akses", i:'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>'},
    {k:"integrations", n:"Integrasi", i:'<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>'},
    {k:"settings", n:"Pengaturan", i:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>'}
  ]}
];

function renderNav(){
  var html = "";
  for(var g=0;g<NAV.length;g++){
    html += '<div class="sb-grp">' + NAV[g].grp + '</div>';
    for(var i=0;i<NAV[g].items.length;i++){
      var it = NAV[g].items[i];
      var on = it.k === S.page ? " on" : "";
      var cnt = "";
      if(it.c === "prods") cnt = '<span class="sb-cnt">'+S.products.length+'</span>';
      else if(it.c === "vars"){
        var n=0; for(var x=0;x<S.products.length;x++) n += S.products[x].colors.length;
        cnt = '<span class="sb-cnt">'+n+'</span>';
      }
      else if(it.c === "orders"){
        var n=0; for(var x=0;x<S.orders.length;x++) if(S.orders[x].status==="processing") n++;
        if(n>0) cnt = '<span class="sb-cnt">'+n+'</span>';
      }
      else if(it.c === "custs") cnt = '<span class="sb-cnt">'+S.customers.length+'</span>';
      html += '<button class="sb-it'+on+'" onclick="go(\''+it.k+'\')">'+
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor">'+it.i+'</svg>'+
        '<span>'+it.n+'</span>'+cnt+'</button>';
    }
  }
  $("#sidenav").innerHTML = html;
}

function setCrumb(parts){
  var html = "";
  for(var i=0;i<parts.length;i++){
    if(i>0) html += '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>';
    html += i===parts.length-1 ? '<b>'+esc(parts[i])+'</b>' : '<span>'+esc(parts[i])+'</span>';
  }
  $("#crumb").innerHTML = html;
}

window.go = function(p){
  S.page = p;
  S.q = "";
  S.filter_cat = "";
  S.filter_status = "";
  try{ localStorage.setItem(KEY+"_last_page", JSON.stringify(p)); }catch(e){}
  renderNav();
  render();
  window.scrollTo({top:0,behavior:"smooth"});
};
window.signOut = function(){
  if(confirm("Keluar dari Admin Center?")){
    toast("Sampai jumpa, Giandi!");
    setTimeout(function(){ window.location.href = "/"; }, 800);
  }
};
window.globalSearch = function(q){
  if(!q) return;
  toast("Mencari: " + q);
  S.q = q;
  go("products");
};

/* ═════ DASHBOARD ═════ */
function pageDashboard(){
  setCrumb(["Admin","Dashboard"]);
  var revenue = 0, ordCount = S.orders.length;
  var revenueLast = 0;
  var thisMonth = new Date().getMonth();
  for(var i=0;i<S.orders.length;i++){
    var d = new Date(S.orders[i].date);
    if(d.getMonth() === thisMonth) revenue += S.orders[i].total;
    else if(d.getMonth() === thisMonth-1) revenueLast += S.orders[i].total;
  }
  if(revenue===0) revenue = 78420000;
  if(revenueLast===0) revenueLast = 62100000;
  var growth = revenueLast ? Math.round(((revenue-revenueLast)/revenueLast)*100) : 0;
  var aov = ordCount ? Math.round(revenue/ordCount) : 0;
  var custActive = S.customers.filter(function(c){return c.orders>0;}).length;

  // Stock alerts
  var lowStock = 0, outStock = 0, totalVars = 0;
  for(var i=0;i<S.products.length;i++){
    var p = S.products[i];
    totalVars += p.colors.length;
    for(var j=0;j<p.colors.length;j++){
      var s = S.stock[p.sku+":"+p.colors[j]] || {};
      var t = (s.retail||0)+(s.wholesale||0);
      if(t===0) outStock++;
      else if(t<30) lowStock++;
    }
  }

  // Recent orders
  var recent = S.orders.slice().sort(function(a,b){return new Date(b.date)-new Date(a.date);}).slice(0,6);

  // Top products by revenue (compute)
  var prodRev = {};
  for(var i=0;i<S.orders.length;i++){
    var o = S.orders[i];
    for(var j=0;j<o.items.length;j++){
      var it = o.items[j];
      prodRev[it.sku] = (prodRev[it.sku]||0) + (it.pr*it.qty);
    }
  }
  var topProds = S.products.slice().sort(function(a,b){return (prodRev[b.sku]||0) - (prodRev[a.sku]||0);}).slice(0,5);

  // Sales by channel
  var byChannel = {whatsapp:0, shopee:0, tiktok:0, lazada:0};
  for(var i=0;i<S.orders.length;i++){
    if(byChannel[S.orders[i].ch] !== undefined) byChannel[S.orders[i].ch] += S.orders[i].total;
  }

  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Overview</div>'+
        '<h1 class="page-title">Selamat datang kembali, Giandi.</h1>'+
        '<p class="page-sub">Ringkasan performa toko Anda hari ini, '+new Date().toLocaleDateString("id-ID",{weekday:"long",day:"numeric",month:"long",year:"numeric"})+'.</p>'+
      '</div>'+
      '<div class="page-actions">'+
        '<button class="btn btn-outline" onclick="exportData()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Export Data</button>'+
        '<button class="btn btn-primary" onclick="newProduct()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 5v14M5 12h14"/></svg> Tambah Produk</button>'+
      '</div>'+
    '</div>'+
    '<div class="kpi-row">'+
      '<div class="kpi"><div class="kpi-lbl">Pendapatan Bulan Ini</div><div class="kpi-val">'+fmtK(revenue)+'</div><div class="kpi-trend '+(growth>=0?"up":"down")+'">'+(growth>=0?"↑":"↓")+' '+Math.abs(growth)+"% vs bulan lalu"+'</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Total Pesanan</div><div class="kpi-val">'+ordCount+'</div><div class="kpi-sub">'+S.orders.filter(function(o){return o.status==="processing";}).length+' menunggu proses</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Pelanggan Aktif</div><div class="kpi-val">'+custActive+'</div><div class="kpi-sub">'+S.customers.filter(function(c){return c.tier==="VIP";}).length+' VIP · '+S.customers.filter(function(c){return c.tier==="Loyal";}).length+' Loyal</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Nilai Rata-rata Order</div><div class="kpi-val">'+fmtK(aov)+'</div><div class="kpi-trend up">↑ 4,2% vs bulan lalu</div></div>'+
    '</div>'+
    '<div style="display:grid;grid-template-columns:1.4fr 1fr;gap:20px;margin-bottom:20px">'+
      '<div class="card">'+
        '<div class="card-head"><div><h3>Pesanan Terbaru</h3><div class="card-head-sub">'+recent.length+' pesanan terbaru dari semua channel</div></div><button class="btn btn-ghost btn-sm" onclick="go(\'orders\')">Lihat Semua →</button></div>'+
        '<div class="card-body" style="padding:0"><div class="table-wrap"><table>'+
          '<thead><tr><th>Order</th><th>Pelanggan</th><th>Channel</th><th class="ta-r">Total</th><th>Status</th></tr></thead>'+
          '<tbody>' + recent.map(function(o){
            var statusColor = o.status==="completed"?"pill-ok":o.status==="shipped"?"pill-info":"pill-warn";
            var statusLbl = o.status==="completed"?"Selesai":o.status==="shipped"?"Dikirim":o.status==="processing"?"Diproses":o.status;
            return '<tr style="cursor:pointer" onclick="openOrder(\''+o.id+'\')">'+
              '<td><div class="mono" style="font-weight:600;color:var(--navy)">'+esc(o.no)+'</div><div style="font-size:10px;color:var(--ink-3);margin-top:2px">'+dateFmt(o.date)+'</div></td>'+
              '<td><div style="font-size:13px;color:var(--navy);font-weight:500">'+esc(o.cust)+'</div><div style="font-size:10px;color:var(--ink-3);margin-top:2px">'+esc(o.phone)+'</div></td>'+
              '<td><span class="pill pill-mute">'+channelLabel(o.ch)+'</span></td>'+
              '<td class="ta-r td-emph">'+fmtK(o.total)+'</td>'+
              '<td><span class="pill '+statusColor+'"><span class="pill-dot"></span>'+statusLbl+'</span></td>'+
            '</tr>';
          }).join('') + '</tbody>'+
        '</table></div></div>'+
      '</div>'+
      '<div class="card">'+
        '<div class="card-head"><h3>Status Stok</h3></div>'+
        '<div class="card-body">'+
          '<div style="display:flex;gap:10px;margin-bottom:18px">'+
            '<div style="flex:1;background:var(--ok-bg);border-radius:10px;padding:14px"><div style="font-size:10px;color:var(--ok);font-weight:600;text-transform:uppercase;letter-spacing:.08em">Aman</div><div style="font-family:var(--serif);font-size:22px;font-weight:600;color:var(--navy);margin-top:2px">'+(totalVars-lowStock-outStock)+'</div></div>'+
            '<div style="flex:1;background:var(--warn-bg);border-radius:10px;padding:14px"><div style="font-size:10px;color:var(--warn);font-weight:600;text-transform:uppercase;letter-spacing:.08em">Menipis</div><div style="font-family:var(--serif);font-size:22px;font-weight:600;color:var(--navy);margin-top:2px">'+lowStock+'</div></div>'+
            '<div style="flex:1;background:var(--err-bg);border-radius:10px;padding:14px"><div style="font-size:10px;color:var(--err);font-weight:600;text-transform:uppercase;letter-spacing:.08em">Habis</div><div style="font-family:var(--serif);font-size:22px;font-weight:600;color:var(--navy);margin-top:2px">'+outStock+'</div></div>'+
          '</div>'+
          '<div style="font-size:11px;color:var(--ink-2);margin-bottom:12px;font-weight:600;text-transform:uppercase;letter-spacing:.08em">Distribusi Channel</div>'+
          channelBars(byChannel)+
          '<button class="btn btn-outline" style="width:100%;margin-top:14px" onclick="go(\'inventory\')">Kelola Inventaris →</button>'+
        '</div>'+
      '</div>'+
    '</div>'+
    '<div style="display:grid;grid-template-columns:1.2fr 1fr;gap:20px">'+
      '<div class="card">'+
        '<div class="card-head"><div><h3>Top Produk</h3><div class="card-head-sub">Berdasarkan pendapatan</div></div><button class="btn btn-ghost btn-sm" onclick="go(\'products\')">Semua Produk →</button></div>'+
        '<div class="card-body" style="padding:0"><div class="table-wrap"><table>'+
          '<thead><tr><th>Produk</th><th>Varian</th><th>Stok Total</th><th class="ta-r">Pendapatan</th></tr></thead>'+
          '<tbody>' + topProds.map(function(p){
            var pi = S.products.indexOf(p);
            return '<tr style="cursor:pointer" onclick="openEdit('+pi+')">'+
              '<td><div class="prod-cell">'+
                '<div class="prod-thumb prod-thumb-large" style="background:linear-gradient(135deg,'+hex(p.colors[0])+','+hex(p.colors[1]||p.colors[0])+')">'+
                  '<div class="prod-thumb-dots">'+ p.colors.slice(0,3).map(function(c){return '<div style="background:'+hex(c)+'"></div>';}).join('') +'</div>'+
                '</div>'+
                '<div class="prod-cell-info"><div class="prod-cell-name">'+esc(p.name)+'</div><div class="prod-cell-sub mono">'+p.sku+'</div></div>'+
              '</div></td>'+
              '<td><div class="cdots">'+ p.colors.slice(0,4).map(function(c){return '<div class="cdot" style="background:'+hex(c)+'"></div>';}).join('')+(p.colors.length>4?'<span class="more">+'+(p.colors.length-4)+'</span>':'')+'</div></td>'+
              '<td class="td-emph mono">'+totalStock(p)+'</td>'+
              '<td class="ta-r td-emph">'+fmtK(prodRev[p.sku]||0)+'</td>'+
            '</tr>';
          }).join('') + '</tbody>'+
        '</table></div></div>'+
      '</div>'+
      '<div class="card">'+
        '<div class="card-head"><h3>Aksi Cepat</h3></div>'+
        '<div class="card-body" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">'+
          quickAction("Edit Produk","Nama, harga, deskripsi","products","M12 20h9M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z")+
          quickAction("Hero Banner","Banner & video toko","storefront","M3 9h18l-2 12H5L3 9zM3 9V6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v3")+
          quickAction("Kelola Stok","Stok per varian","inventory","M21 16V8a2 2 0 0 0-1-1.73L13 2.27a2 2 0 0 0-2 0L4 6.27A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z")+
          quickAction("Promo Voucher","Diskon & flash sale","vouchers","M21 5v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z")+
        '</div>'+
      '</div>'+
    '</div>';
}
function channelLabel(c){
  if(c==="whatsapp") return "WhatsApp";
  if(c==="shopee") return "Shopee";
  if(c==="tiktok") return "TikTok";
  if(c==="lazada") return "Lazada";
  return c;
}
function channelBars(b){
  var total = b.whatsapp + b.shopee + b.tiktok + b.lazada || 1;
  var entries = [
    {n:"WhatsApp", v:b.whatsapp, c:"#25D366"},
    {n:"Shopee", v:b.shopee, c:"#EE4D2D"},
    {n:"TikTok", v:b.tiktok, c:"#000000"},
    {n:"Lazada", v:b.lazada, c:"#0F146E"}
  ];
  return entries.map(function(e){
    var pct = Math.round((e.v/total)*100);
    return '<div style="margin-bottom:10px"><div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:4px"><span style="color:var(--ink-2);font-weight:500">'+e.n+'</span><span class="mono" style="color:var(--ink)">'+fmtK(e.v)+' · '+pct+'%</span></div><div style="height:6px;background:var(--bg-2);border-radius:3px;overflow:hidden"><div style="width:'+pct+'%;height:100%;background:'+e.c+';border-radius:3px"></div></div></div>';
  }).join('');
}
function quickAction(title, desc, page, iconPath){
  return '<button class="card" style="cursor:pointer;text-align:left;background:var(--paper);transition:all .2s;padding:14px;border-radius:11px" onclick="go(\''+page+'\')" onmouseover="this.style.borderColor=\'var(--gold)\';this.style.transform=\'translateY(-2px)\'" onmouseout="this.style.borderColor=\'var(--line)\';this.style.transform=\'\'">'+
    '<div style="width:30px;height:30px;background:var(--gold-bg);border-radius:7px;display:grid;place-items:center;margin-bottom:10px"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="var(--gold-2)" stroke-width="1.8"><path d="'+iconPath+'"/></svg></div>'+
    '<div style="font-size:13px;font-weight:600;color:var(--navy);margin-bottom:2px;letter-spacing:-.005em">'+esc(title)+'</div>'+
    '<div style="font-size:11px;color:var(--ink-2);line-height:1.5">'+esc(desc)+'</div>'+
  '</button>';
}

window.exportData = function(){
  var data = {
    products:S.products, hex:S.hex, stock:S.stock, store:S.store,
    orders:S.orders, customers:S.customers, vouchers:S.vouchers, campaigns:S.campaigns,
    exported_at: new Date().toISOString()
  };
  var blob = new Blob([JSON.stringify(data,null,2)], {type:"application/json"});
  var a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "giandi-data-"+new Date().toISOString().slice(0,10)+".json";
  a.click();
  toast("✓ Data berhasil di-export");
};

/* ═════ PRODUCTS LIST ═════ */
function pageProducts(){
  setCrumb(["Admin","Katalog","Produk"]);
  var cats = [];
  for(var i=0;i<S.products.length;i++){ if(cats.indexOf(S.products[i].cat)<0) cats.push(S.products[i].cat); }
  var filtered = S.products.filter(function(p){
    if(S.filter_cat && p.cat !== S.filter_cat) return false;
    if(S.filter_status === "active" && !p.active) return false;
    if(S.filter_status === "draft" && p.active) return false;
    if(S.q){
      var q = S.q.toLowerCase();
      if(p.name.toLowerCase().indexOf(q)<0 && p.sku.toLowerCase().indexOf(q)<0 && p.cat.toLowerCase().indexOf(q)<0) return false;
    }
    return true;
  });
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Katalog</div>'+
        '<h1 class="page-title">Produk</h1>'+
        '<p class="page-sub">Kelola seluruh produk · edit nama, deskripsi, harga, varian warna, foto, dan stok. Sebagian produk memiliki 30+ varian warna.</p>'+
      '</div>'+
      '<div class="page-actions">'+
        '<button class="btn btn-outline" onclick="bulkExport()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Export CSV</button>'+
        '<button class="btn btn-primary" onclick="newProduct()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 5v14M5 12h14"/></svg> Tambah Produk</button>'+
      '</div>'+
    '</div>'+
    '<div class="list-tools">'+
      '<div class="list-search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input placeholder="Cari nama produk, SKU, kategori..." value="'+esc(S.q)+'" oninput="setQ(this.value)" /></div>'+
      '<select onchange="S.filter_cat=this.value;render()" style="width:auto;min-width:140px">'+
        '<option value="">Semua Kategori</option>'+
        cats.map(function(c){return '<option'+(c===S.filter_cat?' selected':'')+'>'+esc(c)+'</option>';}).join('')+
      '</select>'+
      '<select onchange="S.filter_status=this.value;render()" style="width:auto;min-width:120px">'+
        '<option value="">Semua Status</option>'+
        '<option value="active"'+(S.filter_status==="active"?' selected':'')+'>Aktif</option>'+
        '<option value="draft"'+(S.filter_status==="draft"?' selected':'')+'>Draft</option>'+
      '</select>'+
      '<div class="list-count">'+filtered.length+' produk</div>'+
    '</div>'+
    '<div class="card">'+
      '<div class="table-wrap"><table>'+
        '<thead><tr><th style="width:32px"></th><th>Produk</th><th>Kategori</th><th>Warna</th><th class="ta-r">Ecer (½m)</th><th class="ta-r">Grosir (yard)</th><th class="ta-r">Stok</th><th>Status</th><th style="width:80px"></th></tr></thead>'+
        '<tbody>' + (filtered.length ? filtered.map(function(p){
          var pi = S.products.indexOf(p);
          var stk = totalStock(p);
          return '<tr>'+
            '<td><input type="checkbox" /></td>'+
            '<td><div class="prod-cell" onclick="openEdit('+pi+')" style="cursor:pointer">'+
              '<div class="prod-thumb prod-thumb-large" style="background:linear-gradient(135deg,'+hex(p.colors[0])+','+hex(p.colors[1]||p.colors[0])+')">'+
                '<div class="prod-thumb-dots">'+p.colors.slice(0,3).map(function(c){return '<div style="background:'+hex(c)+'"></div>';}).join('')+'</div>'+
              '</div>'+
              '<div class="prod-cell-info"><div class="prod-cell-name">'+esc(p.name)+'</div><div class="prod-cell-sub mono">'+p.sku+' · '+p.colors.length+' warna</div></div>'+
            '</div></td>'+
            '<td><span class="pill pill-mute">'+esc(p.cat)+'</span></td>'+
            '<td><div class="cdots">'+p.colors.slice(0,5).map(function(c){return '<div class="cdot" title="'+esc(c)+'" style="background:'+hex(c)+'"></div>';}).join('')+(p.colors.length>5?'<span class="more">+'+(p.colors.length-5)+'</span>':'')+'</div></td>'+
            '<td class="ta-r td-emph">'+fmt(p.rh)+'</td>'+
            '<td class="ta-r td-emph">'+fmt(p.wy)+'</td>'+
            '<td class="ta-r mono" style="font-weight:600">'+stk+'</td>'+
            '<td><span class="pill '+(p.active?"pill-ok":"pill-mute")+'"><span class="pill-dot"></span>'+(p.active?'Aktif':'Draft')+'</span></td>'+
            '<td><button class="btn btn-ghost btn-sm" onclick="openEdit('+pi+')">Edit</button></td>'+
          '</tr>';
        }).join('') : '<tr><td colspan="9"><div class="empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg><h3>Tidak ada produk</h3><p>Filter tidak menemukan produk yang cocok.</p></div></td></tr>') + '</tbody>'+
      '</table></div>'+
    '</div>';
}
window.setQ = function(v){
  S.q = v;
  render();
  var inp = $(".list-search input"); 
  if(inp){ inp.focus(); inp.setSelectionRange(v.length, v.length); }
};
window.bulkExport = function(){
  var rows = [["SKU","Nama","Kategori","Warna","Ecer 0.5m","Ecer 1m","Grosir/yd","HPP","Status"]];
  for(var i=0;i<S.products.length;i++){
    var p = S.products[i];
    rows.push([p.sku, p.name, p.cat, p.colors.length+' warna', p.rh, p.rm, p.wy, p.cost||0, p.active?"Aktif":"Draft"]);
  }
  var csv = rows.map(function(r){return r.map(function(c){return '"'+String(c).replace(/"/g,'""')+'"';}).join(",");}).join("\n");
  var blob = new Blob([csv],{type:"text/csv"});
  var a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "giandi-products-"+new Date().toISOString().slice(0,10)+".csv";
  a.click();
  toast("✓ CSV export berhasil");
};

/* ═════ MAIN RENDER ═════ */
function render(){
  var html = "";
  if(S.page === "dashboard") html = pageDashboard();
  else if(S.page === "products") html = pageProducts();
  else if(S.page === "variants") html = pageVariants();
  else if(S.page === "inventory") html = pageInventory();
  else if(S.page === "media") html = pageMedia();
  else if(S.page === "orders") html = pageOrders();
  else if(S.page === "channels") html = pageChannels();
  else if(S.page === "customers") html = pageCustomers();
  else if(S.page === "shipping") html = pageShipping();
  else if(S.page === "finance") html = pageFinance();
  else if(S.page === "campaigns") html = pageCampaigns();
  else if(S.page === "vouchers") html = pageVouchers();
  else if(S.page === "flashsale") html = pageFlashSale();
  else if(S.page === "storefront") html = pageStorefront();
  else if(S.page === "collections") html = pageCollections();
  else if(S.page === "brand") html = pageBrand();
  else if(S.page === "analytics") html = pageAnalytics();
  else if(S.page === "team") html = pageTeam();
  else if(S.page === "integrations") html = pageIntegrations();
  else if(S.page === "settings") html = pageSettings();
  else html = pageDashboard();
  $("#content").innerHTML = html;
  if(S.page === "storefront") setTimeout(window.updatePreview, 50);
}

/* ═════ MODULE FILES LOAD ON DEMAND ═════ */
// All other page functions are defined below in same file
// Init
renderNav();
render();
window._S = S; // Expose for debugging
window._render = render;
window._persist = persist;

/* ═══════════════════════════════════════════════════════ */
/* ═════ PRODUCT EDIT DRAWER ═════ */
window.openEdit = function(pi){
  S.edit_pi = pi;
  S.edit_tab = "general";
  S.edit_var_search = "";
  S.edit_buf = JSON.parse(JSON.stringify(S.products[pi]));
  S.edit_buf._stock = {};
  S.edit_buf._hex = {};
  for(var i=0;i<S.edit_buf.colors.length;i++){
    var c = S.edit_buf.colors[i];
    var k = S.edit_buf.sku + ":" + c;
    S.edit_buf._stock[c] = JSON.parse(JSON.stringify(S.stock[k] || {retail:100, wholesale:50}));
    S.edit_buf._hex[c] = hex(c);
  }
  S.edit_buf._media = S.edit_buf._media || [];
  renderDrawer();
  $("#drawer").classList.add("on");
  $("#drawer-bg").classList.add("on");
};
window.closeDrawer = function(){
  $("#drawer").classList.remove("on");
  $("#drawer-bg").classList.remove("on");
  S.edit_pi = null;
  S.edit_buf = null;
};
window.newProduct = function(){
  S.products.push({
    sku: "GI-NEW-"+Math.random().toString(36).slice(2,5).toUpperCase(),
    name:"Produk Baru",
    cat:"Premium Silk",
    rh:0, rm:0, wy:0, cost:0,
    active:false,
    desc:"",
    colors:["Hitam"]
  });
  S.hex["Hitam"] = S.hex["Hitam"] || "#000000";
  initStock();
  persist();
  renderNav();
  openEdit(S.products.length - 1);
};

function renderDrawer(){
  if(S.edit_buf === null) return;
  var b = S.edit_buf;
  var pi = S.edit_pi;
  var tab = S.edit_tab;
  var tabBody = "";
  if(tab === "general") tabBody = drawerTabGeneral();
  else if(tab === "variants") tabBody = drawerTabVariants();
  else if(tab === "pricing") tabBody = drawerTabPricing();
  else if(tab === "media") tabBody = drawerTabMedia();
  else if(tab === "stock") tabBody = drawerTabStock();
  else if(tab === "seo") tabBody = drawerTabSEO();

  var html = ''+
    '<div class="drawer-head">'+
      '<button class="btn btn-ghost btn-icon" onclick="closeDrawer()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18M6 6l12 12"/></svg></button>'+
      '<div style="flex:1;min-width:0">'+
        '<h2>'+esc(b.name||"Produk Baru")+'</h2>'+
        '<div class="drawer-head-info">'+esc(b.sku)+' · '+b.colors.length+' varian warna · Stok '+totalStock(S.products[pi])+'</div>'+
      '</div>'+
      '<span class="pill '+(b.active?"pill-ok":"pill-mute")+'"><span class="pill-dot"></span>'+(b.active?'Aktif':'Draft')+'</span>'+
    '</div>'+
    '<div style="padding:0 28px;background:var(--paper);border-bottom:1px solid var(--line)">'+
      '<div class="tabs" style="margin-bottom:0">'+
        editTab("general","Umum")+
        editTab("variants","Varian Warna ("+b.colors.length+")")+
        editTab("pricing","Harga")+
        editTab("media","Foto & Video")+
        editTab("stock","Stok")+
        editTab("seo","SEO")+
      '</div>'+
    '</div>'+
    '<div class="drawer-body" id="drawer-body">'+tabBody+'</div>'+
    '<div class="drawer-foot">'+
      '<button class="btn btn-ghost" onclick="if(confirm(\'Hapus produk ini?\'))deleteProduct()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg> Hapus</button>'+
      '<button class="btn btn-ghost" onclick="duplicateProduct()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Duplicate</button>'+
      '<div class="spacer"></div>'+
      '<button class="btn btn-outline" onclick="closeDrawer()">Batal</button>'+
      '<button class="btn btn-primary" onclick="saveProduct()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12l5 5 9-11"/></svg> Simpan</button>'+
    '</div>';
  $("#drawer-content").innerHTML = html;
}
function editTab(k,n){
  return '<button class="tab'+(S.edit_tab===k?' on':'')+'" onclick="setEditTab(\''+k+'\')">'+n+'</button>';
}
window.setEditTab = function(t){
  S.edit_tab = t;
  renderDrawer();
};

function drawerTabGeneral(){
  var b = S.edit_buf;
  var cats = ["Premium Silk","Luxury Silk","Textured Premium","Breathable Fabric","Jet Black Series"];
  return '<div class="form-grid" style="max-width:760px">'+
    '<div class="form-row two">'+
      '<div><label>Nama Produk</label><input class="inp" value="'+esc(b.name)+'" oninput="S.edit_buf.name=this.value" /></div>'+
      '<div><label>SKU <span class="hint">unik per produk</span></label><input class="inp mono" value="'+esc(b.sku)+'" oninput="S.edit_buf.sku=this.value" /></div>'+
    '</div>'+
    '<div class="form-row two">'+
      '<div><label>Kategori</label><select onchange="S.edit_buf.cat=this.value">'+cats.map(function(c){return '<option'+(c===b.cat?' selected':'')+'>'+c+'</option>';}).join('')+'</select></div>'+
      '<div>'+
        '<label>Status</label>'+
        '<div style="display:flex;gap:8px">'+
          '<button class="chip '+(b.active?"on":"")+'" onclick="S.edit_buf.active=true;renderDrawer()">Aktif (Live)</button>'+
          '<button class="chip '+(!b.active?"on":"")+'" onclick="S.edit_buf.active=false;renderDrawer()">Draft</button>'+
        '</div>'+
      '</div>'+
    '</div>'+
    '<div><label>Deskripsi Produk <span class="hint">tampil di halaman produk · gunakan untuk story telling</span></label><textarea oninput="S.edit_buf.desc=this.value" rows="6">'+esc(b.desc||"")+'</textarea></div>'+
    '<div class="form-row two">'+
      '<div><label>Lebar Kain</label><input class="inp" value="'+esc(b.width||"150 cm")+'" oninput="S.edit_buf.width=this.value" /></div>'+
      '<div><label>Berat <span class="hint">per meter</span></label><input class="inp" value="'+esc(b.weight||"200 g/m")+'" oninput="S.edit_buf.weight=this.value" /></div>'+
    '</div>'+
    '<div class="form-row two">'+
      '<div><label>Komposisi</label><input class="inp" value="'+esc(b.composition||"Premium silk blend")+'" oninput="S.edit_buf.composition=this.value" /></div>'+
      '<div><label>Perawatan</label><input class="inp" value="'+esc(b.care||"Hand wash / dry clean")+'" oninput="S.edit_buf.care=this.value" /></div>'+
    '</div>'+
    '<div><label>Tag <span class="hint">pisahkan dengan koma</span></label><input class="inp" value="'+esc((b.tags||[]).join(", "))+'" oninput="S.edit_buf.tags=this.value.split(\',\').map(function(s){return s.trim();}).filter(Boolean)" placeholder="hijab, gamis, syari, bridal, premium" /></div>'+
  '</div>';
}

function drawerTabVariants(){
  var b = S.edit_buf;
  var sq = (S.edit_var_search||"").toLowerCase();
  var filtered = [];
  for(var i=0;i<b.colors.length;i++){
    if(!sq || b.colors[i].toLowerCase().indexOf(sq) >= 0){
      filtered.push({idx:i, name:b.colors[i]});
    }
  }
  var cards = "";
  for(var i=0;i<filtered.length;i++){
    var idx = filtered[i].idx;
    var c = filtered[i].name;
    var h = b._hex[c] || hex(c);
    var s = b._stock[c] || {retail:0, wholesale:0};
    cards += '<div class="var-card">'+
      '<div class="var-card-actions">'+
        '<button onclick="editVariant('+idx+')" title="Edit"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 20h9M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg></button>'+
        '<button onclick="removeVariant('+idx+')" title="Hapus"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg></button>'+
      '</div>'+
      '<div class="var-card-color" style="background:'+h+'"></div>'+
      '<div class="var-card-nm" title="'+esc(c)+'">'+esc(c)+'</div>'+
      '<div class="var-card-hex">'+h.toUpperCase()+'</div>'+
      '<div class="var-card-stk"><span>R:</span><b>'+(s.retail||0)+'m</b> <span>W:</span><b>'+(s.wholesale||0)+'y</b></div>'+
    '</div>';
  }
  if(!sq) cards += '<button class="var-add" onclick="addVariant()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>Tambah Warna</button>';

  return '<div class="form-grid">'+
    '<div>'+
      '<div style="display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:14px;gap:14px;flex-wrap:wrap">'+
        '<div>'+
          '<label style="margin-bottom:2px">Varian Warna · '+b.colors.length+' total</label>'+
          '<div class="field-hint">Klik kartu untuk edit nama dan hex code. Cari di antara '+b.colors.length+' varian.</div>'+
        '</div>'+
        '<div style="display:flex;gap:8px;align-items:center">'+
          '<div class="list-search" style="min-width:240px"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input placeholder="Cari warna..." value="'+esc(S.edit_var_search)+'" oninput="setVarSearch(this.value)" /></div>'+
          '<button class="btn btn-outline btn-sm" onclick="bulkAddVariants()" title="Bulk add"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Bulk</button>'+
        '</div>'+
      '</div>'+
      '<div class="var-grid">'+cards+'</div>'+
      (filtered.length === 0 && sq ? '<div class="empty"><h3>Tidak ditemukan</h3><p>Tidak ada warna dengan nama "<b>'+esc(sq)+'</b>"</p></div>' : '')+
    '</div>'+
  '</div>';
}
window.setVarSearch = function(v){
  S.edit_var_search = v;
  // Re-render only the variant tab content
  $("#drawer-body").innerHTML = drawerTabVariants();
  var inp = $("#drawer-body .list-search input");
  if(inp){ inp.focus(); inp.setSelectionRange(v.length, v.length); }
};

window.editVariant = function(idx){
  var b = S.edit_buf;
  var oldName = b.colors[idx];
  var oldHex = b._hex[oldName] || hex(oldName);
  openModal(''+
    '<h3>Edit Varian Warna</h3>'+
    '<p class="modal-sub">Ubah nama dan hex code. Perubahan disimpan saat klik "Simpan".</p>'+
    '<div class="form-grid">'+
      '<div><label>Nama Warna</label><input class="inp" id="vm-nm" value="'+esc(oldName)+'" autofocus /></div>'+
      '<div>'+
        '<label>Hex Code</label>'+
        '<div class="cp-row">'+
          '<input type="color" id="vm-color" value="'+oldHex+'" oninput="document.getElementById(\'vm-hex\').value=this.value.toUpperCase();document.getElementById(\'vm-prev\').style.background=this.value" />'+
          '<input class="inp cp-hex" id="vm-hex" value="'+oldHex.toUpperCase()+'" oninput="document.getElementById(\'vm-color\').value=this.value;document.getElementById(\'vm-prev\').style.background=this.value" />'+
        '</div>'+
        '<div id="vm-prev" style="background:'+oldHex+';margin-top:10px;width:100%;height:60px;border-radius:9px;border:1px solid var(--line)"></div>'+
      '</div>'+
      '<div class="form-row two">'+
        '<div><label>Stok Ecer <span class="hint">meter</span></label><input class="inp inp-num" type="number" id="vm-r" value="'+(b._stock[oldName]&&b._stock[oldName].retail||0)+'" /></div>'+
        '<div><label>Stok Grosir <span class="hint">yard</span></label><input class="inp inp-num" type="number" id="vm-w" value="'+(b._stock[oldName]&&b._stock[oldName].wholesale||0)+'" /></div>'+
      '</div>'+
    '</div>'+
    '<div class="modal-actions">'+
      '<button class="btn btn-outline" onclick="closeModal()">Batal</button>'+
      '<button class="btn btn-primary" onclick="saveVarEdit('+idx+',\''+esc(oldName).replace(/'/g,"\\'")+'\')">Simpan</button>'+
    '</div>'
  );
};
window.saveVarEdit = function(idx, oldName){
  var newName = $("#vm-nm").value.trim();
  var newHex = $("#vm-hex").value;
  var newR = parseInt($("#vm-r").value)||0;
  var newW = parseInt($("#vm-w").value)||0;
  if(!newName){ toast("Nama warna tidak boleh kosong", "error"); return; }
  var b = S.edit_buf;
  if(newName !== oldName){
    if(b.colors.indexOf(newName) >= 0 && newName !== oldName){ toast("Nama sudah dipakai varian lain", "error"); return; }
    b._stock[newName] = b._stock[oldName] || {retail:0, wholesale:0};
    delete b._stock[oldName];
    b.colors[idx] = newName;
  }
  b._hex[newName] = newHex;
  b._stock[newName] = {retail:newR, wholesale:newW};
  closeModal();
  renderDrawer();
  toast("✓ Varian diperbarui");
};
window.removeVariant = function(idx){
  var b = S.edit_buf;
  if(!confirm("Hapus varian \""+b.colors[idx]+"\"?")) return;
  var name = b.colors[idx];
  b.colors.splice(idx,1);
  delete b._stock[name];
  delete b._hex[name];
  renderDrawer();
  toast("✓ Varian dihapus");
};
window.addVariant = function(){
  openModal(''+
    '<h3>Tambah Warna Baru</h3>'+
    '<p class="modal-sub">Pilih warna dan beri nama. Stok awal default 100m ecer + 50yd grosir.</p>'+
    '<div class="form-grid">'+
      '<div><label>Nama Warna</label><input class="inp" id="av-nm" autofocus placeholder="Misal: Royal Sapphire" /></div>'+
      '<div>'+
        '<label>Hex Code</label>'+
        '<div class="cp-row">'+
          '<input type="color" id="av-color" value="#8C6F5C" oninput="document.getElementById(\'av-hex\').value=this.value.toUpperCase();document.getElementById(\'av-prev\').style.background=this.value" />'+
          '<input class="inp cp-hex" id="av-hex" value="#8C6F5C" oninput="document.getElementById(\'av-color\').value=this.value;document.getElementById(\'av-prev\').style.background=this.value" />'+
        '</div>'+
        '<div id="av-prev" style="background:#8C6F5C;margin-top:10px;width:100%;height:60px;border-radius:9px;border:1px solid var(--line)"></div>'+
      '</div>'+
    '</div>'+
    '<div class="modal-actions">'+
      '<button class="btn btn-outline" onclick="closeModal()">Batal</button>'+
      '<button class="btn btn-primary" onclick="confirmAddVariant()">Tambah</button>'+
    '</div>'
  );
};
window.confirmAddVariant = function(){
  var name = $("#av-nm").value.trim();
  var h = $("#av-hex").value;
  if(!name){ toast("Nama warna diperlukan", "error"); return; }
  var b = S.edit_buf;
  if(b.colors.indexOf(name) >= 0){ toast("Warna sudah ada", "error"); return; }
  b.colors.push(name);
  b._hex[name] = h;
  b._stock[name] = {retail:100, wholesale:50};
  closeModal();
  renderDrawer();
  toast("✓ Warna ditambahkan");
};
window.bulkAddVariants = function(){
  openModal(''+
    '<h3>Bulk Add Warna</h3>'+
    '<p class="modal-sub">Tempel daftar warna · satu nama per baris. Warna duplikat akan dilewati.</p>'+
    '<textarea id="ba-list" rows="10" placeholder="Crimson Red&#10;Royal Sapphire&#10;Forest Emerald&#10;Sand Cream" style="font-family:var(--mono);font-size:12px"></textarea>'+
    '<div class="modal-actions">'+
      '<button class="btn btn-outline" onclick="closeModal()">Batal</button>'+
      '<button class="btn btn-primary" onclick="confirmBulkAdd()">Tambah Semua</button>'+
    '</div>'
  );
};
window.confirmBulkAdd = function(){
  var lines = $("#ba-list").value.split("\n").map(function(s){return s.trim();}).filter(Boolean);
  var b = S.edit_buf;
  var added = 0;
  for(var i=0;i<lines.length;i++){
    if(b.colors.indexOf(lines[i]) < 0){
      b.colors.push(lines[i]);
      b._hex[lines[i]] = "#888888";
      b._stock[lines[i]] = {retail:100, wholesale:50};
      added++;
    }
  }
  closeModal();
  renderDrawer();
  toast("✓ "+added+" warna ditambahkan");
};

function drawerTabPricing(){
  var b = S.edit_buf;
  var mRH = b.cost ? Math.round(((b.rh - b.cost)/b.rh)*100) : 0;
  var mRM = b.cost ? Math.round(((b.rm - (b.cost*2))/b.rm)*100) : 0;
  var mWY = b.cost ? Math.round(((b.wy - (b.cost*0.9))/b.wy)*100) : 0;
  return '<div class="form-grid" style="max-width:760px">'+
    '<div class="card" style="border-color:var(--gold-3);background:var(--gold-bg)"><div class="card-body" style="padding:16px 18px">'+
      '<div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">'+
        '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="var(--gold-2)" stroke-width="1.8"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>'+
        '<b style="color:var(--gold-2);font-size:12px;letter-spacing:.04em;text-transform:uppercase">Tier Harga Giandi</b>'+
      '</div>'+
      '<p style="font-size:12px;color:var(--ink-2);line-height:1.6">Giandi menggunakan 3 tier: <b>Ecer 0,5 m</b>, <b>Ecer 1 m</b>, dan <b>Grosir 1 yard</b> (min. 5 yard/warna). Stok ecer dan grosir terpisah.</p>'+
    '</div></div>'+
    '<div><label>Harga Pokok (HPP) <span class="hint">per meter, untuk hitung margin</span></label>'+
      '<div class="inp-prefix"><span class="prefix">Rp</span><input class="inp inp-num" type="number" value="'+(b.cost||0)+'" oninput="S.edit_buf.cost=parseInt(this.value)||0;renderDrawer()" /></div>'+
    '</div>'+
    '<div class="form-row three">'+
      '<div>'+
        '<label>Ecer 0,5 m</label>'+
        '<div class="inp-prefix"><span class="prefix">Rp</span><input class="inp inp-num" type="number" value="'+(b.rh||0)+'" oninput="S.edit_buf.rh=parseInt(this.value)||0;renderDrawer()" /></div>'+
        '<div class="field-hint">Margin: <b style="color:'+(mRH>40?"var(--ok)":"var(--warn)")+'">'+mRH+'%</b></div>'+
      '</div>'+
      '<div>'+
        '<label>Ecer 1 m</label>'+
        '<div class="inp-prefix"><span class="prefix">Rp</span><input class="inp inp-num" type="number" value="'+(b.rm||0)+'" oninput="S.edit_buf.rm=parseInt(this.value)||0;renderDrawer()" /></div>'+
        '<div class="field-hint">Margin: <b style="color:'+(mRM>40?"var(--ok)":"var(--warn)")+'">'+mRM+'%</b></div>'+
      '</div>'+
      '<div>'+
        '<label>Grosir 1 yard</label>'+
        '<div class="inp-prefix"><span class="prefix">Rp</span><input class="inp inp-num" type="number" value="'+(b.wy||0)+'" oninput="S.edit_buf.wy=parseInt(this.value)||0;renderDrawer()" /></div>'+
        '<div class="field-hint">Margin: <b style="color:'+(mWY>30?"var(--ok)":"var(--warn)")+'">'+mWY+'%</b></div>'+
      '</div>'+
    '</div>'+
    '<div class="form-row two">'+
      '<div><label>Harga Diskon <span class="hint">opsional · sale</span></label><div class="inp-prefix"><span class="prefix">Rp</span><input class="inp inp-num" type="number" value="'+(b.sale_price||"")+'" oninput="S.edit_buf.sale_price=parseInt(this.value)||null" placeholder="0" /></div></div>'+
      '<div><label>Berlaku Sampai</label><input type="date" class="inp" value="'+(b.sale_until||"")+'" oninput="S.edit_buf.sale_until=this.value" /></div>'+
    '</div>'+
  '</div>';
}

function drawerTabMedia(){
  var b = S.edit_buf;
  var tiles = "";
  if(b._media && b._media.length){
    for(var i=0;i<b._media.length;i++){
      var m = b._media[i];
      var typeLabel = m.type === "video" ? "VIDEO" : "FOTO";
      var preview = m.type === "video" 
        ? '<video src="'+(m.data||"")+'" muted></video>'
        : (m.data ? '<img src="'+m.data+'" alt="" />' : '<div style="width:100%;height:100%;background:linear-gradient(135deg,'+hex(b.colors[0])+','+hex(b.colors[1]||b.colors[0])+')"></div>');
      tiles += '<div class="media-tile">'+
        preview+
        '<span class="media-type">'+typeLabel+'</span>'+
        (i===0?'<div class="media-cover">Cover</div>':'')+
        '<div class="media-actions">'+
          (i>0?'<button onclick="setCover('+i+')" title="Set cover"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg></button>':'')+
          '<button onclick="removeMedia('+i+')" title="Hapus" style="color:var(--err)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/></svg></button>'+
        '</div>'+
      '</div>';
    }
  } else {
    // Auto-placeholders from color gradients
    for(var i=0;i<Math.min(4, b.colors.length);i++){
      var c = b.colors[i];
      tiles += '<div class="media-tile" style="background:linear-gradient(135deg,'+hex(c)+', '+hex(b.colors[(i+1)%b.colors.length])+')">'+
        '<span class="media-type">AUTO</span>'+
        (i===0?'<div class="media-cover">Auto Cover</div>':'')+
      '</div>';
    }
  }
  tiles += '<label class="media-tile add">'+
    '<input type="file" accept="image/*,video/*" multiple style="display:none" onchange="uploadMedia(this.files)" />'+
    '<div><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg><div>Upload</div><div style="font-size:10px;color:var(--ink-3);margin-top:2px">Foto / Video</div></div>'+
  '</label>';

  return '<div class="form-grid">'+
    '<div>'+
      '<div style="margin-bottom:14px">'+
        '<label style="margin-bottom:2px">Foto & Video Produk · '+(b._media?b._media.length:0)+' file</label>'+
        '<div class="field-hint">Upload foto (JPG/PNG) atau video (MP4) · drag untuk urutkan · foto pertama jadi cover · rekomendasi 4:5 ratio, max 5MB.</div>'+
      '</div>'+
      '<div class="media-grid">'+tiles+'</div>'+
    '</div>'+
    '<div class="card" style="background:var(--bg-2);border:none"><div class="card-body" style="padding:16px 18px">'+
      '<div style="display:flex;align-items:flex-start;gap:12px">'+
        '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="var(--gold-2)" stroke-width="1.8" style="flex-shrink:0;margin-top:1px"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>'+
        '<div>'+
          '<b style="display:block;margin-bottom:4px;font-size:13px">Tips foto premium</b>'+
          '<p style="font-size:12px;color:var(--ink-2);line-height:1.65">Foto kain di natural light, latar belakang netral (white/cream), close-up tekstur, dan satu shot styling utuh (drape kain). Video 15 detik dengan slow-motion drape sangat meningkatkan konversi di TikTok Shop.</p>'+
        '</div>'+
      '</div>'+
    '</div></div>'+
  '</div>';
}
window.uploadMedia = function(files){
  var b = S.edit_buf;
  if(!b._media) b._media = [];
  var n = files.length;
  var processed = 0;
  for(var i=0;i<n;i++){
    (function(f){
      var reader = new FileReader();
      reader.onload = function(e){
        var type = f.type.indexOf("video") === 0 ? "video" : "image";
        b._media.push({ name:f.name, type:type, data:e.target.result, size:f.size });
        processed++;
        if(processed === n){
          renderDrawer();
          toast("✓ "+n+" file diupload");
        }
      };
      reader.readAsDataURL(f);
    })(files[i]);
  }
};
window.removeMedia = function(idx){
  if(!confirm("Hapus media ini?")) return;
  S.edit_buf._media.splice(idx, 1);
  renderDrawer();
};
window.setCover = function(idx){
  var b = S.edit_buf;
  var item = b._media.splice(idx, 1)[0];
  b._media.unshift(item);
  renderDrawer();
  toast("✓ Cover diperbarui");
};

function drawerTabStock(){
  var b = S.edit_buf;
  var rows = "";
  for(var i=0;i<b.colors.length;i++){
    var c = b.colors[i];
    var s = b._stock[c] || {retail:0,wholesale:0};
    var total = (s.retail||0)+(s.wholesale||0);
    var lo = total < 30, off = total === 0;
    var safeC = c.replace(/'/g,"\\'");
    rows += '<tr>'+
      '<td><div class="prod-cell"><div class="cdot" style="width:26px;height:26px;background:'+(b._hex[c]||hex(c))+'"></div><div><div style="font-weight:500;color:var(--navy)">'+esc(c)+'</div><div class="mono" style="font-size:10px;color:var(--ink-3)">'+(b._hex[c]||hex(c)).toUpperCase()+'</div></div></div></td>'+
      '<td><input class="inp inp-num" type="number" value="'+s.retail+'" oninput="S.edit_buf._stock[\''+safeC+'\'].retail=parseInt(this.value)||0" style="width:90px" /></td>'+
      '<td><input class="inp inp-num" type="number" value="'+s.wholesale+'" oninput="S.edit_buf._stock[\''+safeC+'\'].wholesale=parseInt(this.value)||0" style="width:90px" /></td>'+
      '<td class="ta-r mono td-emph">'+total+'</td>'+
      '<td>'+(off?'<span class="pill pill-err"><span class="pill-dot"></span>Habis</span>':lo?'<span class="pill pill-warn"><span class="pill-dot"></span>Menipis</span>':'<span class="pill pill-ok"><span class="pill-dot"></span>Aman</span>')+'</td>'+
    '</tr>';
  }
  return '<div class="form-grid">'+
    '<div>'+
      '<label style="margin-bottom:2px">Stok per Varian · '+b.colors.length+' warna</label>'+
      '<div class="field-hint" style="margin-bottom:14px">Stok ecer (meter) dan grosir (yard) tersimpan terpisah. Update real-time saat ada pesanan.</div>'+
      '<div class="card"><div class="table-wrap"><table>'+
        '<thead><tr><th>Warna</th><th>Ecer (m)</th><th>Grosir (yard)</th><th class="ta-r">Total</th><th>Status</th></tr></thead>'+
        '<tbody>'+rows+'</tbody>'+
      '</table></div></div>'+
    '</div>'+
  '</div>';
}

function drawerTabSEO(){
  var b = S.edit_buf;
  var slug = b.slug || (b.name||"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"");
  var mt = b.meta_title || (b.name + " — Premium Kain Sutra Giandi Textile");
  var md = b.meta_desc || (b.desc||"").slice(0,160);
  return '<div class="form-grid" style="max-width:760px">'+
    '<div><label>URL Slug</label>'+
      '<div class="inp-prefix"><span class="prefix">/p/</span><input class="inp" value="'+esc(slug)+'" oninput="S.edit_buf.slug=this.value" /></div>'+
      '<div class="field-hint">Misal: marbella-silk-prestige · huruf kecil, angka, tanda hubung saja.</div>'+
    '</div>'+
    '<div><label>Meta Title <span class="hint">max 60 karakter</span></label>'+
      '<input class="inp" value="'+esc(mt)+'" oninput="S.edit_buf.meta_title=this.value" />'+
      '<div class="field-hint">'+mt.length+'/60 karakter</div>'+
    '</div>'+
    '<div><label>Meta Description <span class="hint">max 160 karakter</span></label>'+
      '<textarea oninput="S.edit_buf.meta_desc=this.value" rows="3">'+esc(md)+'</textarea>'+
    '</div>'+
    '<div class="card" style="background:var(--paper)"><div class="card-body">'+
      '<div style="font-size:11px;color:var(--ink-3);letter-spacing:.06em;text-transform:uppercase;font-weight:600;margin-bottom:8px">Preview Google</div>'+
      '<div style="font-size:11px;color:#202124">gianditextile.com › p › '+esc(slug)+'</div>'+
      '<div style="font-size:18px;color:#1A0DAB;line-height:1.3;margin:4px 0 2px">'+esc(mt)+'</div>'+
      '<div style="font-size:13px;color:#4D5156;line-height:1.5">'+esc(md)+'</div>'+
    '</div></div>'+
  '</div>';
}

window.saveProduct = function(){
  var b = S.edit_buf;
  var pi = S.edit_pi;
  for(var c in b._hex){ S.hex[c] = b._hex[c]; }
  for(var c in b._stock){
    S.stock[b.sku + ":" + c] = b._stock[c];
  }
  var clean = {};
  for(var k in b){ if(k.charAt(0) !== "_") clean[k] = b[k]; }
  if(b._media) clean._media = b._media;
  S.products[pi] = clean;
  persist();
  renderNav();
  toast("✓ Perubahan disimpan");
  closeDrawer();
  render();
};
window.deleteProduct = function(){
  S.products.splice(S.edit_pi, 1);
  persist();
  renderNav();
  toast("✓ Produk dihapus");
  closeDrawer();
  render();
};
window.duplicateProduct = function(){
  var b = S.edit_buf;
  var pi = S.edit_pi;
  var clean = JSON.parse(JSON.stringify(S.products[pi]));
  clean.sku = clean.sku + "-COPY";
  clean.name = clean.name + " (Copy)";
  clean.active = false;
  S.products.push(clean);
  initStock();
  persist();
  renderNav();
  toast("✓ Produk diduplikasi");
  closeDrawer();
  render();
};



/* ═════ VARIANTS PAGE (Global Color Manager) ═════ */
function pageVariants(){
  setCrumb(["Admin","Katalog","Varian Warna"]);
  var allColors = {};
  for(var i=0;i<S.products.length;i++){
    var p = S.products[i];
    for(var j=0;j<p.colors.length;j++){
      var c = p.colors[j];
      if(!allColors[c]) allColors[c] = { hex:hex(c), products:[] };
      allColors[c].products.push(p);
    }
  }
  var names = Object.keys(allColors).sort();
  var sq = S.q ? S.q.toLowerCase() : "";
  if(sq) names = names.filter(function(n){return n.toLowerCase().indexOf(sq)>=0;});
  var rows = "";
  for(var i=0;i<names.length;i++){
    var c = names[i];
    var info = allColors[c];
    var safeC = c.replace(/'/g,"\\'");
    rows += '<tr>'+
      '<td><div class="prod-cell">'+
        '<div class="cdot" style="width:32px;height:32px;background:'+info.hex+'"></div>'+
        '<div><div style="font-weight:600;color:var(--navy)">'+esc(c)+'</div><div class="mono" style="font-size:10px;color:var(--ink-3)">'+info.hex.toUpperCase()+'</div></div>'+
      '</div></td>'+
      '<td><span class="pill pill-mute">'+info.products.length+' produk</span></td>'+
      '<td style="font-size:11px;color:var(--ink-2)">'+info.products.slice(0,3).map(function(p){return esc(p.name);}).join(', ')+(info.products.length>3?' <span style="color:var(--ink-3)">+'+(info.products.length-3)+' lainnya</span>':'')+'</td>'+
      '<td><div style="display:flex;gap:6px"><button class="btn btn-ghost btn-sm" onclick="renameGlobalColor(\''+safeC+'\')">Rename</button><button class="btn btn-ghost btn-sm" onclick="changeGlobalHex(\''+safeC+'\')">Ubah Hex</button></div></td>'+
    '</tr>';
  }
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Katalog</div>'+
        '<h1 class="page-title">Varian Warna</h1>'+
        '<p class="page-sub">'+Object.keys(allColors).length+' warna unik di '+S.products.length+' produk. Rename di sini akan update di semua produk yang menggunakan warna tersebut.</p>'+
      '</div>'+
    '</div>'+
    '<div class="list-tools">'+
      '<div class="list-search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input placeholder="Cari nama warna..." value="'+esc(S.q)+'" oninput="setQ(this.value)" /></div>'+
      '<div class="list-count">'+names.length+' warna ditampilkan</div>'+
    '</div>'+
    '<div class="card"><div class="table-wrap"><table>'+
      '<thead><tr><th>Warna</th><th>Penggunaan</th><th>Pada Produk</th><th style="width:160px">Aksi</th></tr></thead>'+
      '<tbody>'+(rows||'<tr><td colspan="4"><div class="empty"><h3>Tidak ditemukan</h3><p>Coba kata kunci lain.</p></div></td></tr>')+'</tbody>'+
    '</table></div></div>';
}
window.renameGlobalColor = function(oldName){
  var newName = prompt('Rename warna "'+oldName+'" menjadi:', oldName);
  if(!newName || newName === oldName) return;
  newName = newName.trim();
  if(!newName) return;
  S.hex[newName] = S.hex[oldName];
  delete S.hex[oldName];
  for(var i=0;i<S.products.length;i++){
    var p = S.products[i];
    for(var j=0;j<p.colors.length;j++){
      if(p.colors[j] === oldName){
        p.colors[j] = newName;
        var oldK = p.sku+":"+oldName, newK = p.sku+":"+newName;
        if(S.stock[oldK]){ S.stock[newK] = S.stock[oldK]; delete S.stock[oldK]; }
      }
    }
  }
  persist();
  toast("✓ "+oldName+" → "+newName);
  render();
};
window.changeGlobalHex = function(name){
  var current = S.hex[name] || "#888888";
  openModal(''+
    '<h3>Ubah Hex Code</h3>'+
    '<p class="modal-sub">Mengubah hex code untuk "<b>'+esc(name)+'</b>" akan update di semua produk yang menggunakan warna ini.</p>'+
    '<div class="form-grid">'+
      '<div>'+
        '<label>Hex Code Baru</label>'+
        '<div class="cp-row">'+
          '<input type="color" id="ch-color" value="'+current+'" oninput="document.getElementById(\'ch-hex\').value=this.value.toUpperCase();document.getElementById(\'ch-prev\').style.background=this.value" />'+
          '<input class="inp cp-hex" id="ch-hex" value="'+current.toUpperCase()+'" oninput="document.getElementById(\'ch-color\').value=this.value;document.getElementById(\'ch-prev\').style.background=this.value" />'+
        '</div>'+
        '<div id="ch-prev" style="background:'+current+';margin-top:10px;width:100%;height:60px;border-radius:9px;border:1px solid var(--line)"></div>'+
      '</div>'+
    '</div>'+
    '<div class="modal-actions">'+
      '<button class="btn btn-outline" onclick="closeModal()">Batal</button>'+
      '<button class="btn btn-primary" onclick="confirmHexChange(\''+name.replace(/'/g,"\\'")+'\')">Simpan</button>'+
    '</div>'
  );
};
window.confirmHexChange = function(name){
  S.hex[name] = $("#ch-hex").value;
  persist();
  closeModal();
  render();
  toast("✓ Hex code diperbarui");
};

/* ═════ INVENTORY PAGE ═════ */
function pageInventory(){
  setCrumb(["Admin","Katalog","Inventaris"]);
  var ok=0, low=0, off=0, totalRet=0, totalWho=0;
  var allItems = [];
  for(var i=0;i<S.products.length;i++){
    var p = S.products[i];
    for(var j=0;j<p.colors.length;j++){
      var c = p.colors[j];
      var s = S.stock[p.sku+":"+c] || {};
      var t = (s.retail||0)+(s.wholesale||0);
      totalRet += s.retail||0;
      totalWho += s.wholesale||0;
      var st = t===0?"off":t<30?"low":"ok";
      if(st==="ok") ok++; else if(st==="low") low++; else off++;
      allItems.push({p:p,c:c,s:s,t:t,st:st});
    }
  }
  var attentionItems = allItems.filter(function(it){return it.st!=="ok";}).sort(function(a,b){return a.t-b.t;});
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Katalog</div>'+
        '<h1 class="page-title">Inventaris</h1>'+
        '<p class="page-sub">Pantau '+allItems.length+' varian di '+S.products.length+' produk. Klik untuk update stok detail.</p>'+
      '</div>'+
    '</div>'+
    '<div class="kpi-row">'+
      '<div class="kpi"><div class="kpi-lbl">Total Varian</div><div class="kpi-val">'+allItems.length+'</div><div class="kpi-sub">di '+S.products.length+' produk</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Stok Aman</div><div class="kpi-val" style="color:var(--ok)">'+ok+'</div><div class="kpi-sub">'+Math.round(ok/allItems.length*100)+'% dari total</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Menipis</div><div class="kpi-val" style="color:var(--warn)">'+low+'</div><div class="kpi-sub">Perlu restock</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Habis</div><div class="kpi-val" style="color:var(--err)">'+off+'</div><div class="kpi-sub">Urgent</div></div>'+
    '</div>'+
    '<div class="kpi-row" style="margin-bottom:24px">'+
      '<div class="kpi"><div class="kpi-lbl">Total Stok Ecer</div><div class="kpi-val">'+fmtNum(totalRet)+' <span style="font-size:14px;color:var(--ink-3);font-weight:400">m</span></div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Total Stok Grosir</div><div class="kpi-val">'+fmtNum(totalWho)+' <span style="font-size:14px;color:var(--ink-3);font-weight:400">yard</span></div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Nilai Inventaris</div><div class="kpi-val">'+fmtK(allItems.reduce(function(a,it){return a+((it.s.retail||0)*it.p.rm)+((it.s.wholesale||0)*it.p.wy);},0))+'</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Kategori Produk</div><div class="kpi-val">'+(function(){var c={};for(var i=0;i<S.products.length;i++)c[S.products[i].cat]=1;return Object.keys(c).length;})()+'</div></div>'+
    '</div>'+
    (attentionItems.length ? ''+
    '<div class="card" style="margin-bottom:20px">'+
      '<div class="card-head"><div><h3>Butuh Perhatian</h3><div class="card-head-sub">'+attentionItems.length+' varian perlu restock segera</div></div></div>'+
      '<div class="card-body" style="padding:0"><div class="table-wrap"><table>'+
        '<thead><tr><th>Produk</th><th>Warna</th><th class="ta-r">Ecer (m)</th><th class="ta-r">Grosir (yard)</th><th class="ta-r">Total</th><th>Status</th><th></th></tr></thead>'+
        '<tbody>'+attentionItems.slice(0,20).map(function(it){
          var pi = S.products.indexOf(it.p);
          return '<tr>'+
            '<td><div class="prod-cell" onclick="openEdit('+pi+')" style="cursor:pointer">'+
              '<div class="prod-thumb" style="background:linear-gradient(135deg,'+hex(it.p.colors[0])+','+hex(it.p.colors[1]||it.p.colors[0])+')"></div>'+
              '<div><div class="prod-cell-name">'+esc(it.p.name)+'</div><div class="prod-cell-sub mono">'+it.p.sku+'</div></div>'+
            '</div></td>'+
            '<td><div style="display:flex;align-items:center;gap:8px"><div class="cdot" style="background:'+hex(it.c)+'"></div>'+esc(it.c)+'</div></td>'+
            '<td class="ta-r mono">'+(it.s.retail||0)+'</td>'+
            '<td class="ta-r mono">'+(it.s.wholesale||0)+'</td>'+
            '<td class="ta-r td-emph">'+it.t+'</td>'+
            '<td>'+(it.st==="off"?'<span class="pill pill-err"><span class="pill-dot"></span>Habis</span>':'<span class="pill pill-warn"><span class="pill-dot"></span>Menipis</span>')+'</td>'+
            '<td><button class="btn btn-outline btn-sm" onclick="openEdit('+pi+');setTimeout(function(){setEditTab(\'stock\')},100)">Update</button></td>'+
          '</tr>';
        }).join('')+'</tbody>'+
      '</table></div></div>'+
    '</div>' : '')+
    '<div class="card">'+
      '<div class="card-head"><h3>Ringkasan per Produk</h3><div class="card-head-sub">Stok agregat per produk</div></div>'+
      '<div class="card-body" style="padding:0"><div class="table-wrap"><table>'+
        '<thead><tr><th>Produk</th><th>Varian</th><th class="ta-r">Total Ecer</th><th class="ta-r">Total Grosir</th><th class="ta-r">Total Stok</th><th class="ta-r">Nilai</th></tr></thead>'+
        '<tbody>'+S.products.map(function(p){
          var pi = S.products.indexOf(p);
          var r=0,w=0;
          for(var j=0;j<p.colors.length;j++){var s=S.stock[p.sku+":"+p.colors[j]]||{};r+=s.retail||0;w+=s.wholesale||0;}
          var val = r*p.rm + w*p.wy;
          return '<tr style="cursor:pointer" onclick="openEdit('+pi+');setTimeout(function(){setEditTab(\'stock\')},100)">'+
            '<td><div class="prod-cell"><div class="prod-thumb" style="background:linear-gradient(135deg,'+hex(p.colors[0])+','+hex(p.colors[1]||p.colors[0])+')"></div><div><div class="prod-cell-name">'+esc(p.name)+'</div><div class="prod-cell-sub mono">'+p.sku+'</div></div></div></td>'+
            '<td><span class="pill pill-mute">'+p.colors.length+'</span></td>'+
            '<td class="ta-r mono">'+fmtNum(r)+' m</td>'+
            '<td class="ta-r mono">'+fmtNum(w)+' yd</td>'+
            '<td class="ta-r td-emph">'+(r+w)+'</td>'+
            '<td class="ta-r td-emph">'+fmtK(val)+'</td>'+
          '</tr>';
        }).join('')+'</tbody>'+
      '</table></div></div>'+
    '</div>';
}

/* ═════ MEDIA LIBRARY PAGE ═════ */
function pageMedia(){
  setCrumb(["Admin","Katalog","Media Library"]);
  // Collect all media from all products
  var allMedia = [];
  for(var i=0;i<S.products.length;i++){
    var p = S.products[i];
    if(p._media){
      for(var j=0;j<p._media.length;j++){
        allMedia.push({p:p, m:p._media[j], idx:j, pi:i});
      }
    }
  }
  // Add standalone media
  for(var i=0;i<S.media.length;i++){
    allMedia.push({m:S.media[i], pi:-1, idx:i});
  }
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Katalog</div>'+
        '<h1 class="page-title">Media Library</h1>'+
        '<p class="page-sub">'+allMedia.length+' file media tersimpan · upload foto produk, video showcase, banner, dan asset visual.</p>'+
      '</div>'+
      '<div class="page-actions">'+
        '<label class="btn btn-primary">'+
          '<input type="file" accept="image/*,video/*" multiple style="display:none" onchange="uploadGlobalMedia(this.files)" />'+
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg> Upload Media'+
        '</label>'+
      '</div>'+
    '</div>'+
    '<div class="kpi-row">'+
      '<div class="kpi"><div class="kpi-lbl">Total Media</div><div class="kpi-val">'+allMedia.length+'</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Foto</div><div class="kpi-val">'+allMedia.filter(function(x){return x.m.type!=="video";}).length+'</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Video</div><div class="kpi-val">'+allMedia.filter(function(x){return x.m.type==="video";}).length+'</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Produk dengan Media</div><div class="kpi-val">'+S.products.filter(function(p){return p._media&&p._media.length;}).length+'</div></div>'+
    '</div>'+
    '<div class="card">'+
      '<div class="card-head"><h3>Semua Media</h3></div>'+
      '<div class="card-body">'+
        (allMedia.length ?
        '<div class="media-grid">'+allMedia.map(function(x){
          var preview = x.m.type==="video" 
            ? '<video src="'+(x.m.data||"")+'" muted></video>' 
            : (x.m.data ? '<img src="'+x.m.data+'" alt="" />' : '<div style="width:100%;height:100%;background:var(--bg-2);display:grid;place-items:center;color:var(--ink-3);font-size:11px">No preview</div>');
          return '<div class="media-tile">'+preview+
            '<span class="media-type">'+(x.m.type==="video"?"VIDEO":"FOTO")+'</span>'+
            (x.pi>=0 ? '<div class="media-cover" style="background:rgba(198,167,105,.9)">'+esc(x.p.sku)+'</div>' : '')+
          '</div>';
        }).join('')+'</div>'
        : '<div class="empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/></svg><h3>Belum ada media</h3><p>Upload foto dan video produk Anda untuk memulai.</p></div>')+
      '</div>'+
    '</div>';
}
window.uploadGlobalMedia = function(files){
  var n = files.length, done = 0;
  for(var i=0;i<n;i++){
    (function(f){
      var r = new FileReader();
      r.onload = function(e){
        var type = f.type.indexOf("video")===0 ? "video" : "image";
        S.media.push({name:f.name, type:type, data:e.target.result, size:f.size, uploaded:new Date().toISOString()});
        done++;
        if(done===n){ persist(); render(); toast("✓ "+n+" file diupload"); }
      };
      r.readAsDataURL(f);
    })(files[i]);
  }
};

/* ═════ ORDERS PAGE ═════ */
function pageOrders(){
  setCrumb(["Admin","Operasional","Pesanan"]);
  var ch = S.filter_status || "";
  var orders = S.orders.slice().sort(function(a,b){return new Date(b.date)-new Date(a.date);});
  if(ch) orders = orders.filter(function(o){return o.ch===ch;});
  if(S.q){
    var q = S.q.toLowerCase();
    orders = orders.filter(function(o){return (o.no||"").toLowerCase().indexOf(q)>=0||(o.cust||"").toLowerCase().indexOf(q)>=0||(o.phone||"").toLowerCase().indexOf(q)>=0;});
  }
  var totalRev = orders.reduce(function(a,o){return a+o.total;},0);
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Operasional</div>'+
        '<h1 class="page-title">Pesanan</h1>'+
        '<p class="page-sub">'+orders.length+' pesanan · '+fmtK(totalRev)+' total nilai · semua channel terintegrasi.</p>'+
      '</div>'+
      '<div class="page-actions">'+
        '<button class="btn btn-outline" onclick="exportOrders()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Export</button>'+
      '</div>'+
    '</div>'+
    '<div class="list-tools">'+
      '<div class="list-search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input placeholder="Cari nomor pesanan, nama, telepon..." value="'+esc(S.q)+'" oninput="setQ(this.value)" /></div>'+
      '<select onchange="S.filter_status=this.value;render()" style="width:auto;min-width:140px">'+
        '<option value="">Semua Channel</option>'+
        '<option value="whatsapp"'+(S.filter_status==="whatsapp"?' selected':'')+'>WhatsApp</option>'+
        '<option value="shopee"'+(S.filter_status==="shopee"?' selected':'')+'>Shopee</option>'+
        '<option value="tiktok"'+(S.filter_status==="tiktok"?' selected':'')+'>TikTok</option>'+
        '<option value="lazada"'+(S.filter_status==="lazada"?' selected':'')+'>Lazada</option>'+
      '</select>'+
      '<div class="list-count">'+orders.length+' pesanan</div>'+
    '</div>'+
    '<div class="card"><div class="table-wrap"><table>'+
      '<thead><tr><th>Order</th><th>Pelanggan</th><th>Channel</th><th>Items</th><th class="ta-r">Total</th><th>Tanggal</th><th>Status</th></tr></thead>'+
      '<tbody>'+orders.map(function(o){
        var sc = o.status==="completed"?"pill-ok":o.status==="shipped"?"pill-info":o.status==="processing"?"pill-warn":"pill-mute";
        var sl = o.status==="completed"?"Selesai":o.status==="shipped"?"Dikirim":o.status==="processing"?"Diproses":o.status;
        var itemCount = o.items.reduce(function(a,i){return a+i.qty;},0);
        return '<tr style="cursor:pointer" onclick="openOrder(\''+o.id+'\')">'+
          '<td><div class="mono" style="font-weight:600;color:var(--navy)">'+esc(o.no)+'</div><div class="mono" style="font-size:10px;color:var(--ink-3);margin-top:2px">'+esc(o.id)+'</div></td>'+
          '<td><div style="font-weight:500;color:var(--navy)">'+esc(o.cust)+'</div><div style="font-size:11px;color:var(--ink-3);margin-top:2px">'+esc(o.phone||"")+'</div></td>'+
          '<td><span class="pill pill-mute">'+channelLabel(o.ch)+'</span></td>'+
          '<td><span class="td-emph">'+itemCount+'</span> <span style="color:var(--ink-3);font-size:11px">'+o.items[0].u+'</span><div style="font-size:10px;color:var(--ink-3);margin-top:2px">'+o.items.length+' jenis</div></td>'+
          '<td class="ta-r td-emph">'+fmtK(o.total)+'</td>'+
          '<td><div style="font-size:12px">'+dateFmt(o.date)+'</div></td>'+
          '<td><span class="pill '+sc+'"><span class="pill-dot"></span>'+sl+'</span></td>'+
        '</tr>';
      }).join('')+'</tbody>'+
    '</table></div></div>';
}
window.openOrder = function(orderId){
  var o = null;
  for(var i=0;i<S.orders.length;i++){ if(S.orders[i].id === orderId){ o = S.orders[i]; break; } }
  if(!o) return;
  var sc = o.status==="completed"?"pill-ok":o.status==="shipped"?"pill-info":"pill-warn";
  var sl = o.status==="completed"?"Selesai":o.status==="shipped"?"Dikirim":"Diproses";
  S.edit_pi = null;
  $("#drawer-content").innerHTML = ''+
    '<div class="drawer-head">'+
      '<button class="btn btn-ghost btn-icon" onclick="closeDrawer()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18M6 6l12 12"/></svg></button>'+
      '<div style="flex:1;min-width:0">'+
        '<h2>Pesanan '+esc(o.no)+'</h2>'+
        '<div class="drawer-head-info">'+esc(o.id)+' · '+dateFmt(o.date)+' · '+channelLabel(o.ch)+'</div>'+
      '</div>'+
      '<span class="pill '+sc+'"><span class="pill-dot"></span>'+sl+'</span>'+
    '</div>'+
    '<div class="drawer-body">'+
      '<div class="card" style="margin-bottom:16px"><div class="card-head"><h3>Pelanggan</h3></div><div class="card-body">'+
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">'+
          '<div><div class="muted" style="font-size:10px;text-transform:uppercase;letter-spacing:.08em;font-weight:600;margin-bottom:4px">Nama</div><div style="font-weight:500;color:var(--navy)">'+esc(o.cust)+'</div></div>'+
          '<div><div class="muted" style="font-size:10px;text-transform:uppercase;letter-spacing:.08em;font-weight:600;margin-bottom:4px">Telepon</div><div class="mono" style="color:var(--navy)">'+esc(o.phone||"-")+'</div></div>'+
          '<div style="grid-column:1/-1"><div class="muted" style="font-size:10px;text-transform:uppercase;letter-spacing:.08em;font-weight:600;margin-bottom:4px">Alamat</div><div style="line-height:1.5;color:var(--ink)">'+esc(o.addr||"-")+'</div></div>'+
        '</div>'+
      '</div></div>'+
      '<div class="card"><div class="card-head"><h3>Items Pesanan</h3><div class="card-head-sub">'+o.items.length+' jenis produk</div></div><div class="card-body" style="padding:0"><div class="table-wrap"><table>'+
        '<thead><tr><th>Produk</th><th>Warna</th><th class="ta-r">Qty</th><th class="ta-r">Harga</th><th class="ta-r">Subtotal</th></tr></thead>'+
        '<tbody>'+o.items.map(function(it){
          return '<tr>'+
            '<td><div style="font-weight:500;color:var(--navy)">'+esc(it.p)+'</div><div class="mono" style="font-size:10px;color:var(--ink-3);margin-top:2px">'+esc(it.sku)+'</div></td>'+
            '<td><div style="display:flex;align-items:center;gap:8px"><div class="cdot" style="background:'+hex(it.c)+'"></div>'+esc(it.c)+'</div></td>'+
            '<td class="ta-r"><b>'+it.qty+'</b> <span style="color:var(--ink-3);font-size:11px">'+esc(it.u)+'</span></td>'+
            '<td class="ta-r mono">'+fmt(it.pr)+'</td>'+
            '<td class="ta-r td-emph">'+fmt(it.qty*it.pr)+'</td>'+
          '</tr>';
        }).join('')+
        '<tr style="background:var(--bg-2)"><td colspan="4" class="ta-r" style="font-weight:600">Total Pesanan</td><td class="ta-r" style="font-family:var(--serif);font-size:18px;font-weight:600;color:var(--gold-2)">'+fmt(o.total)+'</td></tr>'+
        '</tbody>'+
      '</table></div></div></div>'+
    '</div>'+
    '<div class="drawer-foot">'+
      '<button class="btn btn-ghost" onclick="updateOrderStatus(\''+o.id+'\',\'processing\')">Set Diproses</button>'+
      '<button class="btn btn-ghost" onclick="updateOrderStatus(\''+o.id+'\',\'shipped\')">Set Dikirim</button>'+
      '<button class="btn btn-ghost" onclick="updateOrderStatus(\''+o.id+'\',\'completed\')">Set Selesai</button>'+
      '<div class="spacer"></div>'+
      '<button class="btn btn-primary" onclick="printInvoice(\''+o.id+'\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg> Cetak Invoice</button>'+
    '</div>';
  $("#drawer").classList.add("on");
  $("#drawer-bg").classList.add("on");
};
window.updateOrderStatus = function(id, status){
  for(var i=0;i<S.orders.length;i++){
    if(S.orders[i].id === id){ S.orders[i].status = status; break; }
  }
  persist();
  toast("✓ Status order diperbarui");
  closeDrawer();
  render();
};
window.printInvoice = function(id){ toast("Invoice printing terhubung ke Midtrans webhook (production)", "info"); };
window.exportOrders = function(){
  var rows = [["Order","Channel","Customer","Phone","Total","Status","Date"]];
  for(var i=0;i<S.orders.length;i++){
    var o = S.orders[i];
    rows.push([o.no, channelLabel(o.ch), o.cust, o.phone||"", o.total, o.status, o.date]);
  }
  var csv = rows.map(function(r){return r.map(function(c){return '"'+String(c).replace(/"/g,'""')+'"';}).join(",");}).join("\n");
  var a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([csv],{type:"text/csv"}));
  a.download = "giandi-orders-"+new Date().toISOString().slice(0,10)+".csv";
  a.click();
  toast("✓ Orders di-export");
};

/* ═════ CHANNELS PAGE ═════ */
function pageChannels(){
  setCrumb(["Admin","Operasional","Channel"]);
  var channels = [
    {k:"whatsapp", n:"WhatsApp Business", desc:"Channel utama untuk grosir & VIP customer", color:"#25D366", logo:"M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"},
    {k:"shopee", n:"Shopee", desc:"Marketplace #1 di Indonesia", color:"#EE4D2D", logo:"M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4zM3 6h18M16 10a4 4 0 0 1-8 0"},
    {k:"tiktok", n:"TikTok Shop", desc:"Channel video commerce paling cepat tumbuh", color:"#000000", logo:"M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5"},
    {k:"lazada", n:"Lazada", desc:"Marketplace untuk segmentasi reseller", color:"#0F146E", logo:"M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM9 22V12h6v10"}
  ];
  var stats = {};
  for(var i=0;i<S.orders.length;i++){
    var o = S.orders[i];
    if(!stats[o.ch]) stats[o.ch] = {count:0, revenue:0};
    stats[o.ch].count++;
    stats[o.ch].revenue += o.total;
  }
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Operasional</div>'+
        '<h1 class="page-title">Channel</h1>'+
        '<p class="page-sub">Multi-channel commerce · WhatsApp, Shopee, TikTok Shop, Lazada terintegrasi.</p>'+
      '</div>'+
    '</div>'+
    '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px">'+
      channels.map(function(ch){
        var s = stats[ch.k] || {count:0, revenue:0};
        return '<div class="card">'+
          '<div class="card-body">'+
            '<div style="display:flex;align-items:center;gap:12px;margin-bottom:14px">'+
              '<div style="width:40px;height:40px;border-radius:9px;background:'+ch.color+'15;display:grid;place-items:center"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="'+ch.color+'" stroke-width="1.8"><path d="'+ch.logo+'"/></svg></div>'+
              '<div><h3 style="font-size:15px;margin-bottom:1px">'+esc(ch.n)+'</h3><div style="font-size:11px;color:var(--ink-3)">'+esc(ch.desc)+'</div></div>'+
            '</div>'+
            '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">'+
              '<div style="background:var(--bg-2);border-radius:9px;padding:10px 12px"><div style="font-size:10px;color:var(--ink-2);font-weight:600;text-transform:uppercase;letter-spacing:.06em">Pesanan</div><div style="font-family:var(--serif);font-size:20px;font-weight:600;color:var(--navy);margin-top:2px">'+s.count+'</div></div>'+
              '<div style="background:var(--bg-2);border-radius:9px;padding:10px 12px"><div style="font-size:10px;color:var(--ink-2);font-weight:600;text-transform:uppercase;letter-spacing:.06em">Revenue</div><div style="font-family:var(--serif);font-size:20px;font-weight:600;color:var(--gold-2);margin-top:2px">'+fmtK(s.revenue)+'</div></div>'+
            '</div>'+
            '<button class="btn btn-outline" style="width:100%" onclick="S.filter_status=\''+ch.k+'\';go(\'orders\')">Lihat Pesanan →</button>'+
          '</div>'+
        '</div>';
      }).join('')+
    '</div>';
}

/* ═════ CUSTOMERS PAGE ═════ */
function pageCustomers(){
  setCrumb(["Admin","Operasional","Pelanggan"]);
  var customers = S.customers.slice().sort(function(a,b){return b.spent-a.spent;});
  if(S.q){
    var q = S.q.toLowerCase();
    customers = customers.filter(function(c){return c.name.toLowerCase().indexOf(q)>=0||(c.phone||"").indexOf(q)>=0||(c.city||"").toLowerCase().indexOf(q)>=0;});
  }
  if(S.filter_status) customers = customers.filter(function(c){return c.tier===S.filter_status;});
  var vipCnt = S.customers.filter(function(c){return c.tier==="VIP";}).length;
  var loyalCnt = S.customers.filter(function(c){return c.tier==="Loyal";}).length;
  var newCnt = S.customers.filter(function(c){return c.tier==="New";}).length;
  var totalSpent = S.customers.reduce(function(a,c){return a+c.spent;},0);
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Operasional</div>'+
        '<h1 class="page-title">Pelanggan</h1>'+
        '<p class="page-sub">'+S.customers.length+' pelanggan tersimpan · CRM dengan segmentasi otomatis VIP, Loyal, New.</p>'+
      '</div>'+
    '</div>'+
    '<div class="kpi-row">'+
      '<div class="kpi"><div class="kpi-lbl">Total Pelanggan</div><div class="kpi-val">'+S.customers.length+'</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">VIP</div><div class="kpi-val" style="color:var(--gold-2)">'+vipCnt+'</div><div class="kpi-sub">Min. Rp 50jt belanja</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Loyal</div><div class="kpi-val">'+loyalCnt+'</div><div class="kpi-sub">3+ orders</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Lifetime Value</div><div class="kpi-val">'+fmtK(totalSpent)+'</div></div>'+
    '</div>'+
    '<div class="list-tools">'+
      '<div class="list-search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input placeholder="Cari nama, telepon, kota..." value="'+esc(S.q)+'" oninput="setQ(this.value)" /></div>'+
      '<select onchange="S.filter_status=this.value;render()" style="width:auto;min-width:120px">'+
        '<option value="">Semua Tier</option>'+
        '<option value="VIP"'+(S.filter_status==="VIP"?' selected':'')+'>VIP</option>'+
        '<option value="Loyal"'+(S.filter_status==="Loyal"?' selected':'')+'>Loyal</option>'+
        '<option value="New"'+(S.filter_status==="New"?' selected':'')+'>New</option>'+
      '</select>'+
      '<div class="list-count">'+customers.length+' pelanggan</div>'+
    '</div>'+
    '<div class="card"><div class="table-wrap"><table>'+
      '<thead><tr><th>Pelanggan</th><th>Kontak</th><th>Lokasi</th><th>Tier</th><th class="ta-r">Orders</th><th class="ta-r">Total Belanja</th><th>Sejak</th></tr></thead>'+
      '<tbody>'+customers.map(function(c){
        var pillCls = c.tier==="VIP"?"pill-gold":c.tier==="Loyal"?"pill-info":"pill-mute";
        var initials = c.name.split(/\s+/).slice(0,2).map(function(w){return w.charAt(0);}).join("").toUpperCase();
        var avatarCls = c.tier==="VIP" ? "cust-avatar vip" : "cust-avatar";
        return '<tr>'+
          '<td><div class="prod-cell"><div class="'+avatarCls+'">'+initials+'</div><div><div style="font-weight:600;color:var(--navy)">'+esc(c.name)+'</div><div class="mono" style="font-size:10px;color:var(--ink-3)">'+c.id+'</div></div></div></td>'+
          '<td><div class="mono" style="font-size:11px">'+esc(c.phone||"")+'</div>'+(c.email?'<div style="font-size:10px;color:var(--ink-3);margin-top:2px">'+esc(c.email)+'</div>':'')+'</td>'+
          '<td>'+esc(c.city||"-")+'</td>'+
          '<td><span class="pill '+pillCls+'"><span class="pill-dot"></span>'+c.tier+'</span></td>'+
          '<td class="ta-r td-emph">'+c.orders+'</td>'+
          '<td class="ta-r td-emph">'+fmtK(c.spent)+'</td>'+
          '<td><div style="font-size:12px">'+dateFmt(c.since)+'</div></td>'+
        '</tr>';
      }).join('')+'</tbody>'+
    '</table></div></div>';
}

/* ═════ SHIPPING PAGE ═════ */
function pageShipping(){
  setCrumb(["Admin","Operasional","Pengiriman"]);
  var couriers = [
    {n:"JNE",svc:"REG, OKE, YES",active:true,orders:12,color:"#C8202F"},
    {n:"J&T Express",svc:"REG, EZ",active:true,orders:8,color:"#E03434"},
    {n:"SiCepat",svc:"REG, BEST, SDS",active:true,orders:5,color:"#E64A4A"},
    {n:"AnterAja",svc:"NextDay, Regular",active:true,orders:3,color:"#0096D6"},
    {n:"Pos Indonesia",svc:"Regular, Express",active:false,orders:0,color:"#F39C12"},
    {n:"GoSend",svc:"Same Day, Instant",active:true,orders:6,color:"#00AA13"}
  ];
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Operasional</div>'+
        '<h1 class="page-title">Pengiriman</h1>'+
        '<p class="page-sub">Integrasi kurir via RajaOngkir API · 6 kurir, real-time pricing, dan tracking otomatis.</p>'+
      '</div>'+
    '</div>'+
    '<div class="kpi-row">'+
      '<div class="kpi"><div class="kpi-lbl">Kurir Aktif</div><div class="kpi-val">'+couriers.filter(function(c){return c.active;}).length+'</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Pengiriman Hari Ini</div><div class="kpi-val">'+S.orders.filter(function(o){return o.status==="shipped";}).length+'</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Estimasi Sampai</div><div class="kpi-val">2-3 hari</div><div class="kpi-sub">Rata-rata Jabodetabek</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Free Shipping</div><div class="kpi-val">'+fmtK(S.store.business_rules.free_shipping_min)+'</div><div class="kpi-sub">Min. order</div></div>'+
    '</div>'+
    '<div style="display:grid;grid-template-columns:1.4fr 1fr;gap:20px;margin-bottom:20px">'+
      '<div class="card">'+
        '<div class="card-head"><h3>Kurir Tersedia</h3><div class="card-head-sub">Atur kurir yang ditampilkan saat checkout</div></div>'+
        '<div class="card-body" style="padding:0"><div class="table-wrap"><table>'+
          '<thead><tr><th>Kurir</th><th>Layanan</th><th class="ta-r">Pengiriman</th><th>Status</th></tr></thead>'+
          '<tbody>'+couriers.map(function(c){
            return '<tr>'+
              '<td><div style="display:flex;align-items:center;gap:10px"><div style="width:32px;height:32px;border-radius:7px;background:'+c.color+'18;color:'+c.color+';display:grid;place-items:center;font-weight:700;font-size:11px;font-family:var(--mono)">'+c.n.substring(0,3).toUpperCase()+'</div><b style="color:var(--navy)">'+esc(c.n)+'</b></div></td>'+
              '<td style="font-size:12px;color:var(--ink-2)">'+esc(c.svc)+'</td>'+
              '<td class="ta-r td-emph">'+c.orders+'</td>'+
              '<td><span class="pill '+(c.active?"pill-ok":"pill-mute")+'"><span class="pill-dot"></span>'+(c.active?"Aktif":"Nonaktif")+'</span></td>'+
            '</tr>';
          }).join('')+'</tbody>'+
        '</table></div></div>'+
      '</div>'+
      '<div class="card">'+
        '<div class="card-head"><h3>Integrasi API</h3></div>'+
        '<div class="card-body">'+
          '<div style="background:var(--bg-2);border-radius:10px;padding:14px;margin-bottom:12px">'+
            '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><b>RajaOngkir</b><span class="pill pill-ok"><span class="pill-dot"></span>Connected</span></div>'+
            '<div style="font-size:11px;color:var(--ink-2);line-height:1.5">Real-time ongkir untuk seluruh Indonesia. Auto-update saat customer pilih alamat.</div>'+
          '</div>'+
          '<div style="background:var(--bg-2);border-radius:10px;padding:14px"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><b>Tracking Webhook</b><span class="pill pill-ok"><span class="pill-dot"></span>Active</span></div>'+
            '<div style="font-size:11px;color:var(--ink-2);line-height:1.5">Notifikasi otomatis ke WhatsApp customer setiap update status pengiriman.</div>'+
          '</div>'+
        '</div>'+
      '</div>'+
    '</div>'+
    '<div class="card">'+
      '<div class="card-head"><h3>Aturan Pengiriman</h3></div>'+
      '<div class="card-body">'+
        '<div class="form-row two">'+
          '<div><label>Free Shipping Threshold</label><div class="inp-prefix"><span class="prefix">Rp</span><input class="inp inp-num" type="number" value="'+S.store.business_rules.free_shipping_min+'" oninput="S.store.business_rules.free_shipping_min=parseInt(this.value)||0;persist()" /></div></div>'+
          '<div><label>Cut-off Same Day Shipping</label><input type="time" class="inp" value="14:00" /></div>'+
        '</div>'+
      '</div>'+
    '</div>';
}

/* ═════ FINANCE PAGE ═════ */
function pageFinance(){
  setCrumb(["Admin","Operasional","Keuangan"]);
  var totalRev = S.orders.reduce(function(a,o){return a+o.total;},0);
  var byMonth = {};
  for(var i=0;i<S.orders.length;i++){
    var m = S.orders[i].date.slice(0,7);
    byMonth[m] = (byMonth[m]||0) + S.orders[i].total;
  }
  var months = Object.keys(byMonth).sort();
  var maxM = Math.max.apply(null, months.map(function(m){return byMonth[m];}));
  // Estimate margin
  var totalCost = 0;
  for(var i=0;i<S.orders.length;i++){
    var o = S.orders[i];
    for(var j=0;j<o.items.length;j++){
      var it = o.items[j];
      var p = null;
      for(var k=0;k<S.products.length;k++) if(S.products[k].sku===it.sku){p=S.products[k];break;}
      if(p) totalCost += (p.cost||0) * it.qty * (it.u==="yard"?0.9:1);
    }
  }
  var profit = totalRev - totalCost;
  var margin = totalRev ? Math.round((profit/totalRev)*100) : 0;
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Operasional</div>'+
        '<h1 class="page-title">Keuangan</h1>'+
        '<p class="page-sub">Ringkasan pendapatan, biaya, profit, dan trend bulanan dari semua channel.</p>'+
      '</div>'+
    '</div>'+
    '<div class="kpi-row">'+
      '<div class="kpi"><div class="kpi-lbl">Total Pendapatan</div><div class="kpi-val">'+fmtK(totalRev)+'</div><div class="kpi-sub">'+S.orders.length+' transaksi</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">HPP Estimasi</div><div class="kpi-val">'+fmtK(totalCost)+'</div><div class="kpi-sub">Cost of Goods Sold</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Profit Kotor</div><div class="kpi-val" style="color:var(--ok)">'+fmtK(profit)+'</div><div class="kpi-sub">Sebelum operasional</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Margin Rata-rata</div><div class="kpi-val">'+margin+'%</div><div class="kpi-trend up">↑ Healthy</div></div>'+
    '</div>'+
    '<div class="card" style="margin-bottom:20px">'+
      '<div class="card-head"><h3>Trend Bulanan</h3></div>'+
      '<div class="card-body">'+
        '<div class="bar-chart">'+
          months.map(function(m){
            var pct = (byMonth[m]/maxM)*100;
            var label = new Date(m+"-01").toLocaleDateString("id-ID",{month:"short",year:"2-digit"});
            return '<div class="bar" style="height:'+pct+'%"><div class="bar-val">'+fmtK(byMonth[m])+'</div><div class="bar-lbl">'+label+'</div></div>';
          }).join('')+
        '</div>'+
        '<div style="margin-top:24px"></div>'+
      '</div>'+
    '</div>'+
    '<div class="card">'+
      '<div class="card-head"><h3>Detail Transaksi</h3><div class="card-head-sub">'+S.orders.length+' transaksi semua channel</div></div>'+
      '<div class="card-body" style="padding:0"><div class="table-wrap"><table>'+
        '<thead><tr><th>Tanggal</th><th>Order</th><th>Channel</th><th>Pelanggan</th><th class="ta-r">Nilai</th></tr></thead>'+
        '<tbody>'+S.orders.slice().sort(function(a,b){return new Date(b.date)-new Date(a.date);}).slice(0,30).map(function(o){
          return '<tr>'+
            '<td><div style="font-size:12px">'+dateFmt(o.date)+'</div></td>'+
            '<td class="mono" style="color:var(--navy);font-weight:600">'+esc(o.no)+'</td>'+
            '<td><span class="pill pill-mute">'+channelLabel(o.ch)+'</span></td>'+
            '<td>'+esc(o.cust)+'</td>'+
            '<td class="ta-r td-emph">'+fmt(o.total)+'</td>'+
          '</tr>';
        }).join('')+'</tbody>'+
      '</table></div></div>'+
    '</div>';
}

/* ═════ CAMPAIGNS PAGE ═════ */
function pageCampaigns(){
  setCrumb(["Admin","Marketing","Kampanye Iklan"]);
  var total = S.campaigns.length;
  var running = S.campaigns.filter(function(c){return c.status==="running";}).length;
  var totalBudget = S.campaigns.reduce(function(a,c){return a+c.budget;},0);
  var totalSpent = S.campaigns.reduce(function(a,c){return a+c.spent;},0);
  var avgROAS = S.campaigns.length ? (S.campaigns.reduce(function(a,c){return a+c.roas;},0)/S.campaigns.length).toFixed(1) : 0;
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Marketing</div>'+
        '<h1 class="page-title">Kampanye Iklan</h1>'+
        '<p class="page-sub">Meta Ads, TikTok Ads, Google Ads terintegrasi · monitor ROAS, budget, dan konversi real-time.</p>'+
      '</div>'+
      '<div class="page-actions">'+
        '<button class="btn btn-primary" onclick="toast(\'Buat kampanye baru — terhubung ke Meta Ads API saat production.\',\'info\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 5v14M5 12h14"/></svg> Kampanye Baru</button>'+
      '</div>'+
    '</div>'+
    '<div class="kpi-row">'+
      '<div class="kpi"><div class="kpi-lbl">Total Kampanye</div><div class="kpi-val">'+total+'</div><div class="kpi-sub">'+running+' running</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Total Budget</div><div class="kpi-val">'+fmtK(totalBudget)+'</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Total Spent</div><div class="kpi-val">'+fmtK(totalSpent)+'</div><div class="kpi-sub">'+Math.round((totalSpent/totalBudget)*100)+'% utilization</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Avg ROAS</div><div class="kpi-val" style="color:var(--ok)">'+avgROAS+'x</div><div class="kpi-trend up">↑ Profitable</div></div>'+
    '</div>'+
    '<div class="card"><div class="table-wrap"><table>'+
      '<thead><tr><th>Kampanye</th><th>Platform</th><th class="ta-r">Budget</th><th class="ta-r">Spent</th><th class="ta-r">Klik</th><th class="ta-r">Konversi</th><th class="ta-r">ROAS</th><th>Status</th></tr></thead>'+
      '<tbody>'+S.campaigns.map(function(c){
        var sc = c.status==="running"?"pill-ok":c.status==="completed"?"pill-mute":"pill-warn";
        var sl = c.status==="running"?"Running":c.status==="completed"?"Selesai":"Paused";
        var platCol = c.platform==="meta"?"#1877F2":c.platform==="tiktok"?"#000000":"#4285F4";
        var spent_pct = Math.round((c.spent/c.budget)*100);
        return '<tr>'+
          '<td><div style="font-weight:600;color:var(--navy)">'+esc(c.name)+'</div><div style="font-size:10px;color:var(--ink-3);margin-top:2px;font-family:var(--mono)">'+c.id+'</div></td>'+
          '<td><span class="pill" style="background:'+platCol+'15;color:'+platCol+'">'+(c.platform==="meta"?"Meta Ads":c.platform==="tiktok"?"TikTok":"Google")+'</span></td>'+
          '<td class="ta-r td-emph">'+fmtK(c.budget)+'</td>'+
          '<td class="ta-r"><div style="font-weight:600">'+fmtK(c.spent)+'</div><div style="height:4px;background:var(--bg-2);border-radius:2px;margin-top:4px;overflow:hidden"><div style="width:'+spent_pct+'%;height:100%;background:var(--gold)"></div></div></td>'+
          '<td class="ta-r mono">'+fmtNum(c.clicks)+'</td>'+
          '<td class="ta-r mono">'+c.conversions+'</td>'+
          '<td class="ta-r"><b style="font-size:14px;color:'+(c.roas>=3?"var(--ok)":"var(--warn)")+'">'+c.roas+'x</b></td>'+
          '<td><span class="pill '+sc+'"><span class="pill-dot"></span>'+sl+'</span></td>'+
        '</tr>';
      }).join('')+'</tbody>'+
    '</table></div></div>';
}

/* ═════ VOUCHERS PAGE ═════ */
function pageVouchers(){
  setCrumb(["Admin","Marketing","Voucher"]);
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Marketing</div>'+
        '<h1 class="page-title">Voucher & Kode Promo</h1>'+
        '<p class="page-sub">Kelola voucher diskon untuk semua channel · WhatsApp, marketplace, dan website.</p>'+
      '</div>'+
      '<div class="page-actions">'+
        '<button class="btn btn-primary" onclick="newVoucher()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 5v14M5 12h14"/></svg> Voucher Baru</button>'+
      '</div>'+
    '</div>'+
    '<div class="kpi-row">'+
      '<div class="kpi"><div class="kpi-lbl">Voucher Aktif</div><div class="kpi-val">'+S.vouchers.filter(function(v){return v.active;}).length+'</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Total Penggunaan</div><div class="kpi-val">'+S.vouchers.reduce(function(a,v){return a+v.uses;},0)+'</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Voucher Berakhir</div><div class="kpi-val">'+S.vouchers.filter(function(v){return new Date(v.expires)<new Date();}).length+'</div></div>'+
      '<div class="kpi"><div class="kpi-lbl">Total Diskon Diberikan</div><div class="kpi-val">'+fmtK(S.vouchers.reduce(function(a,v){return a+(v.type==="fixed"?v.value:50000)*v.uses;},0))+'</div></div>'+
    '</div>'+
    '<div class="card"><div class="table-wrap"><table>'+
      '<thead><tr><th>Kode</th><th>Deskripsi</th><th>Tipe</th><th class="ta-r">Diskon</th><th class="ta-r">Min. Order</th><th>Pemakaian</th><th>Berakhir</th><th>Status</th></tr></thead>'+
      '<tbody>'+S.vouchers.map(function(v){
        var usePct = Math.round((v.uses/v.limit)*100);
        return '<tr>'+
          '<td><div class="mono" style="font-weight:700;color:var(--navy);font-size:13px;background:var(--gold-bg);padding:4px 10px;border-radius:6px;display:inline-block">'+esc(v.code)+'</div></td>'+
          '<td><div style="font-size:12px;color:var(--ink-2);max-width:240px">'+esc(v.desc)+'</div></td>'+
          '<td><span class="pill pill-info">'+(v.type==="percent"?"Persentase":"Tetap")+'</span></td>'+
          '<td class="ta-r td-emph">'+(v.type==="percent"?v.value+"%":fmt(v.value))+'</td>'+
          '<td class="ta-r mono">'+fmt(v.min)+'</td>'+
          '<td><div style="font-size:12px">'+v.uses+' / '+v.limit+'</div><div style="height:4px;background:var(--bg-2);border-radius:2px;margin-top:4px"><div style="width:'+usePct+'%;height:100%;background:var(--gold);border-radius:2px"></div></div></td>'+
          '<td><div style="font-size:12px">'+dateFmt(v.expires)+'</div></td>'+
          '<td><span class="pill '+(v.active?"pill-ok":"pill-mute")+'"><span class="pill-dot"></span>'+(v.active?"Aktif":"Nonaktif")+'</span></td>'+
        '</tr>';
      }).join('')+'</tbody>'+
    '</table></div></div>';
}
window.newVoucher = function(){
  openModal(''+
    '<h3>Voucher Baru</h3>'+
    '<p class="modal-sub">Buat kode promo yang dapat digunakan pelanggan saat checkout.</p>'+
    '<div class="form-grid">'+
      '<div><label>Kode Voucher</label><input class="inp mono" id="nv-code" placeholder="WELCOME15" style="text-transform:uppercase" /></div>'+
      '<div><label>Deskripsi</label><input class="inp" id="nv-desc" placeholder="15% off untuk pelanggan baru" /></div>'+
      '<div class="form-row two">'+
        '<div><label>Tipe</label><select id="nv-type"><option value="percent">Persentase (%)</option><option value="fixed">Nilai Tetap (Rp)</option></select></div>'+
        '<div><label>Nilai</label><input class="inp inp-num" type="number" id="nv-value" placeholder="15" /></div>'+
      '</div>'+
      '<div class="form-row two">'+
        '<div><label>Min. Order</label><div class="inp-prefix"><span class="prefix">Rp</span><input class="inp inp-num" type="number" id="nv-min" placeholder="0" /></div></div>'+
        '<div><label>Limit Pemakaian</label><input class="inp inp-num" type="number" id="nv-limit" placeholder="100" /></div>'+
      '</div>'+
      '<div><label>Berakhir</label><input class="inp" type="date" id="nv-expires" /></div>'+
    '</div>'+
    '<div class="modal-actions">'+
      '<button class="btn btn-outline" onclick="closeModal()">Batal</button>'+
      '<button class="btn btn-primary" onclick="confirmNewVoucher()">Buat Voucher</button>'+
    '</div>'
  );
};
window.confirmNewVoucher = function(){
  var code = $("#nv-code").value.trim().toUpperCase();
  if(!code){ toast("Kode voucher diperlukan","error"); return; }
  S.vouchers.push({
    id:"V"+Math.random().toString(36).slice(2,6).toUpperCase(),
    code:code,
    desc:$("#nv-desc").value||"",
    type:$("#nv-type").value,
    value:parseInt($("#nv-value").value)||0,
    min:parseInt($("#nv-min").value)||0,
    max:0,
    uses:0,
    limit:parseInt($("#nv-limit").value)||100,
    expires:$("#nv-expires").value||new Date(Date.now()+30*24*3600*1000).toISOString().slice(0,10),
    active:true
  });
  persist();
  closeModal();
  render();
  toast("✓ Voucher dibuat");
};

/* ═════ FLASH SALE PAGE ═════ */
function pageFlashSale(){
  setCrumb(["Admin","Marketing","Flash Sale"]);
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Marketing</div>'+
        '<h1 class="page-title">Flash Sale</h1>'+
        '<p class="page-sub">Flash sale terjadwal dengan countdown timer otomatis di storefront.</p>'+
      '</div>'+
      '<div class="page-actions"><button class="btn btn-primary" onclick="toast(\'Setup flash sale baru — tersinkronisasi ke storefront secara real-time.\',\'info\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 5v14M5 12h14"/></svg> Jadwalkan Sale</button></div>'+
    '</div>'+
    '<div class="card">'+
      '<div class="card-body">'+
        '<div style="background:linear-gradient(135deg,var(--navy),var(--navy-2));color:#fff;border-radius:12px;padding:28px;text-align:center;margin-bottom:24px">'+
          '<div style="font-size:11px;letter-spacing:.2em;color:var(--gold);font-weight:600;text-transform:uppercase;margin-bottom:8px">Upcoming Flash Sale</div>'+
          '<h2 style="font-size:32px;color:#fff;margin-bottom:6px">Lebaran Premium Sale 2026</h2>'+
          '<p style="color:rgba(255,255,255,.7);margin-bottom:20px">Diskon hingga 30% untuk seluruh koleksi Premium Silk · 3 hari saja</p>'+
          '<div style="display:flex;gap:16px;justify-content:center;margin-bottom:20px">'+
            '<div style="background:rgba(255,255,255,.1);border-radius:9px;padding:12px 20px;min-width:80px"><div style="font-family:var(--serif);font-size:28px;font-weight:600;color:#fff">14</div><div style="font-size:10px;color:rgba(255,255,255,.7);letter-spacing:.1em;text-transform:uppercase">Hari</div></div>'+
            '<div style="background:rgba(255,255,255,.1);border-radius:9px;padding:12px 20px;min-width:80px"><div style="font-family:var(--serif);font-size:28px;font-weight:600;color:#fff">06</div><div style="font-size:10px;color:rgba(255,255,255,.7);letter-spacing:.1em;text-transform:uppercase">Jam</div></div>'+
            '<div style="background:rgba(255,255,255,.1);border-radius:9px;padding:12px 20px;min-width:80px"><div style="font-family:var(--serif);font-size:28px;font-weight:600;color:#fff">42</div><div style="font-size:10px;color:rgba(255,255,255,.7);letter-spacing:.1em;text-transform:uppercase">Menit</div></div>'+
            '<div style="background:rgba(255,255,255,.1);border-radius:9px;padding:12px 20px;min-width:80px"><div style="font-family:var(--serif);font-size:28px;font-weight:600;color:#fff">18</div><div style="font-size:10px;color:rgba(255,255,255,.7);letter-spacing:.1em;text-transform:uppercase">Detik</div></div>'+
          '</div>'+
          '<button class="btn btn-gold">Edit Detail</button>'+
        '</div>'+
        '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px">'+
          ['Diskon Hingga 30%','3 Hari Saja','3 Premium Silk','Semua Channel'].map(function(t,i){
            return '<div style="background:var(--bg-2);border-radius:10px;padding:14px"><div style="font-size:10px;color:var(--ink-2);font-weight:600;text-transform:uppercase;letter-spacing:.06em">'+['Diskon','Durasi','Produk','Jangkauan'][i]+'</div><div style="font-family:var(--serif);font-size:18px;font-weight:600;color:var(--navy);margin-top:2px">'+t+'</div></div>';
          }).join('')+
        '</div>'+
      '</div>'+
    '</div>';
}

/* ═════ STOREFRONT EDITOR (Zara-Style) ═════ */
function pageStorefront(){
  setCrumb(["Admin","Toko","Hero Banner"]);
  var slides = S.store.hero_slides || [];
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Toko</div>'+
        '<h1 class="page-title">Hero Banner</h1>'+
        '<p class="page-sub">Editor hero banner seperti Zara · multiple slides · support gambar dan video · scheduling per slide.</p>'+
      '</div>'+
      '<div class="page-actions">'+
        '<button class="btn btn-outline" onclick="resetStore()">Reset Default</button>'+
        '<button class="btn btn-primary" onclick="saveStore()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12l5 5 9-11"/></svg> Simpan Semua</button>'+
      '</div>'+
    '</div>'+
    '<div class="editor-grid">'+
      '<div>'+
        '<div style="margin-bottom:14px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">'+
          '<div><label style="margin-bottom:2px">Hero Slides · '+slides.length+' slide</label><div class="field-hint">Tambah slide dengan gambar atau video. Slide aktif akan rotasi otomatis di homepage.</div></div>'+
          '<button class="btn btn-outline btn-sm" onclick="addSlide()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 5v14M5 12h14"/></svg> Tambah Slide</button>'+
        '</div>'+
        slides.map(function(s,i){
          var mediaPreview;
          if(s.video){
            mediaPreview = '<video src="'+s.video+'" muted autoplay loop style="width:100%;height:140px;object-fit:cover;border-radius:8px;background:var(--bg-2)"></video>';
          } else if(s.image){
            mediaPreview = '<img src="'+s.image+'" style="width:100%;height:140px;object-fit:cover;border-radius:8px"/>';
          } else {
            mediaPreview = '<div style="width:100%;height:140px;border-radius:8px;background:linear-gradient(135deg,var(--navy),var(--navy-2));display:grid;place-items:center;color:rgba(255,255,255,.4);font-size:11px">Belum ada media</div>';
          }
          return '<div class="slide-card">'+
            '<div class="slide-card-head">'+
              '<div class="slide-card-head-l">'+
                '<div class="slide-num">'+(i+1)+'</div>'+
                '<div><b>Slide '+(i+1)+'</b><div style="font-size:11px;color:var(--ink-3);margin-top:1px">'+esc(s.title||"Untitled").substring(0,50)+'</div></div>'+
              '</div>'+
              '<div style="display:flex;gap:6px;align-items:center">'+
                '<span class="pill '+(s.active?"pill-ok":"pill-mute")+'"><span class="pill-dot"></span>'+(s.active?"Aktif":"Draft")+'</span>'+
                (i>0?'<button class="btn btn-ghost btn-icon btn-sm" onclick="moveSlide('+i+',-1)" title="Naik"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="18 15 12 9 6 15"/></svg></button>':'')+
                (i<slides.length-1?'<button class="btn btn-ghost btn-icon btn-sm" onclick="moveSlide('+i+',1)" title="Turun"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="6 9 12 15 18 9"/></svg></button>':'')+
                '<button class="btn btn-ghost btn-icon btn-sm" onclick="deleteSlide('+i+')" title="Hapus" style="color:var(--err)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="3 6 5 6 21 6"/></svg></button>'+
              '</div>'+
            '</div>'+
            '<div class="slide-card-body">'+
              '<div class="form-row two">'+
                '<div>'+
                  '<label>Media Slide</label>'+
                  mediaPreview+
                  '<div style="display:flex;gap:6px;margin-top:8px">'+
                    '<label class="btn btn-outline btn-sm" style="flex:1"><input type="file" accept="image/*" style="display:none" onchange="uploadSlideMedia('+i+',\'image\',this.files[0])" /><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/></svg> Foto</label>'+
                    '<label class="btn btn-outline btn-sm" style="flex:1"><input type="file" accept="video/*" style="display:none" onchange="uploadSlideMedia('+i+',\'video\',this.files[0])" /><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg> Video</label>'+
                  '</div>'+
                '</div>'+
                '<div>'+
                  '<div><label>Eyebrow Text</label><input class="inp" value="'+esc(s.eyebrow||"")+'" oninput="updateSlide('+i+',\'eyebrow\',this.value)" placeholder="Premium Silk · 2026" /></div>'+
                  '<div style="margin-top:14px"><label>Judul Utama</label><textarea oninput="updateSlide('+i+',\'title\',this.value)" rows="2">'+esc(s.title||"")+'</textarea></div>'+
                '</div>'+
              '</div>'+
              '<div style="margin-top:14px"><label>Sub-judul</label><textarea oninput="updateSlide('+i+',\'subtitle\',this.value)" rows="2">'+esc(s.subtitle||"")+'</textarea></div>'+
              '<div class="form-row two" style="margin-top:14px">'+
                '<div><label>Tombol Utama</label><input class="inp" value="'+esc(s.cta_primary||"")+'" oninput="updateSlide('+i+',\'cta_primary\',this.value)" placeholder="Lihat Koleksi" /></div>'+
                '<div><label>Link Tombol Utama</label><input class="inp" value="'+esc(s.cta_primary_link||"/shop")+'" oninput="updateSlide('+i+',\'cta_primary_link\',this.value)" /></div>'+
              '</div>'+
              '<div class="form-row two" style="margin-top:14px">'+
                '<div><label>Tombol Kedua <span class="hint">opsional</span></label><input class="inp" value="'+esc(s.cta_secondary||"")+'" oninput="updateSlide('+i+',\'cta_secondary\',this.value)" /></div>'+
                '<div><label>Link Tombol Kedua</label><input class="inp" value="'+esc(s.cta_secondary_link||"")+'" oninput="updateSlide('+i+',\'cta_secondary_link\',this.value)" /></div>'+
              '</div>'+
              '<div class="form-row two" style="margin-top:14px">'+
                '<div><label>Overlay Opacity <span class="hint">0-1</span></label><input class="inp inp-num" type="number" step="0.1" min="0" max="1" value="'+(s.overlay||0.4)+'" oninput="updateSlide('+i+',\'overlay\',parseFloat(this.value))" /></div>'+
                '<div><label>Status</label><div style="display:flex;gap:6px"><button class="chip '+(s.active?"on":"")+'" onclick="updateSlide('+i+',\'active\',true);render()">Aktif</button><button class="chip '+(!s.active?"on":"")+'" onclick="updateSlide('+i+',\'active\',false);render()">Draft</button></div></div>'+
              '</div>'+
            '</div>'+
          '</div>';
        }).join('')+
      '</div>'+
      '<aside class="preview-pane">'+
        '<div class="preview-bar">'+
          '<div class="preview-dot r"></div><div class="preview-dot y"></div><div class="preview-dot g"></div>'+
          '<span style="margin-left:8px;font-size:11px">gianditextile.com</span>'+
        '</div>'+
        '<div class="preview-area" id="preview"></div>'+
      '</aside>'+
    '</div>';
}
window.updateSlide = function(i, key, val){
  S.store.hero_slides[i][key] = val;
  if(key !== "active") updatePreview();
};
window.addSlide = function(){
  if(!S.store.hero_slides) S.store.hero_slides = [];
  S.store.hero_slides.push({type:"image",eyebrow:"New Collection",title:"Slide Baru",subtitle:"Edit deskripsi slide ini.",cta_primary:"Lihat",cta_primary_link:"/shop",cta_secondary:"",cta_secondary_link:"",image:"",video:"",overlay:0.4,active:false});
  render();
  toast("✓ Slide ditambahkan");
};
window.deleteSlide = function(i){
  if(!confirm("Hapus slide ini?")) return;
  S.store.hero_slides.splice(i, 1);
  render();
  toast("✓ Slide dihapus");
};
window.moveSlide = function(i, dir){
  var slides = S.store.hero_slides;
  if(i+dir<0||i+dir>=slides.length) return;
  var tmp = slides[i]; slides[i] = slides[i+dir]; slides[i+dir] = tmp;
  render();
};
window.uploadSlideMedia = function(i, type, file){
  if(!file) return;
  var r = new FileReader();
  r.onload = function(e){
    if(type==="video"){ S.store.hero_slides[i].video = e.target.result; S.store.hero_slides[i].image = ""; }
    else { S.store.hero_slides[i].image = e.target.result; S.store.hero_slides[i].video = ""; }
    render();
    toast("✓ "+type+" diupload");
  };
  r.readAsDataURL(file);
};
window.saveStore = function(){
  persist();
  toast("✓ Storefront disimpan · live di gianditextile.com");
};
window.resetStore = function(){
  if(!confirm("Reset hero ke default?")) return;
  S.store = JSON.parse(JSON.stringify(window.GIANDI_STORE));
  persist();
  render();
  toast("✓ Reset ke default");
};
window.updatePreview = function(){
  var el = document.getElementById("preview");
  if(!el) return;
  var st = S.store;
  var activeSlides = (st.hero_slides||[]).filter(function(s){return s.active;});
  var slide = activeSlides[0] || st.hero_slides[0] || {};
  var bgMedia = "";
  if(slide.video){
    bgMedia = '<video src="'+slide.video+'" muted autoplay loop style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover"></video>';
  } else if(slide.image){
    bgMedia = '<img src="'+slide.image+'" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover"/>';
  }
  el.innerHTML = ''+
    '<div class="spp">'+
      '<div class="spp-bar">'+
        '<div><div class="spp-bar-brand">'+esc(st.brand_name)+'</div><div class="spp-bar-tag">'+esc(st.brand_tag)+'</div></div>'+
        '<div class="spp-bar-nav">Beranda · Koleksi · Tentang</div>'+
      '</div>'+
      '<div class="spp-hero" style="background:'+(slide.image||slide.video?"transparent":st.theme.primary)+'">'+
        bgMedia+
        (bgMedia?'<div style="position:absolute;inset:0;background:rgba(15,23,42,'+(slide.overlay||0.4)+')"></div>':'')+
        '<div style="position:relative;z-index:2">'+
          '<div class="spp-eb">'+esc(slide.eyebrow||"")+'</div>'+
          '<h2>'+esc(slide.title||"")+'</h2>'+
          '<p>'+esc(slide.subtitle||"")+'</p>'+
          (slide.cta_primary?'<button class="btn-sm" style="background:'+st.theme.accent+';color:#fff">'+esc(slide.cta_primary)+'</button>':'')+
          (slide.cta_secondary?'<button class="btn-sm" style="background:transparent;color:#fff;border:1px solid rgba(255,255,255,.3)">'+esc(slide.cta_secondary)+'</button>':'')+
        '</div>'+
      '</div>'+
      '<div style="margin-top:14px;font-size:9px;color:var(--ink-3);letter-spacing:.16em;text-transform:uppercase;font-weight:600">Koleksi Pilihan</div>'+
      '<div class="spp-grid">'+
        S.products.filter(function(p){return p.active;}).slice(0,4).map(function(p){
          return '<div class="spp-card">'+
            '<div class="spp-card-img" style="background:linear-gradient(135deg,'+hex(p.colors[0])+','+hex(p.colors[1]||p.colors[0])+')"></div>'+
            '<div class="spp-card-body">'+
              '<div class="spp-card-nm">'+esc(p.name)+'</div>'+
              '<div class="spp-card-pr" style="color:'+st.theme.accent+'">'+fmtK(p.rh)+'/½m</div>'+
            '</div>'+
          '</div>';
        }).join('')+
      '</div>'+
    '</div>';
};

/* ═════ COLLECTIONS PAGE ═════ */
function pageCollections(){
  setCrumb(["Admin","Toko","Koleksi"]);
  var cols = S.store.collections || [];
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Toko</div>'+
        '<h1 class="page-title">Koleksi</h1>'+
        '<p class="page-sub">Kelompokkan produk dalam koleksi tematik · tampil di homepage dan menu navigasi.</p>'+
      '</div>'+
    '</div>'+
    '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px">'+
      cols.map(function(c, i){
        return '<div class="card">'+
          '<div style="height:140px;background:linear-gradient(135deg,'+hex(S.products.find(function(p){return p.sku===c.products[0];})?S.products.find(function(p){return p.sku===c.products[0];}).colors[0]:"Hitam")+', '+hex(S.products.find(function(p){return p.sku===c.products[0];})?S.products.find(function(p){return p.sku===c.products[0];}).colors[1]||"Hitam":"Hitam")+');position:relative">'+
            (c.featured?'<div style="position:absolute;top:10px;right:10px;background:rgba(255,255,255,.94);color:var(--gold-2);padding:4px 10px;border-radius:99px;font-size:10px;font-weight:600">★ Featured</div>':'')+
          '</div>'+
          '<div class="card-body">'+
            '<h3 style="font-size:16px;margin-bottom:4px">'+esc(c.name)+'</h3>'+
            '<p style="font-size:12px;color:var(--ink-2);margin-bottom:12px;line-height:1.5">'+esc(c.desc)+'</p>'+
            '<div style="display:flex;justify-content:space-between;align-items:center"><span class="pill pill-mute">'+c.products.length+' produk</span><button class="btn btn-ghost btn-sm" onclick="toast(\'Edit koleksi · production akan sync ke storefront real-time.\',\'info\')">Edit →</button></div>'+
          '</div>'+
        '</div>';
      }).join('')+
    '</div>';
}

/* ═════ BRAND PAGE ═════ */
function pageBrand(){
  setCrumb(["Admin","Toko","Brand & Theme"]);
  var st = S.store;
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Toko</div>'+
        '<h1 class="page-title">Brand & Theme</h1>'+
        '<p class="page-sub">Identitas brand, palet warna, typography, dan story telling untuk toko Anda.</p>'+
      '</div>'+
      '<div class="page-actions"><button class="btn btn-primary" onclick="saveStore()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12l5 5 9-11"/></svg> Simpan</button></div>'+
    '</div>'+
    '<div class="card" style="margin-bottom:16px"><div class="card-head"><h3>Identitas Brand</h3></div><div class="card-body">'+
      '<div class="form-grid">'+
        '<div class="form-row two">'+
          '<div><label>Nama Brand</label><input class="inp" value="'+esc(st.brand_name)+'" oninput="S.store.brand_name=this.value" /></div>'+
          '<div><label>Tagline</label><input class="inp" value="'+esc(st.brand_tag)+'" oninput="S.store.brand_tag=this.value" /></div>'+
        '</div>'+
        '<div><label>Brand Story</label><textarea oninput="S.store.brand_about=this.value" rows="6">'+esc(st.brand_about)+'</textarea></div>'+
        '<div class="form-row three">'+
          '<div><label>WhatsApp</label><input class="inp" value="'+esc(st.contact.whatsapp)+'" oninput="S.store.contact.whatsapp=this.value" /></div>'+
          '<div><label>Email</label><input class="inp" type="email" value="'+esc(st.contact.email)+'" oninput="S.store.contact.email=this.value" /></div>'+
          '<div><label>Instagram</label><input class="inp" value="'+esc(st.contact.instagram)+'" oninput="S.store.contact.instagram=this.value" /></div>'+
        '</div>'+
      '</div>'+
    '</div></div>'+
    '<div class="card" style="margin-bottom:16px"><div class="card-head"><h3>Palet Warna</h3><div class="card-head-sub">Customisasi tema warna untuk seluruh storefront</div></div><div class="card-body">'+
      '<div class="form-row three">'+
        '<div><label>Warna Utama</label><div class="cp-row"><input type="color" value="'+st.theme.primary+'" oninput="S.store.theme.primary=this.value" /><input class="inp cp-hex" value="'+st.theme.primary+'" oninput="S.store.theme.primary=this.value" /></div></div>'+
        '<div><label>Warna Aksen</label><div class="cp-row"><input type="color" value="'+st.theme.accent+'" oninput="S.store.theme.accent=this.value" /><input class="inp cp-hex" value="'+st.theme.accent+'" oninput="S.store.theme.accent=this.value" /></div></div>'+
        '<div><label>Background</label><div class="cp-row"><input type="color" value="'+st.theme.bg+'" oninput="S.store.theme.bg=this.value" /><input class="inp cp-hex" value="'+st.theme.bg+'" oninput="S.store.theme.bg=this.value" /></div></div>'+
      '</div>'+
    '</div></div>'+
    '<div class="card"><div class="card-head"><h3>Aturan Bisnis</h3></div><div class="card-body">'+
      '<div class="form-row three">'+
        '<div><label>Min. Ecer <span class="hint">meter</span></label><input class="inp inp-num" type="number" step="0.5" value="'+st.business_rules.retail_min_meter+'" oninput="S.store.business_rules.retail_min_meter=parseFloat(this.value)" /></div>'+
        '<div><label>Min. Grosir <span class="hint">yard</span></label><input class="inp inp-num" type="number" value="'+st.business_rules.wholesale_min_yard+'" oninput="S.store.business_rules.wholesale_min_yard=parseInt(this.value)" /></div>'+
        '<div><label>Free Shipping <span class="hint">min. belanja</span></label><div class="inp-prefix"><span class="prefix">Rp</span><input class="inp inp-num" type="number" value="'+st.business_rules.free_shipping_min+'" oninput="S.store.business_rules.free_shipping_min=parseInt(this.value)" /></div></div>'+
      '</div>'+
    '</div></div>';
}

/* ═════ ANALYTICS PAGE ═════ */
function pageAnalytics(){
  setCrumb(["Admin","Overview","Analytics"]);
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Overview</div>'+
        '<h1 class="page-title">Analytics</h1>'+
        '<p class="page-sub">Deep analytics performa toko · revenue trends, customer behavior, dan product performance.</p>'+
      '</div>'+
    '</div>'+
    pageFinance().split('<div class="page-head">')[1].split('</div>').slice(2).join('</div>');
}

/* ═════ TEAM PAGE ═════ */
function pageTeam(){
  setCrumb(["Admin","Pengaturan","Tim & Akses"]);
  var team = [
    {n:"Giandi Owner",e:"owner@gianditextile.com",r:"Owner",last:"Sekarang",active:true},
    {n:"Customer Service",e:"cs@gianditextile.com",r:"Support",last:"2 jam lalu",active:true},
    {n:"Operations",e:"ops@gianditextile.com",r:"Operations",last:"5 jam lalu",active:true},
    {n:"Marketing",e:"marketing@gianditextile.com",r:"Marketing",last:"1 hari lalu",active:true}
  ];
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Pengaturan</div>'+
        '<h1 class="page-title">Tim & Akses</h1>'+
        '<p class="page-sub">Kelola anggota tim dan permission per role.</p>'+
      '</div>'+
      '<div class="page-actions"><button class="btn btn-primary"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 5v14M5 12h14"/></svg> Undang Anggota</button></div>'+
    '</div>'+
    '<div class="card"><div class="table-wrap"><table>'+
      '<thead><tr><th>Anggota</th><th>Role</th><th>Terakhir Aktif</th><th>Status</th><th></th></tr></thead>'+
      '<tbody>'+team.map(function(t){
        var initials = t.n.split(/\s+/).slice(0,2).map(function(w){return w.charAt(0);}).join("").toUpperCase();
        return '<tr>'+
          '<td><div class="prod-cell"><div class="cust-avatar'+(t.r==="Owner"?" vip":"")+'">'+initials+'</div><div><div style="font-weight:500;color:var(--navy)">'+esc(t.n)+'</div><div style="font-size:11px;color:var(--ink-3);margin-top:1px">'+esc(t.e)+'</div></div></div></td>'+
          '<td><span class="pill '+(t.r==="Owner"?"pill-gold":"pill-info")+'">'+t.r+'</span></td>'+
          '<td><div style="font-size:12px">'+esc(t.last)+'</div></td>'+
          '<td><span class="pill pill-ok"><span class="pill-dot"></span>Aktif</span></td>'+
          '<td><button class="btn btn-ghost btn-sm">Edit</button></td>'+
        '</tr>';
      }).join('')+'</tbody>'+
    '</table></div></div>';
}

/* ═════ INTEGRATIONS PAGE ═════ */
function pageIntegrations(){
  setCrumb(["Admin","Pengaturan","Integrasi"]);
  var integrations = [
    {n:"Supabase",desc:"Database PostgreSQL untuk produk, order, dan customer",cat:"Database",connected:true,logo:"#3ECF8E"},
    {n:"Midtrans",desc:"Payment gateway (QRIS, VA, Credit Card)",cat:"Payment",connected:true,logo:"#1C5BFF"},
    {n:"WhatsApp Cloud API",desc:"Pesan otomatis dan order tracking via WhatsApp",cat:"Messaging",connected:true,logo:"#25D366"},
    {n:"Claude AI",desc:"AI sales assistant untuk WhatsApp & website",cat:"AI",connected:true,logo:"#D97757"},
    {n:"RajaOngkir",desc:"Real-time ongkir untuk 6 kurir Indonesia",cat:"Shipping",connected:true,logo:"#0096D6"},
    {n:"Meta Ads",desc:"Tracking dan optimasi iklan Facebook & Instagram",cat:"Marketing",connected:true,logo:"#1877F2"},
    {n:"Google Drive",desc:"Backup foto produk dan dokumen",cat:"Storage",connected:false,logo:"#4285F4"},
    {n:"TikTok Shop API",desc:"Sync produk dan order dari TikTok Shop",cat:"Marketplace",connected:false,logo:"#000000"}
  ];
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Pengaturan</div>'+
        '<h1 class="page-title">Integrasi</h1>'+
        '<p class="page-sub">Layanan eksternal terhubung ke Giandi Ecosystem · '+integrations.filter(function(x){return x.connected;}).length+' aktif dari '+integrations.length+' tersedia.</p>'+
      '</div>'+
    '</div>'+
    '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px">'+
      integrations.map(function(it){
        return '<div class="card">'+
          '<div class="card-body">'+
            '<div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:10px">'+
              '<div style="width:40px;height:40px;border-radius:9px;background:'+it.logo+'18;color:'+it.logo+';display:grid;place-items:center;font-weight:700;font-size:14px;font-family:var(--mono)">'+it.n.substring(0,2).toUpperCase()+'</div>'+
              '<span class="pill '+(it.connected?"pill-ok":"pill-mute")+'"><span class="pill-dot"></span>'+(it.connected?"Connected":"Not Connected")+'</span>'+
            '</div>'+
            '<h3 style="font-size:15px;margin-bottom:4px">'+esc(it.n)+'</h3>'+
            '<div style="font-size:10px;color:var(--ink-3);letter-spacing:.1em;text-transform:uppercase;font-weight:600;margin-bottom:8px">'+esc(it.cat)+'</div>'+
            '<p style="font-size:12px;color:var(--ink-2);line-height:1.5;margin-bottom:14px">'+esc(it.desc)+'</p>'+
            '<button class="btn '+(it.connected?"btn-outline":"btn-primary")+'" style="width:100%">'+(it.connected?"Configure":"Connect")+'</button>'+
          '</div>'+
        '</div>';
      }).join('')+
    '</div>';
}

/* ═════ SETTINGS PAGE ═════ */
function pageSettings(){
  setCrumb(["Admin","Pengaturan","Pengaturan"]);
  var st = S.store;
  return ''+
    '<div class="page-head">'+
      '<div>'+
        '<div class="page-eyebrow">Pengaturan</div>'+
        '<h1 class="page-title">Pengaturan</h1>'+
        '<p class="page-sub">Konfigurasi umum toko, SEO, backup, dan akun.</p>'+
      '</div>'+
      '<div class="page-actions"><button class="btn btn-primary" onclick="saveStore()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12l5 5 9-11"/></svg> Simpan</button></div>'+
    '</div>'+
    '<div class="card" style="margin-bottom:16px"><div class="card-head"><h3>SEO Toko</h3><div class="card-head-sub">Meta tags yang muncul di Google Search</div></div><div class="card-body">'+
      '<div class="form-grid">'+
        '<div><label>Site Title</label><input class="inp" value="'+esc(st.seo.title)+'" oninput="S.store.seo.title=this.value" /></div>'+
        '<div><label>Meta Description</label><textarea oninput="S.store.seo.description=this.value" rows="3">'+esc(st.seo.description)+'</textarea></div>'+
      '</div>'+
    '</div></div>'+
    '<div class="card" style="margin-bottom:16px"><div class="card-head"><h3>Backup & Restore</h3></div><div class="card-body">'+
      '<p style="font-size:12px;color:var(--ink-2);line-height:1.6;margin-bottom:14px">Export semua data (produk, order, customer, settings) sebagai JSON untuk backup. Restore data dari file backup yang sudah ada.</p>'+
      '<div style="display:flex;gap:8px">'+
        '<button class="btn btn-outline" onclick="exportData()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Export Backup</button>'+
        '<label class="btn btn-outline"><input type="file" accept=".json" style="display:none" onchange="importBackup(this.files[0])" /><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg> Restore Backup</label>'+
        '<button class="btn btn-ghost" style="margin-left:auto;color:var(--err)" onclick="resetAllData()">Reset Semua Data</button>'+
      '</div>'+
    '</div></div>'+
    '<div class="card"><div class="card-head"><h3>Tentang Sistem</h3></div><div class="card-body">'+
      '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px">'+
        '<div style="background:var(--bg-2);border-radius:9px;padding:14px"><div style="font-size:10px;color:var(--ink-2);font-weight:600;text-transform:uppercase;letter-spacing:.06em">Versi Admin</div><div style="font-family:var(--mono);font-size:16px;font-weight:600;color:var(--navy);margin-top:4px">v3.0.0</div></div>'+
        '<div style="background:var(--bg-2);border-radius:9px;padding:14px"><div style="font-size:10px;color:var(--ink-2);font-weight:600;text-transform:uppercase;letter-spacing:.06em">Build</div><div style="font-family:var(--mono);font-size:16px;font-weight:600;color:var(--navy);margin-top:4px">2026.05.19</div></div>'+
        '<div style="background:var(--bg-2);border-radius:9px;padding:14px"><div style="font-size:10px;color:var(--ink-2);font-weight:600;text-transform:uppercase;letter-spacing:.06em">Lingkungan</div><div style="font-family:var(--mono);font-size:16px;font-weight:600;color:var(--ok);margin-top:4px">Production</div></div>'+
      '</div>'+
    '</div></div>';
}
window.importBackup = function(file){
  if(!file) return;
  var r = new FileReader();
  r.onload = function(e){
    try{
      var data = JSON.parse(e.target.result);
      if(data.products) S.products = data.products;
      if(data.hex) S.hex = data.hex;
      if(data.stock) S.stock = data.stock;
      if(data.store) S.store = data.store;
      if(data.orders) S.orders = data.orders;
      if(data.customers) S.customers = data.customers;
      if(data.vouchers) S.vouchers = data.vouchers;
      if(data.campaigns) S.campaigns = data.campaigns;
      persist();
      renderNav();
      render();
      toast("✓ Backup berhasil di-restore");
    }catch(err){
      toast("File backup tidak valid","error");
    }
  };
  r.readAsText(file);
};
window.resetAllData = function(){
  if(!confirm("Reset SEMUA data ke default? Tindakan ini tidak dapat dibatalkan.")) return;
  if(!confirm("Yakin? Semua perubahan akan hilang.")) return;
  try{
    var keys = Object.keys(localStorage).filter(function(k){return k.indexOf(KEY)===0;});
    for(var i=0;i<keys.length;i++) localStorage.removeItem(keys[i]);
  }catch(e){}
  window.location.reload();
};

})();
