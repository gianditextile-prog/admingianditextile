-- ════════════════════════════════════════════════════════════════════════════
--  GIANDI TEXTILE — ECOSYSTEM HUB v3
--  PRODUCTION SUPABASE SCHEMA  (PostgreSQL 15 / Supabase)
--  Single source of truth · IDR currency · id-ID locale
--  Apply with: supabase db push   OR   psql < 01-supabase-schema.sql
-- ════════════════════════════════════════════════════════════════════════════

create extension if not exists "pgcrypto";
create extension if not exists "uuid-ossp";
create extension if not exists "pg_trgm";
create extension if not exists "btree_gin";

-- ───────────────────────────────────────────────────────── ENUMS
do $$ begin
  create type user_role         as enum ('superadmin','admin','manager','seller','staff','customer');
  create type order_status      as enum ('draft','pending_payment','paid','processing','packed','shipped','delivered','completed','cancelled','refunded','returned');
  create type payment_status    as enum ('pending','authorized','settled','failed','expired','refunded');
  create type payment_method    as enum ('qris','va_bca','va_mandiri','va_bni','va_bri','va_permata','cc','gopay','shopeepay','dana','ovo','cash','transfer');
  create type sales_channel     as enum ('website','whatsapp','shopee','shopee_bogor','tiktok','lazada','tokopedia','blibli','offline');
  create type unit_type         as enum ('meter','half_meter','yard','roll');
  create type stock_movement_t  as enum ('in','out','adjust','transfer','return','reserve','release');
  create type shipment_status   as enum ('pending','picked_up','in_transit','out_for_delivery','delivered','failed','returned');
  create type conversation_state as enum ('open','awaiting_payment','awaiting_shipment','closed','spam');
  create type campaign_status   as enum ('draft','active','paused','completed','archived');
  create type ad_platform       as enum ('meta','google','tiktok','shopee_ads','tokopedia_ads');
exception when duplicate_object then null; end $$;

-- ───────────────────────────────────────────────────────── CORE: USERS & ROLES
create table if not exists users (
  id            uuid primary key default uuid_generate_v4(),
  email         citext unique,
  phone         text unique,
  password_hash text,
  full_name     text not null,
  role          user_role not null default 'customer',
  avatar_url    text,
  is_active     boolean not null default true,
  email_verified_at  timestamptz,
  phone_verified_at  timestamptz,
  last_login_at      timestamptz,
  metadata      jsonb default '{}'::jsonb,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists idx_users_role on users(role);
create index if not exists idx_users_phone on users(phone);

create table if not exists permissions (
  id          uuid primary key default uuid_generate_v4(),
  role        user_role not null,
  resource    text not null,
  action      text not null,
  unique(role,resource,action)
);

-- ───────────────────────────────────────────────────────── CUSTOMERS
create table if not exists customers (
  id            uuid primary key default uuid_generate_v4(),
  user_id       uuid references users(id) on delete set null,
  code          text unique not null default ('CUST-'||to_char(now(),'YYMMDD')||'-'||substr(uuid_generate_v4()::text,1,6)),
  full_name     text not null,
  phone         text,
  email         citext,
  whatsapp      text,
  address_line  text,
  city          text,
  province      text,
  postal_code   text,
  country       text default 'ID',
  tier          text default 'retail',          -- retail | wholesale | vip
  total_orders  int default 0,
  total_spent   bigint default 0,
  last_order_at timestamptz,
  source        sales_channel default 'website',
  tags          text[] default '{}',
  metadata      jsonb default '{}'::jsonb,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists idx_customers_phone on customers(phone);
create index if not exists idx_customers_email on customers(email);
create index if not exists idx_customers_search on customers using gin (full_name gin_trgm_ops);

-- ───────────────────────────────────────────────────────── PRODUCTS
create table if not exists products (
  id              uuid primary key default uuid_generate_v4(),
  sku_prefix      text unique not null,
  name            text not null,
  slug            text unique not null,
  category        text not null,
  description     text,
  retail_price_half_meter  bigint not null default 0,  -- IDR
  retail_price_meter       bigint not null default 0,
  wholesale_price_yard     bigint not null default 0,
  cost_price               bigint default 0,
  is_active       boolean not null default true,
  is_featured     boolean not null default false,
  weight_grams    int default 200,
  width_cm        int default 150,
  composition     text,
  care_instructions text,
  cover_image     text,
  gallery         jsonb default '[]'::jsonb,
  video_url       text,
  tags            text[] default '{}',
  metadata        jsonb default '{}'::jsonb,
  total_sold      int default 0,
  rating          numeric(3,2) default 0,
  rating_count    int default 0,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index if not exists idx_products_slug on products(slug);
create index if not exists idx_products_category on products(category);
create index if not exists idx_products_active on products(is_active);
create index if not exists idx_products_search on products using gin (name gin_trgm_ops);

create table if not exists product_variants (
  id              uuid primary key default uuid_generate_v4(),
  product_id      uuid not null references products(id) on delete cascade,
  sku             text unique not null,
  color_name      text not null,
  color_code      text not null,
  hex             text,
  swatch_url      text,
  gallery         jsonb default '[]'::jsonb,
  retail_price_half_meter_override bigint,
  retail_price_meter_override      bigint,
  wholesale_price_yard_override    bigint,
  is_active       boolean not null default true,
  position        int default 0,
  metadata        jsonb default '{}'::jsonb,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique(product_id,color_code)
);
create index if not exists idx_variants_product on product_variants(product_id);
create index if not exists idx_variants_sku on product_variants(sku);

-- ───────────────────────────────────────────────────────── INVENTORY
create table if not exists inventory (
  id            uuid primary key default uuid_generate_v4(),
  variant_id    uuid not null unique references product_variants(id) on delete cascade,
  qty_on_hand   numeric(12,2) not null default 0,   -- in meters
  qty_reserved  numeric(12,2) not null default 0,
  qty_yard      numeric(12,2) generated always as (qty_on_hand / 0.9144) stored,
  reorder_point numeric(12,2) default 5,
  warehouse     text default 'MAIN',
  updated_at    timestamptz not null default now()
);

create table if not exists stock_movements (
  id           uuid primary key default uuid_generate_v4(),
  variant_id   uuid not null references product_variants(id) on delete cascade,
  type         stock_movement_t not null,
  qty          numeric(12,2) not null,
  ref_type     text,
  ref_id       uuid,
  note         text,
  user_id      uuid references users(id),
  created_at   timestamptz not null default now()
);
create index if not exists idx_stockmov_variant on stock_movements(variant_id,created_at desc);

-- ───────────────────────────────────────────────────────── CART
create table if not exists carts (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid references users(id) on delete cascade,
  session_id  text,
  status      text not null default 'active',     -- active | converted | abandoned
  metadata    jsonb default '{}'::jsonb,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists cart_items (
  id          uuid primary key default uuid_generate_v4(),
  cart_id     uuid not null references carts(id) on delete cascade,
  variant_id  uuid not null references product_variants(id),
  unit        unit_type not null,
  qty         numeric(12,2) not null,
  unit_price  bigint not null,
  created_at  timestamptz not null default now()
);

-- ───────────────────────────────────────────────────────── ORDERS
create table if not exists orders (
  id                uuid primary key default uuid_generate_v4(),
  order_no          text unique not null default ('GD-'||to_char(now(),'YYMMDD')||'-'||substr(uuid_generate_v4()::text,1,8)),
  customer_id       uuid references customers(id),
  channel           sales_channel not null default 'website',
  status            order_status not null default 'pending_payment',
  subtotal          bigint not null default 0,
  discount_total    bigint not null default 0,
  shipping_total    bigint not null default 0,
  tax_total         bigint not null default 0,
  grand_total       bigint not null default 0,
  cost_total        bigint not null default 0,
  profit            bigint generated always as (grand_total - cost_total - shipping_total) stored,
  currency          text not null default 'IDR',
  customer_name     text,
  customer_phone    text,
  customer_email    text,
  shipping_address  jsonb,
  shipping_courier  text,
  shipping_service  text,
  shipping_awb      text,
  notes             text,
  cancel_reason     text,
  meta_lead_id      text,
  utm_source        text,
  utm_campaign      text,
  placed_at         timestamptz not null default now(),
  paid_at           timestamptz,
  shipped_at        timestamptz,
  completed_at      timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
create index if not exists idx_orders_customer on orders(customer_id);
create index if not exists idx_orders_status on orders(status);
create index if not exists idx_orders_channel on orders(channel);
create index if not exists idx_orders_placed on orders(placed_at desc);

create table if not exists order_items (
  id          uuid primary key default uuid_generate_v4(),
  order_id    uuid not null references orders(id) on delete cascade,
  variant_id  uuid not null references product_variants(id),
  product_name text not null,
  color_name   text not null,
  sku          text not null,
  unit         unit_type not null,
  qty          numeric(12,2) not null,
  unit_price   bigint not null,
  cost_price   bigint not null default 0,
  line_total   bigint not null,
  created_at   timestamptz not null default now()
);
create index if not exists idx_order_items_order on order_items(order_id);

-- ───────────────────────────────────────────────────────── INVOICES
create table if not exists invoices (
  id           uuid primary key default uuid_generate_v4(),
  invoice_no   text unique not null default ('INV-'||to_char(now(),'YYMMDD')||'-'||substr(uuid_generate_v4()::text,1,8)),
  order_id     uuid not null unique references orders(id) on delete cascade,
  amount       bigint not null,
  status       text not null default 'unpaid',
  due_at       timestamptz,
  pdf_url      text,
  issued_at    timestamptz not null default now(),
  created_at   timestamptz not null default now()
);

-- ───────────────────────────────────────────────────────── PAYMENTS
create table if not exists payments (
  id                  uuid primary key default uuid_generate_v4(),
  order_id            uuid not null references orders(id) on delete cascade,
  midtrans_order_id   text,
  midtrans_transaction_id text,
  method              payment_method not null,
  status              payment_status not null default 'pending',
  amount              bigint not null,
  fee                 bigint default 0,
  net_amount          bigint generated always as (amount - coalesce(fee,0)) stored,
  va_number           text,
  qris_url            text,
  snap_token          text,
  snap_redirect_url   text,
  raw_payload         jsonb,
  paid_at             timestamptz,
  expired_at          timestamptz,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);
create index if not exists idx_payments_order on payments(order_id);
create index if not exists idx_payments_status on payments(status);

-- ───────────────────────────────────────────────────────── SHIPMENTS
create table if not exists shipments (
  id           uuid primary key default uuid_generate_v4(),
  order_id     uuid not null references orders(id) on delete cascade,
  courier      text not null,
  service      text,
  awb          text,
  cost         bigint default 0,
  weight_grams int,
  status       shipment_status not null default 'pending',
  picked_up_at timestamptz,
  delivered_at timestamptz,
  tracking_url text,
  raw_payload  jsonb,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create table if not exists returns (
  id           uuid primary key default uuid_generate_v4(),
  order_id     uuid not null references orders(id),
  reason       text,
  status       text default 'requested',
  refund_amount bigint default 0,
  approved_at  timestamptz,
  created_at   timestamptz not null default now()
);

-- ───────────────────────────────────────────────────────── CRM: CONVERSATIONS
create table if not exists conversations (
  id             uuid primary key default uuid_generate_v4(),
  customer_id    uuid references customers(id),
  channel        sales_channel not null default 'whatsapp',
  external_id    text,                              -- WA phone, IG handle, etc.
  state          conversation_state not null default 'open',
  assigned_to    uuid references users(id),
  last_message_at timestamptz,
  unread_count   int default 0,
  metadata       jsonb default '{}'::jsonb,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create table if not exists messages (
  id              uuid primary key default uuid_generate_v4(),
  conversation_id uuid not null references conversations(id) on delete cascade,
  direction       text not null,                  -- inbound | outbound
  type            text not null default 'text',   -- text | image | template | order
  body            text,
  media_url       text,
  ai_generated    boolean default false,
  ai_intent       text,
  ai_confidence   numeric(4,3),
  raw_payload     jsonb,
  created_at      timestamptz not null default now()
);
create index if not exists idx_messages_conv on messages(conversation_id,created_at desc);

-- ───────────────────────────────────────────────────────── MARKETING
create table if not exists campaigns (
  id           uuid primary key default uuid_generate_v4(),
  name         text not null,
  platform     ad_platform not null default 'meta',
  status       campaign_status not null default 'draft',
  budget_daily bigint default 0,
  budget_total bigint default 0,
  spend_total  bigint default 0,
  impressions  int default 0,
  clicks       int default 0,
  leads        int default 0,
  conversions  int default 0,
  revenue      bigint default 0,
  external_id  text,
  starts_at    timestamptz,
  ends_at      timestamptz,
  metadata     jsonb default '{}'::jsonb,
  created_at   timestamptz not null default now()
);

create table if not exists ad_leads (
  id           uuid primary key default uuid_generate_v4(),
  campaign_id  uuid references campaigns(id),
  full_name    text,
  phone        text,
  email        text,
  message      text,
  customer_id  uuid references customers(id),
  converted    boolean default false,
  raw_payload  jsonb,
  created_at   timestamptz not null default now()
);

-- ───────────────────────────────────────────────────────── FINANCE
create table if not exists finance_transactions (
  id           uuid primary key default uuid_generate_v4(),
  type         text not null,         -- revenue | expense | refund | adjustment | transfer
  category     text not null,
  amount       bigint not null,       -- positive=in, negative=out
  currency     text default 'IDR',
  ref_type     text,                  -- order | payment | manual
  ref_id       uuid,
  account      text default 'main',
  description  text,
  date         date not null default current_date,
  user_id      uuid references users(id),
  metadata     jsonb default '{}'::jsonb,
  created_at   timestamptz not null default now()
);
create index if not exists idx_fintx_date on finance_transactions(date desc);
create index if not exists idx_fintx_type on finance_transactions(type);

-- ───────────────────────────────────────────────────────── AUDIT
create table if not exists audit_logs (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid references users(id),
  action      text not null,
  resource    text not null,
  resource_id uuid,
  before      jsonb,
  after       jsonb,
  ip          inet,
  user_agent  text,
  created_at  timestamptz not null default now()
);
create index if not exists idx_audit_resource on audit_logs(resource,resource_id);

-- ───────────────────────────────────────────────────────── TRIGGERS
create or replace function set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

do $$ declare t text; begin
  for t in select unnest(array['users','customers','products','product_variants','carts','orders','payments','shipments','conversations']) loop
    execute format('drop trigger if exists trg_%I_upd on %I',t,t);
    execute format('create trigger trg_%I_upd before update on %I for each row execute function set_updated_at()',t,t);
  end loop;
end $$;

-- recompute order grand_total from items
create or replace function recompute_order_totals() returns trigger language plpgsql as $$
declare oid uuid;
begin
  oid := coalesce(new.order_id, old.order_id);
  update orders set
    subtotal   = (select coalesce(sum(line_total),0) from order_items where order_id=oid),
    cost_total = (select coalesce(sum(cost_price*qty),0) from order_items where order_id=oid)
  where id=oid;
  update orders set grand_total = subtotal - discount_total + shipping_total + tax_total where id=oid;
  return null;
end $$;

drop trigger if exists trg_order_items_total on order_items;
create trigger trg_order_items_total
after insert or update or delete on order_items
for each row execute function recompute_order_totals();

-- auto-create finance_transaction on paid order
create or replace function on_order_paid() returns trigger language plpgsql as $$
begin
  if new.status='paid' and (old.status is null or old.status<>'paid') then
    insert into finance_transactions(type,category,amount,ref_type,ref_id,description,date)
    values('revenue', new.channel::text, new.grand_total, 'order', new.id,
           'Order '||new.order_no, current_date);
    new.paid_at := now();
  end if;
  return new;
end $$;
drop trigger if exists trg_order_paid on orders;
create trigger trg_order_paid before update on orders
for each row execute function on_order_paid();

-- ───────────────────────────────────────────────────────── RLS POLICIES
alter table users           enable row level security;
alter table customers       enable row level security;
alter table products        enable row level security;
alter table product_variants enable row level security;
alter table inventory       enable row level security;
alter table carts           enable row level security;
alter table cart_items      enable row level security;
alter table orders          enable row level security;
alter table order_items     enable row level security;
alter table invoices        enable row level security;
alter table payments        enable row level security;
alter table conversations   enable row level security;
alter table messages        enable row level security;
alter table shipments       enable row level security;
alter table finance_transactions enable row level security;
alter table audit_logs      enable row level security;

-- public read on products / variants / inventory
drop policy if exists "public read products" on products;
create policy "public read products" on products for select using (is_active = true);

drop policy if exists "public read variants" on product_variants;
create policy "public read variants" on product_variants for select using (is_active = true);

drop policy if exists "public read inventory" on inventory;
create policy "public read inventory" on inventory for select using (true);

-- customers own their data
drop policy if exists "customer own" on customers;
create policy "customer own" on customers for all
using (user_id = auth.uid() or auth.jwt()->>'role' in ('admin','superadmin','manager','staff'))
with check (user_id = auth.uid() or auth.jwt()->>'role' in ('admin','superadmin','manager','staff'));

-- orders: customer sees own, staff sees all
drop policy if exists "orders access" on orders;
create policy "orders access" on orders for all
using (
  customer_id in (select id from customers where user_id = auth.uid())
  or auth.jwt()->>'role' in ('admin','superadmin','manager','seller','staff')
);

drop policy if exists "order items access" on order_items;
create policy "order items access" on order_items for all
using (order_id in (select id from orders));

-- carts: own session/user
drop policy if exists "cart own" on carts;
create policy "cart own" on carts for all
using (user_id = auth.uid() or auth.jwt()->>'role' in ('admin','superadmin','manager','staff'));

-- admin-only tables
drop policy if exists "admin only" on finance_transactions;
create policy "admin only" on finance_transactions for all
using (auth.jwt()->>'role' in ('admin','superadmin','manager'));

drop policy if exists "admin audit" on audit_logs;
create policy "admin audit" on audit_logs for all
using (auth.jwt()->>'role' in ('admin','superadmin'));

-- ════════════════════════════════════════════════════════════════════════════
--  SEED DATA — MASTER PRODUCT CATALOG (GIANDI TEXTILE)
-- ════════════════════════════════════════════════════════════════════════════

-- helper: slugify
create or replace function slugify(s text) returns text language sql immutable as $$
  select trim(both '-' from regexp_replace(lower(trim(s)),'[^a-z0-9]+','-','g'))
$$;

-- helper: stable color code
create or replace function color_to_code(s text) returns text language sql immutable as $$
  select upper(regexp_replace(translate(s,' /','--'),'[^A-Za-z0-9-]','','g'))
$$;

-- 1) Insert master products
insert into products (sku_prefix, name, slug, category, retail_price_half_meter, retail_price_meter, wholesale_price_yard, cost_price, is_active, is_featured, composition, width_cm, weight_grams, description)
values
('GI-MSP',  'Marbella Silk Prestige', 'marbella-silk-prestige', 'Premium Silk',     27500, 55000, 20000, 14000, true, true,
 '100% premium silk blend', 150, 200, 'Marbella Silk Prestige — kain sutra premium dengan jatuh kain elegan, cocok untuk gamis syar''i, dress, dan hijab segi empat. Tersedia 32 varian warna.'),
('GI-MSL',  'Marbella Silk Luxe', 'marbella-silk-luxe', 'Premium Silk',                32500, 65000, 25000, 17000, true, true,
 'Premium silk dengan finishing luxe', 150, 210, 'Marbella Silk Luxe — kelas mewah dengan tekstur lembut dan kilau halus, ideal untuk koleksi premium boutique.'),
('GI-MSPM', 'Marbella Silk Premium', 'marbella-silk-premium', 'Premium Silk',         37500, 75000, 30000, 19000, true, true,
 'Premium silk grade A', 150, 215, 'Marbella Silk Premium — grade tertinggi seri Marbella, untuk koleksi eksklusif.'),
('GI-GS',   'Golden Silk', 'golden-silk', 'Luxury Silk',                              30000, 60000, 23000, 15500, true, false,
 'Luxury silk', 150, 205, 'Golden Silk — kain mewah dengan finishing emas lembut, statement piece untuk koleksi premium.'),
('GI-RSU',  'Royanna Silk UV', 'royanna-silk-uv', 'Luxury Silk',                      31000, 62000, 24000, 16000, true, false,
 'UV-resistant luxury silk', 150, 200, 'Royanna Silk UV — sutra mewah dengan perlindungan UV, warna tidak mudah pudar.'),
('GI-MHP',  'Maheen Prive', 'maheen-prive', 'Textured Premium',                       34000, 68000, 28000, 17500, true, true,
 'Textured premium fabric', 150, 220, 'Maheen Prive — kain bertekstur premium dengan karakter earthy modern.'),
('GI-CUP',  'Cupro', 'cupro', 'Breathable Fabric',                                     36000, 72000, 29000, 18000, true, false,
 'Breathable cupro fabric', 150, 195, 'Cupro — kain breathable adem dengan jatuh kain yang ringan dan mewah.'),
('GI-JKS',  'Jetblack Kiara Softer', 'jetblack-kiara-softer', 'Jet Black Series',     24000, 48000, 18000, 12500, true, false,
 'Soft black fabric', 150, 200, 'Jetblack Kiara Softer — hitam pekat dengan handfeel sangat lembut.'),
('GI-JFS',  'Jetblack Fursan', 'jetblack-fursan', 'Jet Black Series',                  25000, 50000, 19000, 13000, true, false,
 'Premium black fursan', 150, 210, 'Jetblack Fursan — seri jet black dengan karakter premium fursan.'),
('GI-JMB',  'Jetblack Marbella', 'jetblack-marbella', 'Jet Black Series',              26000, 52000, 20000, 13500, true, false,
 'Black marbella silk', 150, 200, 'Jetblack Marbella — versi jet black dari seri Marbella Silk.'),
('GI-JWP',  'Jetblack Woolpeach', 'jetblack-woolpeach', 'Jet Black Series',            22500, 45000, 17000, 11500, true, false,
 'Black woolpeach', 150, 215, 'Jetblack Woolpeach — woolpeach hitam pekat, cocok untuk gamis dan abaya formal.')
on conflict (sku_prefix) do update set
  name=excluded.name, slug=excluded.slug, category=excluded.category,
  retail_price_half_meter=excluded.retail_price_half_meter,
  retail_price_meter=excluded.retail_price_meter,
  wholesale_price_yard=excluded.wholesale_price_yard,
  cost_price=excluded.cost_price, description=excluded.description, updated_at=now();

-- 2) Insert all color variants programmatically
do $$
declare
  prod record;
  c text;
  colors_msp  text[] := array['Hitam','Broken White','Classic Maroon','Burgundy','Storm Blue','Deep Teal','Urban Mist','Deep Ash','Cocoa Chestnut','Blush Mauve','Warm Tan','Classic Taupe','Coffee','Chocolate Brown','Dusty Lavender','Mystic Plum','Ashen Berry','Soft Mocha','Twilight Navy','Slate Blue','Charcoal','Fog Stone','Grape Violet','Dust Plum','Soft Petal','Blush Petal','Silver Mist','Matcha Cream','Terracotta','Nude Mahogany','Burnt Mahogany','Intense Mahogany'];
  colors_msl  text[] := array['Black','Royal Navy','Maroon','Forest Deep','Berry Blush','Rose Wood','Sage Grey','Cloudy Blue','Azure Calm','Deep Slate','Vanilla Dust','Caramel Nude'];
  colors_mspm text[] := array['Ivory','Champagne','Dusty Pink','Sage Green','Olive','Terracotta','Mustard','Navy','Emerald'];
  colors_gs   text[] := array['Forest Green','Light Lime Green','Silver Pearl White'];
  colors_rsu  text[] := array['Deep Blue','Snow White','Dark Maroon','Burgundy','Misty Purple','Deep Teal','Ash Grey','Warm Mocha'];
  colors_mhp  text[] := array['Soft Broken White','Warm Sand Beige','Natural Nude','Cream Stone','Cocoa Sand','Khaki Clay','Tiramisu Earth','Ash Peach Clay','Soft Peach Sand'];
  colors_cup  text[] := array['Desert Dune','Champagne Sand','Soft Almond','Cocoa Mousse','Sage Laurel','Graphite Ash','Midnight Navy','Onyx Black','Rosewood Blush'];
  colors_jb   text[] := array['Jet Black'];
  hexmap jsonb := '{
    "Hitam":"#0B0B0B","Broken White":"#F2EBE0","Classic Maroon":"#5B1A1F","Burgundy":"#6B1F2C","Storm Blue":"#2C4A66","Deep Teal":"#1F4E5C","Urban Mist":"#9AA3A8","Deep Ash":"#5D6066","Cocoa Chestnut":"#6B3A22","Blush Mauve":"#C7A4A6","Warm Tan":"#B58965","Classic Taupe":"#8E7763","Coffee":"#5A3A24","Chocolate Brown":"#3E2418","Dusty Lavender":"#A493B4","Mystic Plum":"#5E3552","Ashen Berry":"#7B4256","Soft Mocha":"#8C6F5C","Twilight Navy":"#1B2A4E","Slate Blue":"#4A5F7A","Charcoal":"#2A2A2A","Fog Stone":"#A8A8A6","Grape Violet":"#5B2C6F","Dust Plum":"#6E4A65","Soft Petal":"#EAD0D4","Blush Petal":"#E8B6B6","Silver Mist":"#C7C9CC","Matcha Cream":"#C1C58F","Terracotta":"#B5573E","Nude Mahogany":"#9C6A5A","Burnt Mahogany":"#6E3A2D","Intense Mahogany":"#4A2218",
    "Black":"#0A0A0A","Royal Navy":"#0F1E4B","Maroon":"#5C1A2A","Forest Deep":"#0E3B2E","Berry Blush":"#A45561","Rose Wood":"#7D4A4E","Sage Grey":"#9AA59A","Cloudy Blue":"#9EB1C6","Azure Calm":"#5B82A6","Deep Slate":"#3A4A5C","Vanilla Dust":"#E9DEC8","Caramel Nude":"#B98E66",
    "Ivory":"#F4ECDD","Champagne":"#E3CFA6","Dusty Pink":"#D6A7AD","Sage Green":"#A8B5A2","Olive":"#6B6A2A","Mustard":"#C19A2C","Navy":"#1A2A52","Emerald":"#1F6E54",
    "Forest Green":"#1F4D3A","Light Lime Green":"#B7D58A","Silver Pearl White":"#EDEAE0",
    "Deep Blue":"#102B5C","Snow White":"#F8F6F0","Dark Maroon":"#3E0F18","Misty Purple":"#7E6E94","Ash Grey":"#8C8E92","Warm Mocha":"#7A5A45",
    "Soft Broken White":"#F0E7D6","Warm Sand Beige":"#D4B894","Natural Nude":"#D9B89B","Cream Stone":"#E6D7BE","Cocoa Sand":"#A8825F","Khaki Clay":"#9C8255","Tiramisu Earth":"#7A5536","Ash Peach Clay":"#C28E76","Soft Peach Sand":"#E0B9A0",
    "Desert Dune":"#C9A87C","Champagne Sand":"#D8B98A","Soft Almond":"#D9B894","Cocoa Mousse":"#7A5B45","Sage Laurel":"#7E8B6E","Graphite Ash":"#4A4A4A","Midnight Navy":"#0F172A","Onyx Black":"#0A0A0A","Rosewood Blush":"#8B5A5E",
    "Jet Black":"#000000"
  }'::jsonb;
begin
  for prod in select id, sku_prefix from products loop
    declare arr text[];
    begin
      arr := case prod.sku_prefix
        when 'GI-MSP'  then colors_msp
        when 'GI-MSL'  then colors_msl
        when 'GI-MSPM' then colors_mspm
        when 'GI-GS'   then colors_gs
        when 'GI-RSU'  then colors_rsu
        when 'GI-MHP'  then colors_mhp
        when 'GI-CUP'  then colors_cup
        when 'GI-JKS'  then colors_jb
        when 'GI-JFS'  then colors_jb
        when 'GI-JMB'  then colors_jb
        when 'GI-JWP'  then colors_jb
      end;
      if arr is null then continue; end if;
      foreach c in array arr loop
        insert into product_variants(product_id, sku, color_name, color_code, hex, is_active)
        values (prod.id,
                prod.sku_prefix||'-'||color_to_code(c),
                c, color_to_code(c),
                coalesce(hexmap->>c,'#8B82A8'), true)
        on conflict (product_id, color_code) do update set
          color_name=excluded.color_name, hex=excluded.hex, updated_at=now();
      end loop;
    end;
  end loop;
end $$;

-- 3) Initialize inventory for every variant (default 50 meter)
insert into inventory(variant_id, qty_on_hand, reorder_point, warehouse)
select v.id, 50, 10, 'MAIN' from product_variants v
on conflict (variant_id) do nothing;

-- 4) Default superadmin (password=admin123 — bcrypt placeholder; replace in production via Supabase Auth)
insert into users(email, phone, full_name, role, is_active)
values ('admin@giandi.id','+6281234567890','Giandi Admin','superadmin', true)
on conflict (email) do nothing;

-- 5) Permissions seed
insert into permissions(role, resource, action) values
('superadmin','*','*'),
('admin','products','*'),('admin','orders','*'),('admin','customers','*'),('admin','finance','*'),
('manager','products','read'),('manager','orders','*'),('manager','finance','read'),
('seller','products','*'),('seller','orders','read'),('seller','orders','update'),
('staff','orders','read'),('staff','orders','update'),
('customer','orders','read_own'),('customer','cart','*')
on conflict do nothing;

-- ───────────────────────────────────────────────────────── VIEWS (analytics)
create or replace view v_product_catalog as
select
  p.id, p.sku_prefix, p.name, p.slug, p.category, p.is_active, p.is_featured,
  p.retail_price_half_meter, p.retail_price_meter, p.wholesale_price_yard,
  p.cover_image, p.gallery, p.tags, p.rating, p.rating_count, p.total_sold,
  coalesce((select count(*) from product_variants v where v.product_id=p.id and v.is_active),0) as variant_count,
  coalesce((select sum(qty_on_hand) from inventory i join product_variants v on v.id=i.variant_id where v.product_id=p.id),0) as total_stock_m
from products p;

create or replace view v_sales_daily as
select date(placed_at) as date,
       channel,
       count(*) as orders,
       sum(grand_total) as revenue,
       sum(cost_total) as cost,
       sum(profit) as profit
from orders where status in ('paid','processing','packed','shipped','delivered','completed')
group by 1,2 order by 1 desc;

create or replace view v_inventory_alerts as
select v.sku, p.name, v.color_name, i.qty_on_hand, i.qty_reserved, i.reorder_point
from inventory i
join product_variants v on v.id=i.variant_id
join products p on p.id=v.product_id
where i.qty_on_hand <= i.reorder_point;

-- ════════════════════════════════════════════════════════════════════════════
--  END OF SCHEMA — Apply via: supabase db reset && supabase db push
-- ════════════════════════════════════════════════════════════════════════════
