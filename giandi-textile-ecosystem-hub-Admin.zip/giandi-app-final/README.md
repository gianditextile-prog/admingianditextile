# 🎀 Giandi Textile — Ecosystem Hub v3

> **Premium Fabric Atelier · Enterprise Digital Operating System**
> Marketplace · Admin · Seller Center · Finance · CRM · AI Sales · Payments · Shipping

A complete, **production-ready** Node.js + Express application built for premium silk supplier Giandi Textile. Includes a full customer storefront, a 30+ module Seller Center admin dashboard, Supabase PostgreSQL schema with RLS, Midtrans payment integration, WhatsApp Cloud API webhook with Claude AI Sales Engine, Meta Ads integration, RajaOngkir shipping, and PWA support.

---

## ✨ Highlights

| Capability | Detail |
|---|---|
| **Storefront** | 11 products · 130+ color variants · ecer (0,5 m / 1 m) & grosir (per yard) · dual stock pools · wishlist · cart · checkout · 8 Midtrans payment methods |
| **Seller Center** | 30+ modules: Pesanan · Pengiriman Massal · Serah Terima · Retur · Produk · Inventory · Media · Promosi · Diskon · Flash Sale · Voucher · Program Loyalty · Garansi Harga · Iklan Meta · Customers · Chat · Asisten AI · Broadcast · Penilaian · Finance · Penghasilan · Saldo · Dana Cepat · Bank · Produk Keuangan · Analytics · Health · Profil · Dekorasi · Settings · Banding · Misi |
| **Database** | Full Supabase PostgreSQL schema (657 lines) — 23 tables · RLS · triggers · views · seed data |
| **Payments** | Midtrans Snap API · QRIS · 4 bank VAs · Credit/Debit · GoPay · ShopeePay · webhook with sha512 signature verification |
| **AI Sales** | WhatsApp Cloud API webhook → Claude Sonnet 4.5 auto-reply · intent classification · structured order extraction |
| **Shipping** | RajaOngkir integration · 8 couriers · free ongkir threshold · auto-cost calculation |
| **PWA** | Manifest + Service Worker · installable · offline support |
| **Branding** | Midnight Navy `#0F172A` · Rose Gold `#C6A769` · Fraunces serif · pixel-perfect responsive |

---

## 📦 Project Structure

```
giandi-textile-ecosystem-hub/
├── server.js                    # Express entry point
├── package.json                 # Dependencies + scripts
├── .env.example                 # Environment template
├── .gitignore
├── vercel.json                  # Alt deployment config
│
├── lib/
│   ├── supabase.js              # Supabase client singleton
│   ├── midtrans.js              # Midtrans Snap + Core API
│   ├── claude.js                # Claude AI sales engine
│   └── catalog.js               # Master product catalog (single source of truth)
│
├── api/
│   ├── products/index.js        # Product list, detail, variants
│   ├── orders/index.js          # Order CRUD + Midtrans Snap creation
│   ├── midtrans/index.js        # Payment webhook (sha512 verify) + status
│   ├── whatsapp/index.js        # Meta verification + inbound webhook + send/broadcast
│   ├── claude/index.js          # AI chat, intent, order extraction
│   └── shipping/index.js        # RajaOngkir provinces/cities/cost
│
├── db/
│   └── schema.sql               # Full Supabase schema (657 lines, RLS, triggers, seed)
│
├── scripts/
│   ├── seed.js                  # Idempotent product/variant/inventory seeder
│   └── migrate.js               # Schema migration helper
│
└── public/
    ├── index.html               # Storefront + Admin shell
    ├── manifest.json            # PWA manifest
    ├── sw.js                    # Service worker (offline)
    └── js/
        └── app.js               # Storefront + 30+ admin modules (vanilla JS)
```

---

## 🚀 Deployment to Hostinger (Node.js Hosting)

### Step 1 — Upload to Hostinger

1. Login to **Hostinger hPanel** → **Websites** → your domain → **Deploy Aplikasi Web Node.js**
2. Click **Upload file** → **Lanjutkan**
3. Upload `giandi-textile-ecosystem-hub-v3.zip`
4. Set Node.js options:
   - **Node.js version:** 18.x or 20.x
   - **Application root:** `/`
   - **Application URL:** your domain
   - **Application startup file:** `server.js`
   - **Environment:** Production

### Step 2 — Install dependencies

From Hostinger Terminal (or auto):
```bash
cd ~/domains/yourdomain.com/public_html
npm install --production
```

### Step 3 — Configure environment variables

Copy `.env.example` → `.env` in app root and fill in:
- Supabase credentials
- Midtrans keys (start with sandbox, switch to production once tested)
- WhatsApp Cloud API token
- Anthropic API key

### Step 4 — Start

Hostinger's panel auto-starts `node server.js`. To restart manually:
```bash
npm start
```

App is live at `https://yourdomain.com`. The admin panel is at `https://yourdomain.com/?r=admin`.

---

## 🗄️ Supabase Setup

1. Create new project at https://app.supabase.com
2. Open **SQL Editor** → New query → paste content of `db/schema.sql` → **Run**
3. This creates 23 tables + RLS policies + triggers + seeds 11 products and ~130 variants
4. Copy `Project URL`, `anon key`, `service_role key` from **Settings → API** into `.env`
5. (Optional) Run `node scripts/seed.js` to (re)load catalog from Node side

---

## 💳 Midtrans Setup

1. Register at https://midtrans.com → activate Sandbox
2. **Dashboard → Settings → Access Keys** → copy `Server Key` & `Client Key` into `.env`
3. **Dashboard → Settings → Configuration** → set Payment Notification URL:
   `https://yourdomain.com/api/midtrans/webhook`
4. Webhook handler at `/api/midtrans/webhook` verifies sha512 signature and updates order status automatically
5. Switch `MIDTRANS_IS_PRODUCTION=true` after testing

---

## 💬 WhatsApp Cloud API Setup

1. Go to https://developers.facebook.com → Create app → **WhatsApp Business**
2. Get permanent **Access Token** + **Phone Number ID**
3. Set webhook URL in Meta dashboard: `https://yourdomain.com/api/whatsapp/webhook`
   Verify token: value of `WHATSAPP_VERIFY_TOKEN` env var (default: `giandi-verify-2026`)
4. Subscribe to `messages` field
5. Every inbound message → Claude AI replies automatically, persists to `conversations` + `messages` tables

---

## 🤖 Claude AI Setup

1. Get API key from https://console.anthropic.com
2. Set `ANTHROPIC_API_KEY` and `CLAUDE_MODEL` in `.env`
3. Default model: `claude-sonnet-4-5-20250929`
4. System prompt is in `lib/claude.js` — fully editable. Trained on full Giandi catalog with pricing tiers, business rules, and Indonesian sales tone.

---

## 🔑 Default Admin Access

- **Email:** `admin@giandi.id`
- **Password:** `admin123`
- **URL:** `https://yourdomain.com/?r=admin`

⚠️ Change in `db/schema.sql` and rotate `JWT_SECRET` in production.

---

## 📋 API Endpoints

| Method | Path | Purpose |
|---|---|---|
| `GET`  | `/health` | Health check |
| `GET`  | `/api/products` | List products (optional `?category=`, `?q=`, `?sort=`) |
| `GET`  | `/api/products/:slug` | Product detail + variants |
| `GET`  | `/api/products/meta/variants` | Full denormalized variant list |
| `POST` | `/api/orders` | Create order + Midtrans Snap token |
| `GET`  | `/api/orders` | List orders (filter by `?phone=`, `?status=`, `?channel=`) |
| `GET`  | `/api/orders/:order_no` | Single order with items + payments |
| `PATCH`| `/api/orders/:order_no/status` | Update status (shipped → AWB) |
| `POST` | `/api/midtrans/create` | Snap transaction (alt entry) |
| `POST` | `/api/midtrans/webhook` | Midtrans notification handler |
| `GET`  | `/api/midtrans/status/:order_id` | Manual status check |
| `GET`  | `/api/whatsapp/webhook` | Meta verification handshake |
| `POST` | `/api/whatsapp/webhook` | Inbound msg → Claude reply |
| `POST` | `/api/whatsapp/send` | Outbound message |
| `POST` | `/api/whatsapp/broadcast` | Bulk message |
| `POST` | `/api/claude/chat` | Direct chat with Claude |
| `POST` | `/api/claude/extract` | Extract structured order from convo |
| `POST` | `/api/claude/classify` | Intent classification |
| `GET`  | `/api/shipping/provinces` | RajaOngkir provinces |
| `GET`  | `/api/shipping/cities` | Cities |
| `POST` | `/api/shipping/cost` | Calculate shipping cost |

---

## 🎨 Product Catalog

| SKU | Product | Colors | Retail ½ m | Retail 1 m | Grosir/yard |
|---|---|---|---|---|---|
| GI-MSP | Marbella Silk Prestige | 32 | Rp 27.500 | Rp 55.000 | Rp 20.000 |
| GI-MSL | Marbella Silk Luxe | 12 | Rp 32.500 | Rp 65.000 | Rp 25.000 |
| GI-MSPM | Marbella Silk Premium | 9 | Rp 37.500 | Rp 75.000 | Rp 30.000 |
| GI-GS | Golden Silk | 3 | Rp 30.000 | Rp 60.000 | Rp 23.000 |
| GI-RSU | Royanna Silk UV | 8 | Rp 31.000 | Rp 62.000 | Rp 24.000 |
| GI-MHP | Maheen Prive | 9 | Rp 34.000 | Rp 68.000 | Rp 28.000 |
| GI-CUP | Cupro | 9 | Rp 36.000 | Rp 72.000 | Rp 29.000 |
| GI-JKS | Jetblack Kiara Softer | 1 | Rp 24.000 | Rp 48.000 | Rp 18.000 |
| GI-JFS | Jetblack Fursan | 1 | Rp 25.000 | Rp 50.000 | Rp 19.000 |
| GI-JMB | Jetblack Marbella | 1 | Rp 26.000 | Rp 52.000 | Rp 20.000 |
| GI-JWP | Jetblack Woolpeach | 1 | Rp 22.500 | Rp 45.000 | Rp 17.000 |

Edit prices/colors in `lib/catalog.js` AND `public/js/app.js` (storefront uses same data for instant offline rendering).

---

## 🛒 Seller Center Modules

### Operations
Pesanan Saya · Pengiriman Massal · Serah Terima Pesanan · Retur & Pembatalan · Pengaturan Pengiriman

### Catalog
Produk Master · Inventory Management · Media Library

### Marketing
Pusat Promosi · Diskon · Flash Sale · Voucher Toko · Pengelolaan Program · Garansi Harga Terbaik · Iklan Meta API

### CRM
Customers · Manajemen Chat · Asisten AI Chat · Chat Broadcast · Penilaian Toko

### Finance
Finance Dashboard · Penghasilan Saya · Saldo Saya · Dana Cepat · Rekening Bank · Produk Keuangan

### Data
Performa Toko · Kesehatan Toko

### Store
Profil Toko · Dekorasi Toko · Pengaturan Toko · Pengelolaan Banding · Misi Penjual

---

## 🌐 Recommended Domain Setup

| Subdomain | Points to |
|---|---|
| `gianditextile.com` | Main marketing landing (this app) |
| `store.gianditextile.com` | Same app — storefront |
| `admin.gianditextile.com` | Same app — admin (or restrict by IP) |
| `api.gianditextile.com` | Same app — API only |
| `assets.gianditextile.com` | Cloudflare R2 / Supabase Storage / Google Drive |

In Hostinger DNS → add A records pointing all subdomains to your server IP.

---

## 🛠️ Local Development

```bash
npm install
cp .env.example .env       # fill in
npm run dev                # starts node server.js
# open http://localhost:3000
```

Without env vars, the app **runs in mock mode** — Supabase, Midtrans, WhatsApp, and Claude all use stubbed responses. Perfect for UI testing.

---

## 🧪 Testing the Flow

1. Open `http://localhost:3000`
2. Click any product → choose color → pick unit (0,5m / 1m / yard) → Add to cart
3. Checkout → fill shipping → choose Midtrans method → place order
4. Order is saved in Supabase (or localStorage in mock mode)
5. Open `/?r=admin` to see it appear in Dashboard → Pesanan
6. Update status (shipped → enter AWB → delivered)

---

## 📱 Mobile / PWA

This app is a fully installable PWA. On mobile Chrome/Safari → "Add to Home Screen" works out of the box.

For **native app wrapper** with Capacitor:
```bash
npm install @capacitor/cli @capacitor/core
npx cap init "Giandi Textile" "com.giandi.textile"
npx cap add android
npx cap add ios
npx cap sync
```
Then point `webDir` to `public/` in `capacitor.config.json`.

---

## 🔐 Security Checklist

- [x] Helmet.js security headers
- [x] CORS configured per env
- [x] Rate limiting on `/api/*` and `/api/whatsapp/*`
- [x] Midtrans signature verification (sha512)
- [x] WhatsApp verify token handshake
- [x] Supabase RLS policies (role-based)
- [x] Service role key server-side only (never exposed to client)
- [ ] **TODO:** Rotate `JWT_SECRET` before production
- [ ] **TODO:** Change default admin password
- [ ] **TODO:** Enable Supabase 2FA on database access

---

## 📄 License

UNLICENSED · © 2026 Giandi Textile · All rights reserved.

---

## 🆘 Support

For deployment issues, email `dev@giandi.id` or open an issue in your internal GitHub repository.

**Built with care for premium Indonesian textile commerce.** 🌹
