# 🚀 HOSTINGER QUICK DEPLOY

This is the **fastest path** to get Giandi Textile running on Hostinger Node.js hosting.

## 1. Upload this ZIP

Hostinger hPanel → **Websites** → your domain → **Deploy Aplikasi Web Node.js** → **Upload file** → choose this ZIP.

## 2. Set Node.js options

| Field | Value |
|---|---|
| Node.js version | **20.x** |
| Application root | `/` |
| Startup file | **`server.js`** |
| Environment | **Production** |

## 3. (Optional) Configure environment

In Hostinger Terminal:
```bash
cd ~/domains/yourdomain.com/public_html
cp .env.example .env
nano .env       # fill in Supabase, Midtrans, WhatsApp, Claude keys
```

If you skip this step, the app runs in **mock mode** — fully functional storefront + admin, but no real payments / Supabase / WhatsApp. Perfect for first demo.

## 4. Install + Start

Hostinger usually auto-runs `npm install` and starts. If not:
```bash
npm install --production
npm start
```

## 5. Visit

- Storefront: `https://yourdomain.com`
- Admin: `https://yourdomain.com/?r=admin`

That's it. ✅

---

For full setup (Supabase schema, Midtrans webhook, WhatsApp Cloud API, Claude AI), see **`README.md`**.
